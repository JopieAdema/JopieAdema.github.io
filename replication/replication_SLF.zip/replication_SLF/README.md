# Replication package

**Terrorism and Voting: The Rise of Right-Wing Populism in Germany: Comment**
Joop Adema (University of Innsbruck), November 2026

This package reproduces every table, figure and number in the comment on Sabet, Liebald and Friebel (2025), "Terrorism and Voting: The Rise of Right-Wing Populism in Germany", *American Economic Journal: Economic Policy* 17 (3): 407–40, <https://doi.org/10.1257/pol.20230615>. One command runs everything:

```
Rscript run_all.R
```

Run it from the package root after setting the path to Stata at the top of `run_all.R`. Results are written to `output/` (CSV and figures) and to one log per script in `logs/`. Numbers reported only in the text are printed in the logs, mostly on lines starting with `RESULT`.

## Data

### Sabet, Liebald and Friebel (2025) replication package (`data/slf/`)

The analysis uses the authors' processed data from their replication package: openICPSR project 208722, version V1, <https://doi.org/10.3886/E208722V1> (accessed November 2026). `code/00_extract_slf_data.R` builds `data/slf/` from that package and documents what was taken. The files are:

| File | Content |
|---|---|
| `derived/master.dta` | Municipality-by-election panel used in all of SLF's main estimates |
| `derived/master_propensity.dta` | SLF's propensity-matched sample (their Table 3) |
| `derived/municipality_first_terror.dta` | First successful and first failed attack date by municipality |
| `raw_processed/election_state.dta` | Municipal state-election results, all years |
| `raw_processed/election_federal.dta` | Municipal federal-election results |
| `raw/election_state/143xx-01-03-*.csv` | State-election tables exported by SLF from the Regional Database of the federal and state statistical offices (regionalstatistik.de) |
| `attacks.csv` | The 232 attacks in SLF's sample: municipality key, name, date, successful (1) or failed (0) |
| `LICENSE.txt` | SLF's license file |

The election and municipality data are licensed under the Data Licence Germany – Attribution – Version 2.0 (dl-de/by-2-0) and are redistributed here with attribution to the Federal Returning Officer and the statistical offices of the federal government and the states; SLF's code is under the MIT License (see `data/slf/LICENSE.txt`). SLF's attack-level file (`raw_processed/terror_raw.dta`, which carries Global Terrorism Database variables) is not redistributed; `attacks.csv` keeps only the four columns needed here. The SOEP data used in part of SLF's paper are not used.

### Official election results (`data/official/official_results.csv`)

Official results used to correct the two control municipalities (Ludwigshafen am Rhein 2021, Kremmen 2019) and Nauen 2019, and to document the errors in Table 4. Each row gives the value and its source: the Landeswahlleiter Rheinland-Pfalz (*Die Wahl zum 18. Landtag Rheinland-Pfalz am 14. März 2021, Endgültige Ergebnisse, Teil 1*), the Landeswahlleiter Brandenburg (Landtagswahl 2019, second-vote results by *Amt* and municipality, wahlergebnisse.brandenburg.de), and the Amt für Statistik Berlin-Brandenburg (*Landtagswahl 2019 im Land Brandenburg, Endgültiges Ergebnis*, table 3.7). The values enter the code directly in `06_official_corrections.do` and `13_eventstudy_turnout.R`.

## Software

- R 4.4.3 with haven 2.5.4, data.table 1.18.2.1, fixest 0.12.1, ggplot2 4.0.3, sandwich 3.1.1, lmtest 0.9.40.
- Stata 18 MP with reghdfe 6.13.1, ftools 2.50.0 and boottest 4.5.0. `code/00_setup_stata.do` installs missing packages from SSC.

Wild cluster bootstrap p-values use 9,999 draws with seed 20261111; randomization-inference p-values in `14_balance.R` use the same seed. The full run takes about two to three minutes on a standard laptop (Windows 11).

## Scripts and exhibits

| Script | Produces |
|---|---|
| `00_extract_slf_data.R` | Builds `data/slf/` from SLF's package (not run by `run_all.R`) |
| `00_setup_stata.do` | Installs Stata packages if missing |
| `01_attacks.R` | Attack counts in Section 2; Table 8 |
| `02_main_table.R` | Table 1; Table 3, columns 1–3 and 5–7 (estimates, standard errors) → `main_table_counts.csv`, `main_table_estimates.csv` |
| `03_main_table_wcb.do` | Table 3, columns 1–3 and 5–7, bootstrap p-values → `main_table_wcb.dta`; alternative bootstrap p-values in Section 4 |
| `04_decomposition.do` | Table 2; attack-date coding check (Section 3, Appendix B) |
| `05_sensitivity.do` | Table 6 |
| `06_official_corrections.do` | Table 3, columns 4 and 8; corrections reported in Appendix A (Ludwigshafen alone; Nauen in addition) |
| `07_matched_sample.do` | Table 7 |
| `08_eventstudy_sunab.R` | Event-study estimates for Figure 1 and the average post-attack effects in Section 4 → `eventstudy_afd_sunab.csv` |
| `09_eventstudy_figure.R` | Figure 1 → `eventstudy_main.pdf`; election-type composition of event-time bins (Section 4) → `eventstudy_composition.csv` |
| `10_eventstudy_yearcohorts.R` | Year-of-attack cohort estimates in the notes to Figure 1 |
| `11_eventstudy_drop_fed17.R` | Event study without the 2017 federal election (Appendix A) |
| `12_eventstudy_rawmeans.R` | Figure 2 → `eventstudy_rawmeans.pdf`; raw means in Section 4 |
| `13_eventstudy_turnout.R` | Figure 3 → `eventstudy_turnout.pdf`; averages in its notes |
| `14_balance.R` | Table 5 → `balance_panelB.csv` |
| `15_data_checks.R` | Section 3 and Appendix A: postal-vote coverage of the state-election files, package values in Table 4, informative municipalities by state, 2017 federal data, 2021 state data (Berlin, Saxony-Anhalt), missing elections |

Table 4 combines the package values printed by `15_data_checks.R` (section B) with the official values in `data/official/official_results.csv`.

## Notes

- The event studies use the Sun–Abraham estimator in the R package fixest rather than SLF's Stata implementation (`xtevent`); see the Reproduction paragraph in Appendix B of the comment.
- `boottest` does not run after `reghdfe` with several absorbed fixed effects, so the bootstrap scripts estimate the same models with `areg`, absorbing municipality by election type and entering the time fixed effects as dummies. Point estimates are identical.
- `manuscript/` contains the comment (PDF and LaTeX source). Its figures are read from `../output/`.
