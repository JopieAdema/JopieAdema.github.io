# Runs the full replication package for "Terrorism and Voting: The Rise of Right-Wing Populism in
# Germany: Comment". Run from the package root:   Rscript run_all.R
# Results go to output/ (tables as CSV, figures as PDF/PNG); every script writes a log to logs/.
# Set the path to your Stata executable below. Stata runs in batch mode (/e on Windows, -b elsewhere).

stata <- "C:/Stata18/StataMP-64.exe"

setwd(file.path(getwd(), "code"))
dir.create("../output", showWarnings = FALSE)
dir.create("../logs", showWarnings = FALSE)
rscript <- file.path(R.home("bin"), "Rscript")

run_r <- function(f) {
  cat("Running", f, "\n")
  log <- file.path("../logs", sub("\\.R$", ".log", f))
  ret <- system2(rscript, f, stdout = log, stderr = log)
  if (ret != 0) stop(f, " failed; see ", log)
}
run_stata <- function(f) {
  cat("Running", f, "\n")
  flag <- if (.Platform$OS.type == "windows") "/e" else "-b"
  ret <- system2(stata, c(flag, "do", f), wait = TRUE, stdout = FALSE, stderr = FALSE)
  log <- sub("\\.do$", ".log", f)                # Stata batch mode writes the log to the working directory
  if (file.exists(log)) file.rename(log, file.path("../logs", log))
  txt <- readLines(file.path("../logs", log), warn = FALSE)
  if (ret != 0 || any(grepl("^r\\(\\d+\\);", txt))) stop(f, " failed; see ../logs/", log)
}

run_stata("00_setup_stata.do")
run_r("01_attacks.R")
run_r("02_main_table.R")
run_stata("03_main_table_wcb.do")
run_stata("04_decomposition.do")
run_stata("05_sensitivity.do")
run_stata("06_official_corrections.do")
run_stata("07_matched_sample.do")
run_r("08_eventstudy_sunab.R")
run_r("09_eventstudy_figure.R")
run_r("10_eventstudy_yearcohorts.R")
run_r("11_eventstudy_drop_fed17.R")
run_r("12_eventstudy_rawmeans.R")
run_r("13_eventstudy_turnout.R")
run_r("14_balance.R")
run_r("15_data_checks.R")
cat("Done.\n")
