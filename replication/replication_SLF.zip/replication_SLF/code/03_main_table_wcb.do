* Table 3, columns 1-3 and 5-7, bracketed p-values: restricted wild cluster bootstrap (Webb weights,
* 9,999 draws, clustered by municipality) for SLF's pooled model with (a) SLF fixed effects and
* (b) state-by-election-type-by-year fixed effects, for the AfD vote share and turnout (2013+).
* Also the alternative bootstrap p-values for the AfD state-election coefficient reported in Section 4
* (Rademacher weights, and the unrestricted bootstrap).
clear all
set more off
set seed 20261111
tempname h
postfile `h' str10 outcome str4 spec byte type double(b p_wcb) using "../output/main_table_wcb.dta", replace
foreach y in share_afd turnout {
	foreach s in slf sxy {
		use "../data/slf/derived/master.dta", clear
		keep if success!=.
		if "`y'"=="turnout" keep if year>=2013
		forvalues t = 1/3 {
			gen sp`t' = post_election*success*(election_type==`t')
			gen p`t'  = post_election*(election_type==`t')
		}
		* boottest does not run after reghdfe with several absorbed fixed effects: absorb municipality x type
		* in areg and enter the time fixed effects as dummies (point estimates identical to reghdfe)
		egen idtype = group(id election_type)
		if "`s'"=="slf" egen tfe = group(election_type year)
		if "`s'"=="sxy" egen tfe = group(land election_type year)
		areg `y' sp1 sp2 sp3 p1 p2 p3 i.tfe, absorb(idtype) cluster(id)
		forvalues t = 1/3 {
			if _se[sp`t']>0 {
				local b = _b[sp`t']
				boottest sp`t', weighttype(webb) reps(9999) nograph
				post `h' ("`y'") ("`s'") (`t') (`b') (r(p))
			}
		}
	}
}
postclose `h'
use "../output/main_table_wcb.dta", clear
list, clean

* Alternative bootstrap p-values, AfD vote share, state elections, SLF fixed effects
use "../data/slf/derived/master.dta", clear
keep if success!=.
forvalues t = 1/3 {
	gen sp`t' = post_election*success*(election_type==`t')
	gen p`t'  = post_election*(election_type==`t')
}
egen idtype = group(id election_type)
egen tfe = group(election_type year)
areg share_afd sp1 sp2 sp3 p1 p2 p3 i.tfe, absorb(idtype) cluster(id)
set seed 20261111
boottest sp3, weighttype(rademacher) reps(9999) nograph
di "RESULT restricted, Rademacher weights: p = " %5.3f r(p)
boottest sp3, weighttype(rademacher) reps(9999) nonull nograph
di "RESULT unrestricted, Rademacher weights: p = " %5.3f r(p)
