* Installs the user-written Stata packages used here, if they are missing (requires internet access).
* Versions used for the results in the comment: reghdfe 6.13.1, ftools 2.50.0, boottest 4.5.0.
foreach p in ftools reghdfe boottest {
	capture which `p'
	if _rc ssc install `p'
}
which ftools
which reghdfe
which boottest
