# Figure 1 (main-text event study): SLF's Figure 3 specification vs. the same pooled model with
# state-by-election-type-by-year FE (estimates from 08_eventstudy_sunab.R, all municipalities).
# Also tabulates the election-type composition of each event-time bin for successfully attacked municipalities.
suppressPackageStartupMessages({library(haven); library(data.table); library(ggplot2)})
root <- ".."
r <- fread(file.path(root, "output/eventstudy_afd_sunab.csv"))
r <- r[sample == "All municipalities" & substr(design, 1, 1) %in% c("A", "C")]
r[, spec := ifelse(substr(design, 1, 1) == "A", "SLF specification (Figure 3)", "State-by-year fixed effects")]
r[, x := rel + ifelse(substr(design, 1, 1) == "A", -0.1, 0.1)]
labs <- c("-4" = "-4+", "-3" = "-3", "-2" = "-2", "-1" = "-1", "0" = "0", "1" = "1", "2" = "2", "3" = "3+")
p <- ggplot(r, aes(x, b, colour = spec, shape = spec)) +
  geom_hline(yintercept = 0, colour = "grey70") +
  geom_vline(xintercept = -0.5, colour = "grey50", linetype = "dashed") +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.1) + geom_point(size = 2.2) +
  scale_x_continuous(breaks = -4:3, labels = labs) +
  scale_colour_manual(values = c("#1f4e79", "#c0504d")) +
  labs(x = "Elections relative to first attack", y = "Effect on AfD vote share", colour = NULL, shape = NULL) +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
ggsave(file.path(root, "output/eventstudy_main.pdf"), p, width = 6.5, height = 3.6)
ggsave(file.path(root, "output/eventstudy_main.png"), p, width = 6.5, height = 3.6, dpi = 200)

# Composition of event-time bins (successfully attacked municipalities, SLF's event-time definition)
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))
m <- m[!is.na(success) & !is.na(election_date)][order(id, year, election_type)]
m[, period := seq_len(.N), by = id]; m[, policy := success * post_election]
m <- merge(m, m[policy == 1, .(cohort = min(period)), by = id], by = "id", all.x = TRUE)
t <- m[success == 1 & !is.na(cohort) & !is.na(share_afd)]
t[, rel := pmin(pmax(period - cohort, -4), 3)]
comp <- dcast(t[, .N, by = .(rel, election_type)], rel ~ election_type, value.var = "N", fill = 0)
setnames(comp, c("rel", "federal", "european", "state"))
comp[, share_state := round(state / (federal + european + state), 2)]
comp[, mean_afd := t[, .(m = round(mean(share_afd), 3)), by = rel][order(rel)]$m]
print(comp)
fwrite(comp, file.path(root, "output/eventstudy_composition.csv"))
