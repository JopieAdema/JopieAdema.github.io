* State-election estimates after replacing erroneous observations with official results
* (values and sources in ../data/official/official_results.csv):
*   Ludwigshafen 2021: package holds constituency 36 only -> official city result
*                      (turnout 52,785/100,442; AfD 6,539/52,126 valid list votes)
*   Kremmen 2019:      package excludes postal votes -> official municipal result (turnout 0.601; AfD 0.251)
*   Nauen 2019:        successfully attacked; package excludes postal votes -> official (turnout 0.522; AfD 0.277)
* Part 1: Table 3, columns 4 and 8 (both controls corrected), with restricted wild cluster bootstrap p-values.
* Part 2: Appendix A (text), Ludwigshafen corrected alone; and Nauen corrected in addition to both controls.
clear all
set more off
set seed 20261111

capture program drop fix_controls
program define fix_controls
	replace turnout   = 52785/100442 if id==7314000  & year==2021 & election_type==3
	replace share_afd = 6539/52126   if id==7314000  & year==2021 & election_type==3
	replace turnout   = 0.601        if id==12065165 & year==2019 & election_type==3
	replace share_afd = 0.251        if id==12065165 & year==2019 & election_type==3
end

* ---- Part 1: Table 3, columns 4 and 8 ----
foreach y in share_afd turnout {
	foreach s in slf sxy {
		use "../data/slf/derived/master.dta", clear
		keep if success!=.
		if "`y'"=="turnout" keep if year>=2013
		fix_controls
		forvalues t = 1/3 {
			gen sp`t' = post_election*success*(election_type==`t')
			gen p`t'  = post_election*(election_type==`t')
		}
		egen idtype = group(id election_type)
		if "`s'"=="slf" egen tfe = group(election_type year)
		if "`s'"=="sxy" egen tfe = group(land election_type year)
		qui reghdfe `y' sp1 sp2 sp3 p1 p2 p3, a(idtype tfe) cluster(id)
		local b = _b[sp3]
		local se = _se[sp3]
		qui areg `y' sp1 sp2 sp3 p1 p2 p3 i.tfe, absorb(idtype) cluster(id)
		boottest sp3, weighttype(webb) reps(9999) nograph noci
		di "RESULT Table 3 corrected controls, `y', `s': " %7.4f `b' " (" %6.4f `se' ") [" %5.3f r(p) "]"
	}
}

* ---- Part 2: Ludwigshafen alone (fix = 1); both controls and Nauen (fix = 3) ----
foreach y in share_afd turnout {
	foreach fix in 1 3 {
		use "../data/slf/derived/master.dta", clear
		if "`y'"=="turnout" keep if year>=2013
		if `fix'==1 {
			replace turnout   = 52785/100442 if id==7314000 & year==2021 & election_type==3
			replace share_afd = 6539/52126   if id==7314000 & year==2021 & election_type==3
		}
		if `fix'==3 {
			fix_controls
			replace turnout   = 0.522 if id==12063208 & year==2019 & election_type==3
			replace share_afd = 0.277 if id==12063208 & year==2019 & election_type==3
		}
		forvalues t = 1/3 {
			gen p`t'  = post_election*(election_type==`t')
			gen sp`t' = success*post_election*(election_type==`t')
		}
		qui reghdfe `y' sp1 sp2 sp3 p1 p2 p3, a(i.id#i.election_type i.election_type#i.year) cluster(id)
		local b1 = _b[sp3]
		local s1 = _se[sp3]
		qui reghdfe `y' sp1 sp2 sp3 p1 p2 p3, a(i.id#i.election_type i.land#i.election_type#i.year) cluster(id)
		di "RESULT `y' fix=`fix' (1 = Ludwigshafen only, 3 = both controls and Nauen)  SLF FE: " %7.4f `b1' " (" %6.4f `s1' ")   state x year FE: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
	}
}
