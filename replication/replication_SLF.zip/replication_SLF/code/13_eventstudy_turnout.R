# Appendix figure: Sun-Abraham event study of turnout, styled like the main AfD figure (09_eventstudy_figure.R).
# Same designs as 08_eventstudy_sunab.R panels A (SLF Figure 3 specification) and C (state-by-year FE),
# with turnout as outcome and elections from 2013 (as in SLF's turnout regressions, figure4.do).
# Also reports average post-attack effects after replacing the two controls' erroneous state-election
# turnout with official values (Ludwigshafen 2021: 0.526; Kremmen 2019: 0.601).
suppressPackageStartupMessages({library(haven); library(data.table); library(fixest); library(ggplot2)})
root <- ".."
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))
m <- m[!is.na(success) & !is.na(election_date) & year >= 2013]

prep <- function(d) {
  d <- copy(d)[order(id, year, election_type)]
  d[, period := seq_len(.N), by = id]
  d[, policy := success * post_election]
  d <- merge(d, d[policy == 1, .(cohort = min(period)), by = id], by = "id", all.x = TRUE)
  d[is.na(cohort), cohort := 10000]
  d
}
est <- function(d, fe_time, unit) {
  obs <- unique(d[cohort < 10000 & !is.na(turnout), period - cohort])
  binlist <- list(`-4` = sort(obs[obs <= -4]), `3` = sort(obs[obs >= 3]))
  binlist <- binlist[lengths(binlist) > 0]
  bins <- if (length(binlist)) paste0(", bin.rel = ", paste(deparse(binlist, width.cutoff = 500L), collapse = "")) else ""
  r <- feols(as.formula(paste0("turnout ~ sunab(cohort, period, ref.p = -1", bins, ") | ", unit, " + ", fe_time)),
             data = d, cluster = ~id)
  att <- summary(r, agg = "ATT")$coeftable["ATT", 1:2]
  ct <- as.data.table(coeftable(r), keep.rownames = "term")
  ct[, rel := as.numeric(sub("period::", "", term))]
  list(att = att, es = rbind(ct[, .(rel, b = Estimate, se = `Std. Error`)], data.table(rel = -1, b = 0, se = 0))[order(rel)])
}
designs <- list(
  list(spec = "SLF specification (Figure 3)", fe = "period", unit = "id"),
  list(spec = "State-by-year fixed effects", fe = "land^election_type^year", unit = "id^election_type")
)
mc <- copy(m)
mc[id == 7314000 & election_type == 3 & year == 2021, turnout := 0.526]
mc[id == 12065165 & election_type == 3 & year == 2019, turnout := 0.601]
res <- list()
for (g in designs) {
  o <- est(prep(m), g$fe, g$unit); c <- est(prep(mc), g$fe, g$unit)
  cat(sprintf("%s: ATT %.4f (%.4f); official controls %.4f (%.4f)\n", g$spec, o$att[1], o$att[2], c$att[1], c$att[2]))
  res[[g$spec]] <- cbind(o$es, spec = g$spec)
}
r <- rbindlist(res)
r[, lo := b - 1.96 * se][, hi := b + 1.96 * se]
r[, x := rel + ifelse(spec == designs[[1]]$spec, -0.1, 0.1)]
print(r[, .(spec, rel, b = round(b, 4), se = round(se, 4))])
fwrite(r, file.path(root, "output/eventstudy_turnout.csv"))
labs <- c("-4" = "-4+", "-3" = "-3", "-2" = "-2", "-1" = "-1", "0" = "0", "1" = "1", "2" = "2", "3" = "3+")
p <- ggplot(r, aes(x, b, colour = spec, shape = spec)) +
  geom_hline(yintercept = 0, colour = "grey70") +
  geom_vline(xintercept = -0.5, colour = "grey50", linetype = "dashed") +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.1) + geom_point(size = 2.2) +
  scale_x_continuous(breaks = -4:3, labels = labs) +
  scale_colour_manual(values = c("#1f4e79", "#c0504d")) +
  labs(x = "Elections relative to first attack", y = "Effect on turnout", colour = NULL, shape = NULL) +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
ggsave(file.path(root, "output/eventstudy_turnout.pdf"), p, width = 6.5, height = 3.6)
ggsave(file.path(root, "output/eventstudy_turnout.png"), p, width = 6.5, height = 3.6, dpi = 200)
