# Figure 1 notes: robustness of the event study to SLF's cohort definition: interaction-weighted (Sun-Abraham) estimator
# with event time in elections (from the policy switch, as in xtevent) but cohorts defined by the calendar
# year of the attack (SLF's cohort(time_treat) with time_treat = year_attack). Event-time x cohort dummies,
# aggregated with cohort shares via fixest::aggregate. Never-treated: failed-attack municipalities and
# successfully attacked municipalities without a post-attack election.
suppressPackageStartupMessages({library(haven); library(data.table); library(fixest)})
root <- ".."
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))
m <- m[!is.na(success) & !is.na(election_date)][order(id, year, election_type)]
m[, period := seq_len(.N), by = id]; m[, policy := success * post_election]
m <- merge(m, m[policy == 1, .(first = min(period)), by = id], by = "id", all.x = TRUE)
m[, treated := !is.na(first)]
m[, rel := pmin(pmax(period - first, -4), 3)]
m[, rc := ifelse(treated & rel != -1, paste0("rel::", rel, ":cohort::", year_attack), "ref")]
m[, idtype := paste(id, election_type)]; m[, typeyear := paste(election_type, year)]; m[, stypeyear := paste(land, election_type, year)]

run <- function(fe, lab) {
  r <- feols(as.formula(paste("share_afd ~ i(rc, ref = 'ref') |", fe)), data = m, cluster = ~id)
  a <- aggregate(r, c("rel" = "rc::rel::(-?[[:digit:]]+):cohort"))
  att <- aggregate(r, c("ATT" = "rc::rel::[^-][[:digit:]]*:cohort"))
  cat("\n==", lab, "\n"); print(round(a[, 1:4], 4)); print(round(att[, 1:2], 4))
}
run("id + period", "SLF specification (municipality + election-position FE), year-of-attack cohorts")
run("idtype + typeyear", "SLF Table 2 FE, year-of-attack cohorts")
run("idtype + stypeyear", "State-by-year FE, year-of-attack cohorts")
