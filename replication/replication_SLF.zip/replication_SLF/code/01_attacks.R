# Attack counts (Section 2) and the failed-attack municipalities in state elections (Table 8):
# how many attacks failed, how many failed-attack municipalities also had a successful attack, and which
# state elections each failed-attack-only municipality has in SLF's data.
suppressPackageStartupMessages({library(haven); library(data.table)})
a <- fread("../data/slf/attacks.csv")
cat("Attacks:", nrow(a), "| successful:", sum(a$success), "| failed:", sum(a$success == 0), "\n")
g <- a[, .(n = .N, n_succ = sum(success)), by = id][, n_fail := n - n_succ]
cat("Municipalities:", nrow(g), "\n")
cat("  with at least one failed attack:", g[n_fail > 0, .N], "\n")
cat("  failed attacks only (SUCCESS = 0):", g[n_fail > 0 & n_succ == 0, .N], "\n")
cat("  failed and successful attacks (coded SUCCESS = 1):", g[n_fail > 0 & n_succ > 0, .N], "\n")

m <- as.data.table(read_dta("../data/slf/derived/master.dta"))
c0 <- unique(m[success == 0], by = c("id", "year", "election_type"))
first <- c0[order(id, year), .(first_attack = as.Date(date_attack[1])), by = id]
st <- c0[election_type == 3][order(id, year), .(state_elections = paste0(year, ifelse(post_election == 1, "*", ""),
                                                   ifelse(is.na(share_afd), " (no AfD)", ""), collapse = ", ")), by = id]
nm <- unique(a[, .(id, municipality)], by = "id")
out <- Reduce(function(x, y) merge(x, y, by = "id", all.x = TRUE), list(first, nm, st))
cat("\nFailed-attack-only municipalities (state elections in the data; * = after the first attack):\n")
print(out[order(first_attack)])
