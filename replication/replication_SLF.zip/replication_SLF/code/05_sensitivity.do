* Table 6: sensitivity of the state-election coefficient to the two informative failed-attack municipalities,
* Ludwigshafen (7314000) and Kremmen (12065165).
* Panel A: SLF's parameterization (sp3 alongside the common post terms p1-p3).
* Panel B: post-attack changes entered separately for successful (ps) and failed (pf) municipalities;
*          the effect ps3 - pf3 is reported only if pf3 is identified.
* Column 5: turnout including the 2010-2012 elections (SLF's turnout regressions start in 2013).
clear all
set more off
global fe i.year i.id#i.election_type i.election_type#i.year

* ---- Panel A ----
foreach y in share_afd turnout {
	use "../data/slf/derived/master.dta", clear
	if "`y'"=="turnout" keep if year>=2013
	forvalues t = 1/3 {
		gen p`t'  = post_election*(election_type==`t')
		gen sp`t' = success*post_election*(election_type==`t')
	}
	foreach d in 0 7314000 12065165 1 {
		if `d'==1 local cond "!inlist(id,7314000,12065165)"
		else local cond "id!=`d'"
		qui reghdfe `y' sp1 sp2 sp3 p1 p2 p3 if `cond', a($fe) cluster(id)
		di "RESULT panel A `y' dropping `d' (1 = both): " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
	}
}
use "../data/slf/derived/master.dta", clear
forvalues t = 1/3 {
	gen p`t'  = post_election*(election_type==`t')
	gen sp`t' = success*post_election*(election_type==`t')
}
qui reghdfe turnout sp1 sp2 sp3 p1 p2 p3, a($fe) cluster(id)
di "RESULT panel A turnout from 2010: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
* informative failed-attack municipalities in the state-election turnout sample from 2010
gen byte s = e(sample)
keep if s==1 & election_type==3
bysort id: egen npost = total(post_election)
bysort id: gen nobs = _N
bysort id: gen first = _n==1
gen switcher = npost>0 & npost<nobs
tab success switcher if first

* ---- Panel B ----
capture program drop report
program define report
	args lab
	if _se[pf3]==0 {
		di "RESULT panel B `lab': failed-attack term not identified (ps3 = " %6.4f _b[ps3] ")"
	}
	else {
		lincom ps3 - pf3
		di "RESULT panel B `lab': " %7.4f r(estimate) " (" %6.4f r(se) ")"
	}
end
foreach y in share_afd turnout {
	use "../data/slf/derived/master.dta", clear
	if "`y'"=="turnout" keep if year>=2013
	forvalues t = 1/3 {
		gen ps`t' = post_election*success*(election_type==`t')
		gen pf`t' = post_election*(1-success)*(election_type==`t')
	}
	qui reghdfe `y' ps1 ps2 ps3 pf1 pf2 pf3, a($fe) cluster(id)
	report "`y' baseline"
	qui reghdfe `y' ps1 ps2 ps3 pf1 pf2 pf3 if id!=7314000, a($fe) cluster(id)
	report "`y' without Ludwigshafen"
	qui reghdfe `y' ps1 ps2 ps3 pf1 pf2 pf3 if id!=12065165, a($fe) cluster(id)
	report "`y' without Kremmen"
	qui reghdfe `y' ps1 ps2 ps3 pf1 pf2 pf3 if !inlist(id,7314000,12065165), a($fe) cluster(id)
	report "`y' without both"
}
use "../data/slf/derived/master.dta", clear
forvalues t = 1/3 {
	gen ps`t' = post_election*success*(election_type==`t')
	gen pf`t' = post_election*(1-success)*(election_type==`t')
}
qui reghdfe turnout ps1 ps2 ps3 pf1 pf2 pf3, a($fe) cluster(id)
report "turnout from 2010"
