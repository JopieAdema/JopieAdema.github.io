# Table 1 (municipalities identifying the effect) and Table 3, columns 1-3 and 5-7 (point estimates and
# municipality-clustered standard errors): SLF's pooled model (their equation 2) with coefficients for
# federal, European and state elections, (a) with SLF's fixed effects (municipality x election type,
# election type x year) and (b) additionally with state x election type x year fixed effects, for the AfD
# vote share and turnout (elections from 2013). Bootstrap p-values: 03_main_table_wcb.do.
suppressPackageStartupMessages({library(haven); library(data.table); library(fixest)})
m <- as.data.table(read_dta("../data/slf/derived/master.dta"))
m <- m[!is.na(success)]
for (t in 1:3) {
  m[, paste0("sp", t) := post_election * success * (election_type == t)]
  m[, paste0("p", t)  := post_election * (election_type == t)]
}
m[, idtype := paste(id, election_type)]
m[, typeyear := paste(election_type, year)]
m[, statetypeyear := paste(land, election_type, year)]
types <- c("Federal", "European", "State")

fit <- function(y, d, fe) {
  d <- d[!is.na(get(y)) & !is.na(post_election) & !is.na(year) & !is.na(land)]
  # drop singleton fixed-effect cells iteratively, as reghdfe does (singletons do not affect the estimates,
  # but they matter for the unit counts in Table 1)
  fes <- strsplit(fe, " \\+ ")[[1]]
  repeat {
    n0 <- nrow(d)
    for (v in fes) d <- d[, if (.N > 1) .SD, by = v]
    if (nrow(d) == n0) break
  }
  f <- as.formula(paste(y, "~ sp1 + sp2 + sp3 + p1 + p2 + p3 |", fe))
  r <- feols(f, data = d, cluster = ~id)
  list(r = r, d = d)
}
# Units observed before and after the first attack identify the post-attack change for that election type
counts <- function(d, t) {
  x <- d[election_type == t, .(success = success[1], n = .N, npost = sum(post_election)), by = id]
  x[, informative := npost > 0 & npost < n]
  c(obs = d[election_type == t, .N], munis = nrow(x), succ = sum(x$success == 1), fail = sum(x$success == 0),
    succ_inf = sum(x$success == 1 & x$informative), fail_inf = sum(x$success == 0 & x$informative),
    states_fail_inf = uniqueN(d[election_type == t & id %in% x[success == 0 & informative == TRUE, id], land]))
}

out <- list(); cnt <- list()
specs <- list(slf = "idtype + typeyear", sxy = "idtype + statetypeyear")
for (y in c("share_afd", "turnout")) for (s in names(specs)) {
  d <- if (y == "turnout") m[year >= 2013] else m
  fr <- fit(y, d, specs[[s]])
  for (t in 1:3) {
    k <- paste0("sp", t)
    if (!(k %in% names(coef(fr$r)))) next
    out[[length(out) + 1]] <- data.table(outcome = y, spec = s, type = types[t],
      b = coef(fr$r)[k], se = se(fr$r)[k], p_clustered = pvalue(fr$r)[k], n_obs = sum(fr$d$election_type == t))
    if (s == "slf") cnt[[length(cnt) + 1]] <- data.table(outcome = y, type = types[t], t(counts(fr$d, t)))
  }
}
out <- rbindlist(out); cnt <- rbindlist(cnt)
fwrite(out, "../output/main_table_estimates.csv")
fwrite(cnt, "../output/main_table_counts.csv")
cat("Table 3 point estimates and clustered SEs (spec slf = columns 1-3, sxy = columns 5-7):\n")
print(out[, lapply(.SD, function(x) if (is.numeric(x)) round(x, 4) else x)])
cat("\nTable 1 (outcome share_afd) and the turnout counts in its notes:\n")
print(cnt)
