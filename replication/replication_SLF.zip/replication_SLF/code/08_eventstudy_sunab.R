# Estimates for Figure 1 and the average post-attack effects in Section 4: Sun-Abraham event study of the
# AfD vote share (SLF Figure 3), with and without the two
# informative failed-attack municipalities (Ludwigshafen 7314000, Kremmen 12065165).
#
# Panel 1 mirrors SLF's figure3.do: all election types pooled, event time counted in elections
# ("period" = position of the election in the municipality's sequence), municipality and period FE,
# failed-attack municipalities as the never-treated control cohort, window -3..2 with binned endpoints,
# reference period -1, SEs clustered by municipality. Difference to SLF: cohorts are defined by the
# period of first treatment (standard Sun-Abraham) rather than by the calendar year of the attack.
# Panel B: as panel A, but with SLF's Table 2 fixed effects (municipality x election type, election type x year).
# Panel C: as panel B, with state x election type x year FE (comparisons within the same election).
# Panel D: state elections only, event time in state elections, municipality and state x year FE.

suppressPackageStartupMessages({library(haven); library(data.table); library(fixest); library(ggplot2)})

root <- ".."
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))
m <- m[!is.na(success) & !is.na(election_date)]
drop2 <- c(7314000, 12065165)

prep <- function(d) {
  d <- copy(d)[order(id, year, election_type)]
  d[, period := seq_len(.N), by = id]
  d[, policy := success * post_election]
  first <- d[policy == 1, .(cohort = min(period)), by = id]
  d <- merge(d, first, by = "id", all.x = TRUE)
  d[is.na(cohort), cohort := 10000]          # failed attacks, or treated after the last election: never treated
  d
}

est <- function(d, fe_time, unit = "id") {
  obs <- unique(d[cohort < 10000 & !is.na(share_afd), period - cohort])
  binlist <- list(`-4` = sort(obs[obs <= -4]), `3` = sort(obs[obs >= 3]))
  binlist <- binlist[lengths(binlist) > 0]
  bins <- if (length(binlist)) paste0(", bin.rel = ", paste(deparse(binlist, width.cutoff = 500L), collapse = "")) else ""
  r <- feols(as.formula(paste0("share_afd ~ sunab(cohort, period, ref.p = -1", bins, ") | ", unit, " + ", fe_time)),
             data = d, cluster = ~id)
  att <- summary(r, agg = "ATT")$coeftable["ATT", 1:2]
  cat(sprintf("ATT (average post-attack effect): %.4f (%.4f)\n", att[1], att[2]))
  ct <- as.data.table(coeftable(r), keep.rownames = "term")
  ct[, rel := as.numeric(sub("period::", "", term))]
  rbind(ct[, .(rel, b = Estimate, se = `Std. Error`)], data.table(rel = -1, b = 0, se = 0))[order(rel)]
}

# Panel 3: pooled as in panel 1, but with SLF's Table 2 fixed effects
# (municipality x election type, election type x year) instead of municipality and period FE.
designs <- list(
  list(name = "A. Pooled, municipality and period FE (SLF Figure 3)", data = m, fe = "period"),
  list(name = "B. Pooled, SLF Table 2 FE", data = m, fe = "election_type^year", unit = "id^election_type"),
  list(name = "C. Pooled, state-by-year FE", data = m, fe = "land^election_type^year", unit = "id^election_type"),
  list(name = "D. State elections only, state-by-year FE", data = m[election_type == 3], fe = "land^year")
)
res <- list()
for (g in designs) for (s in c("All municipalities", "Without Ludwigshafen and Kremmen")) {
  d <- prep(if (s == "All municipalities") g$data else g$data[!(id %in% drop2)])
  unit <- if (is.null(g$unit)) "id" else g$unit
  res[[length(res) + 1]] <- cbind(est(d, g$fe, unit), sample = s, design = g$name)
}
res <- rbindlist(res)
res[, lo := b - 1.96 * se][, hi := b + 1.96 * se]
fwrite(res, file.path(root, "output/eventstudy_afd_sunab.csv"))
print(res[, .(design, sample, rel, b = round(b, 4), se = round(se, 4))])

res[, x := rel + ifelse(sample == "All municipalities", -0.12, 0.12)]
labs <- c("-4" = "-4+", "-3" = "-3", "-2" = "-2", "-1" = "-1", "0" = "0", "1" = "1", "2" = "2", "3" = "3+")
p <- ggplot(res, aes(x, b, colour = sample, shape = sample)) +
  geom_hline(yintercept = 0, colour = "grey70") +
  geom_vline(xintercept = -0.5, colour = "grey50", linetype = "dashed") +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.1) +
  geom_point(size = 2) +
  facet_wrap(~design, ncol = 1, scales = "free_x") +
  scale_x_continuous(breaks = -4:3, labels = labs) +
  scale_colour_manual(values = c("#1f4e79", "#c0504d")) +
  labs(x = "Elections relative to first attack", y = "Effect on AfD vote share", colour = NULL, shape = NULL) +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
ggsave(file.path(root, "output/eventstudy_afd_sunab.pdf"), p, width = 7, height = 10)
ggsave(file.path(root, "output/eventstudy_afd_sunab.png"), p, width = 7, height = 10, dpi = 200)
