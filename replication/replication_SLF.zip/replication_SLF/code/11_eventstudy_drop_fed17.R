# Average post-attack effect in SLF's event-study specification with and without the 2017 federal election
# (Section 3 and Appendix A: the 2017 federal results do not measure municipalities).
suppressPackageStartupMessages({library(haven); library(data.table); library(fixest)})
R <- "../data/slf"
m0 <- as.data.table(read_dta(file.path(R, "derived/master.dta")))
m0 <- m0[!is.na(success) & !is.na(election_date)]
run <- function(d, lab) {
  d <- copy(d)[order(id, year, election_type)]; d[, period := seq_len(.N), by = id]; d[, policy := success * post_election]
  d <- merge(d, d[policy == 1, .(cohort = min(period)), by = id], by = "id", all.x = TRUE); d[is.na(cohort), cohort := 10000]
  obs <- unique(d[cohort < 10000 & !is.na(share_afd), period - cohort])
  bl <- list(`-4` = sort(obs[obs <= -4]), `3` = sort(obs[obs >= 3])); bl <- bl[lengths(bl) > 0]
  f <- as.formula(paste0("share_afd ~ sunab(cohort, period, ref.p = -1, bin.rel = ", paste(deparse(bl, width.cutoff = 500L), collapse = ""), ") | id + period"))
  r <- feols(f, data = d, cluster = ~id)
  a <- summary(r, agg = "ATT")$coeftable["ATT", 1:2]
  cat(sprintf("\n== %s: ATT = %.4f (%.4f)\n", lab, a[1], a[2])); print(round(coeftable(r)[, 1:2], 4))
}
run(m0, "SLF spec, all elections")
run(m0[!(election_type == 1 & year == 2017)], "SLF spec, without 2017 federal election")
