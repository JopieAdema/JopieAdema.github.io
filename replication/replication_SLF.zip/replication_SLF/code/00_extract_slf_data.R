# Builds data/slf/ from the original replication package of Sabet, Liebald and Friebel (2025),
# openICPSR project 208722, version V1 (https://doi.org/10.3886/E208722V1).
#
# This script is NOT run by run_all.R: data/slf/ already contains its output. It documents how the
# shipped files were obtained and lets users rebuild them from the original package.
#
# Usage: Rscript 00_extract_slf_data.R "<path to SLF_replication_upload>"
# (run from the code/ folder)
#
# Files copied unchanged: derived/master.dta, derived/master_propensity.dta,
# derived/municipality_first_terror.dta, raw_processed/election_state.dta,
# raw_processed/election_federal.dta, raw/election_state/143*.csv (Regional Database exports), LICENSE.txt.
# The attack-level file raw_processed/terror_raw.dta (68,148 incidents, Global Terrorism Database
# variables) is not redistributed; only the four columns needed here are kept for the 232 attacks in
# SLF's sample, in data/slf/attacks.csv.

suppressPackageStartupMessages({library(haven); library(data.table)})
args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 1) stop("Give the path to SLF_replication_upload as the first argument.")
src <- args[1]
dst <- "../data/slf"

files <- c("derived/master.dta", "derived/master_propensity.dta", "derived/municipality_first_terror.dta",
           "raw_processed/election_state.dta", "raw_processed/election_federal.dta", "LICENSE.txt",
           file.path("raw/election_state", list.files(file.path(src, "raw/election_state"), pattern = "^143.*\\.csv$")))
for (f in files) {
  dir.create(dirname(file.path(dst, f)), recursive = TRUE, showWarnings = FALSE)
  stopifnot(file.copy(file.path(src, f), file.path(dst, f), overwrite = TRUE))
}

# Attack list: same selection as SLF's 4_merging_terror.do (attacks from 2010, Berlin state code excluded,
# one row per municipality, year and event)
t <- as.data.table(read_dta(file.path(src, "raw_processed/terror_raw.dta")))
t <- t[attack_dum == 1 & year >= 2010 & code != 11000000]
t <- unique(t, by = c("code", "year", "eventid"))
t[, date := fifelse(!is.na(success_date), success_date, failure_date)]
a <- t[, .(id = code, municipality = city_shp, date = as.Date(date), success = treated)][order(id, date)]
fwrite(a, file.path(dst, "attacks.csv"))
cat("Copied", length(files), "files; attacks.csv has", nrow(a), "rows\n")
