# Data errors documented in Section 3 and Appendix A.
#  A. Postal-vote coverage of the Regional Database state-election files (tables 143xx-01-03): turnout
#     shortfall of summed municipal voters relative to the state total, by state and election.
#  B. Package values for the two control municipalities (Table 4): Kremmen and the five
#     municipalities of constituency Oberhavel I (2014, 2019); Ludwigshafen (2016, 2021).
#  C. State, pre- and post-attack elections of the municipalities informative for state elections.
#  D. 2017 federal election: eligible voters in attacked municipalities and in total.
#  E. Separately collected 2021 state-election results: Berlin districts and Saxony-Anhalt.
#  F. Missing elections: Baden-Wuerttemberg 2021, AfD in Schleswig-Holstein 2017, Artern/Unstrut 2019.
suppressPackageStartupMessages({library(haven); library(data.table)})
D <- "../data/slf"

# ---- A. Postal-vote coverage ----
rows <- list()
for (f in list.files(file.path(D, "raw/election_state"), pattern = "^143.*\\.csv$", full.names = TRUE)) {
  p <- strsplit(readLines(f, warn = FALSE), ";", fixed = TRUE)
  p <- p[vapply(p, function(x) length(x) >= 6 && grepl("^\\d\\d\\.\\d\\d\\.\\d{4}$", x[1]), logical(1))]
  d <- rbindlist(lapply(p, function(x) data.table(date = x[1], code = trimws(x[2]), name = trimws(iconv(x[3], "latin1", "UTF-8")),
                                                   elig = suppressWarnings(as.numeric(x[4])),
                                                   turnout = suppressWarnings(as.numeric(sub(",", ".", x[5]))))))
  d <- d[!is.na(elig) & !is.na(turnout)]
  d[, voters := elig * turnout / 100]
  for (dt in unique(d$date)) {
    g <- d[date == dt]; tot <- g[nchar(code) == 2]
    if (!nrow(tot)) next
    gem <- g[nchar(code) == 8]
    kfs <- g[nchar(code) == 5 & grepl("Kreisfreie Stadt", name) & !(code %in% substr(gem$code, 1, 5))]
    low <- rbind(gem, kfs)
    if (!nrow(low)) next                       # city-states
    rows[[length(rows) + 1]] <- data.table(table = substr(basename(f), 1, 5), state = tot$name[1], date = dt,
      state_turnout = tot$turnout[1], muni_turnout = 100 * sum(low$voters) / sum(low$elig),
      eligible_ratio = sum(low$elig) / tot$elig[1], municipalities = nrow(low))
  }
}
pc <- rbindlist(rows)[, `:=`(gap_pp = state_turnout - muni_turnout, year = as.integer(substr(date, 7, 10)))]
cat("A. Turnout shortfall of municipal sums relative to state totals (percentage points), elections from 2010:\n")
print(pc[year >= 2010][order(state, year), .(state, year, state_turnout, muni_turnout = round(muni_turnout, 1),
                                             gap_pp = round(gap_pp, 1), eligible_ratio = round(eligible_ratio, 3))], nrows = 200)

# ---- B. Control municipalities in the package ----
e <- as.data.table(read_dta(file.path(D, "raw_processed/election_state.dta")))
oh1 <- c(12065136, 12065165, 12065198, 12065251, 12065332)   # Hennigsdorf, Kremmen, Loewenberger Land, Oberkraemer, Velten
b <- e[id %in% oh1 & election_year_land %in% c(2014, 2019)]
cat("\nB. Kremmen (12065165), package values:\n")
print(b[id == 12065165, .(year = election_year_land, eligible_land, turnout_land, afd_share = round(afd_land / valid_land, 3))])
cat("Constituency Oberhavel I (sum over its five municipalities), package values:\n")
print(b[, .(voters = round(sum(eligible_land * turnout_land)), eligible = sum(eligible_land),
            turnout = round(sum(eligible_land * turnout_land) / sum(eligible_land), 3)), by = .(year = election_year_land)])
cat("Ludwigshafen (7314000), package values:\n")
print(e[id == 7314000 & election_year_land %in% c(2016, 2021),
        .(year = election_year_land, name, eligible_land, turnout_land = round(turnout_land, 3), valid_land, afd_land,
          share_afd_land = round(share_afd_land, 3))])

# ---- C. Informative municipalities in state elections ----
m <- as.data.table(read_dta(file.path(D, "derived/master.dta")))
m[, land := floor(id / 1e6)]
s <- m[!is.na(success) & election_type == 3 & !is.na(share_afd) & !is.na(year)]
repeat { n0 <- nrow(s); s <- s[, if (.N > 1) .SD, by = id][, if (.N > 1) .SD, by = year]; if (nrow(s) == n0) break }
inf <- s[, .(n = .N, np = sum(post_election), success = success[1], land = land[1],
             pre = paste(year[post_election == 0], collapse = ","), post = paste(year[post_election == 1], collapse = ",")),
         by = id][np > 0 & np < n]
cat("\nC. Municipalities informative for state elections (AfD sample), by state code and election years:\n")
print(inf[, .N, by = .(success, land, pre, post)][order(-success, land)])
cat("By state (successful attacks):\n"); print(inf[success == 1, .N, by = land][order(land)])

# ---- D. 2017 federal election ----
cat("\nD. Federal elections: mean eligible voters (thousands) in attacked municipalities, and total over all municipalities:\n")
print(m[!is.na(success) & election_type == 1 & year %in% c(2013, 2017, 2021), .(attacked = .N, mean_eligible_000 = round(mean(eligible, na.rm = TRUE), 2)), by = year])
f <- as.data.table(read_dta(file.path(D, "raw_processed/election_federal.dta")))
print(f[, .(municipalities = .N, total_eligible = sum(eligible, na.rm = TRUE)), by = year][order(year)])

# ---- E. 2021 state-election results ----
cat("\nE. Berlin (11) and Saxony-Anhalt (15), 2016 vs 2021: eligible voters and aggregate turnout in the package:\n")
x <- e[floor(id / 1e6) %in% c(11, 15) & election_year_land %in% c(2016, 2021) & !is.na(eligible_land)]
print(x[, .(units = .N, eligible = sum(eligible_land), turnout = round(sum(turnout_land * eligible_land) / sum(eligible_land), 3)),
        by = .(land = floor(id / 1e6), year = election_year_land)][order(land, year)])
print(x[floor(id / 1e6) == 11, .(id, name, year = election_year_land, eligible_land, turnout_land = round(turnout_land, 3))][order(id, year)])

# ---- F. Missing elections ----
cat("\nF. State-election rows by state and year (from 2013):\n")
e[, land := floor(id / 1e6)]
print(dcast(e[election_year_land >= 2013, .N, by = .(land, election_year_land)], land ~ election_year_land, value.var = "N", fill = 0))
cat("Schleswig-Holstein 2017 rows with an AfD share:", e[land == 1 & election_year_land == 2017 & !is.na(share_afd_land), .N],
    "of", e[land == 1 & election_year_land == 2017, .N], "\n")
cat("Artern/Unstrut (16065002) state elections:\n")
print(m[id == 16065002 & election_type == 3, .(year, share_afd, turnout)])
