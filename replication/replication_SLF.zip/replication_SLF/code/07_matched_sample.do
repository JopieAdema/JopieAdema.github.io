* Table 7: SLF's propensity-matched comparison (their Table 3, column 3): successfully attacked
* versus matched untargeted municipalities, state-election coefficient.
* Column 1: SLF's pooled model (AfD vote share; turnout from 2013).
* Column 2: state elections only, municipality and state-by-year fixed effects.
clear all
set more off
global fe i.year i.id#i.election_type i.election_type#i.year

use "../data/slf/derived/master_propensity.dta", clear
keep if matched_sample_success==1
forvalues t = 1/3 {
	gen p`t'  = post_election*(election_type==`t')
	gen sp`t' = new_success*post_election*(election_type==`t')
}
qui reghdfe share_afd sp1 sp2 sp3 p1 p2 p3, a($fe) cluster(id)
di "RESULT column 1 AfD: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
* matched municipalities observed before and after the assigned attack date (state elections)
gen byte s = e(sample)
preserve
keep if s==1 & election_type==3
bysort id: egen npost = total(post_election)
bysort id: gen nobs = _N
bysort id: gen first = _n==1
gen switcher = npost>0 & npost<nobs
tab new_success switcher if first
restore
preserve
keep if year>=2013
qui reghdfe turnout sp1 sp2 sp3 p1 p2 p3, a($fe) cluster(id)
di "RESULT column 1 turnout: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
restore

keep if election_type==3
qui reghdfe share_afd sp3 post_election, a(id i.land#i.year) cluster(id)
di "RESULT column 2 AfD: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
keep if year>=2013
qui reghdfe turnout sp3 post_election, a(id i.land#i.year) cluster(id)
di "RESULT column 2 turnout: " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
