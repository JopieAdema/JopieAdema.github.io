# Appendix figure: raw mean AfD vote shares by event time (SLF's event-time definition: elections of all types
# counted relative to the first election after the first attack), for successfully attacked and failed-attack
# municipalities. Styled like the main event-study figure (09_eventstudy_figure.R).
suppressPackageStartupMessages({library(haven); library(data.table); library(ggplot2)})
root <- ".."
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))
m <- m[!is.na(success) & !is.na(election_date)][order(id, year, election_type)]
m[, period := seq_len(.N), by = id]
m <- merge(m, m[post_election == 1, .(cohort = min(period)), by = id], by = "id", all.x = TRUE)
t <- m[!is.na(cohort) & !is.na(share_afd)]
t[, rel := pmin(pmax(period - cohort, -4), 3)]

a <- t[, .(b = mean(share_afd), se = sd(share_afd) / sqrt(.N), N = .N), by = .(success, rel)]
a[, lo := b - 1.96 * se][, hi := b + 1.96 * se]
a[, spec := factor(ifelse(success == 1, "Successful attack", "Failed attack"), c("Successful attack", "Failed attack"))]
a[, x := rel + ifelse(success == 1, -0.1, 0.1)]
labs <- c("-4" = "-4+", "-3" = "-3", "-2" = "-2", "-1" = "-1", "0" = "0", "1" = "1", "2" = "2", "3" = "3+")
p <- ggplot(a, aes(x, b, colour = spec, shape = spec)) +
  geom_vline(xintercept = -0.5, colour = "grey50", linetype = "dashed") +
  geom_errorbar(aes(ymin = lo, ymax = hi), width = 0.1) + geom_point(size = 2.2) +
  scale_x_continuous(breaks = -4:3, labels = labs) +
  scale_colour_manual(values = c("#1f4e79", "#c0504d")) +
  labs(x = "Elections relative to first attack", y = "Mean AfD vote share", colour = NULL, shape = NULL) +
  theme_bw(base_size = 11) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
ggsave(file.path(root, "output/eventstudy_rawmeans.pdf"), p, width = 6.5, height = 3.6)
ggsave(file.path(root, "output/eventstudy_rawmeans.png"), p, width = 6.5, height = 3.6, dpi = 200)
print(a[order(success, rel), .(success, rel, b = round(b, 3), lo = round(lo, 3), hi = round(hi, 3), N)])
