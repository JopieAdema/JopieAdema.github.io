# Table 5: balance of municipalities with successful vs only failed attacks on fixed-date baseline characteristics
# (2013 federal election and 2012 municipal statistics, i.e. the same date for every municipality),
# with randomization-inference p-values that respect the 113 vs 11 split. Panel B lists the two
# informative state-election controls next to the 35 informative successfully attacked municipalities.

suppressPackageStartupMessages({library(haven); library(data.table); library(sandwich); library(lmtest)})
set.seed(20261111)
root <- ".."
m <- as.data.table(read_dta(file.path(root, "data/slf/derived/master.dta")))

# State-level AfD share in the 2013 federal election (all municipalities, vote-weighted)
m[, land := floor(id / 1e6)]                 # state code from the municipality key
f13 <- m[election_type == 1 & year == 2013 & !is.na(share_afd)]
state_afd <- f13[!is.na(turnout) & !is.na(eligible), .(state_afd13 = sum(share_afd * turnout * eligible) / sum(turnout * eligible)), by = land]
print(state_afd[order(land)])

att <- m[!is.na(success), .(success = max(success), land = max(land), east = max(east, na.rm = TRUE),
                              free_city = max(free_city, na.rm = TRUE), share_nsdap33 = max(share_nsdap33, na.rm = TRUE)), by = id]
fed <- f13[id %in% att$id, .(id, afd13 = share_afd, turnout13 = turnout, eligible13 = eligible)]
s12 <- unique(m[year == 2012 & id %in% att$id, .(id, pop12 = population / 1000, income12 = income_pc,
                                                  unemp12 = unemployed * 1e6 / population)], by = "id")
b <- Reduce(function(x, y) merge(x, y, by = "id", all.x = TRUE), list(att, fed, s12))
b <- merge(b, state_afd, by = "land", all.x = TRUE)

vars <- c(afd13 = "AfD vote share, federal election 2013",
          state_afd13 = "AfD vote share in the state, federal election 2013",
          turnout13 = "Turnout, federal election 2013",
          eligible13 = "Eligible voters, 2013 (000s)",
          pop12 = "Population, 2012 (000s)",
          east = "East Germany",
          free_city = "Urban district (kreisfreie Stadt)",
          share_nsdap33 = "NSDAP vote share, 1933",
          income12 = "Income per capita, 2012",
          unemp12 = "Unemployed per 1,000 inhabitants, 2012")

ri <- function(y, d, R = 10000) {
  d <- d[!is.na(get(y))]; obs <- d[success == 1, mean(get(y))] - d[success == 0, mean(get(y))]
  sims <- replicate(R, { s <- sample(d$success); mean(d[[y]][s == 1]) - mean(d[[y]][s == 0]) })
  mean(abs(sims) >= abs(obs))
}
rows <- rbindlist(lapply(names(vars), function(v) {
  d <- b[!is.na(get(v))]
  fit <- lm(as.formula(paste(v, "~ success")), data = d)
  data.table(variable = vars[[v]], mean_succ = d[success == 1, mean(get(v))], mean_fail = d[success == 0, mean(get(v))],
             diff = coef(fit)[2], p_robust = coeftest(fit, vcov = vcovHC(fit, "HC2"))[2, 4], p_ri = ri(v, d),
             n_succ = d[success == 1, .N], n_fail = d[success == 0, .N])
}))
print(rows[, lapply(.SD, function(x) if (is.numeric(x)) round(x, 3) else x)])

# Panel B: the 35 informative successfully attacked municipalities (state elections) vs Ludwigshafen and Kremmen
# replicate reghdfe's iterative singleton removal in the state-election sample (municipality and year cells)
s3 <- m[!is.na(success) & election_type == 3 & !is.na(share_afd) & !is.na(year)]
repeat { n0 <- nrow(s3); s3 <- s3[, if (.N > 1) .SD, by = id][, if (.N > 1) .SD, by = year]; if (nrow(s3) == n0) break }
st <- s3[, .(n = .N, np = sum(post_election)), by = .(id, success)]
inf35 <- st[success == 1 & np > 0 & np < n, id]
pb <- rbindlist(lapply(names(vars), function(v) data.table(variable = vars[[v]],
  mean_inf_succ = b[id %in% inf35, mean(get(v), na.rm = TRUE)],
  ludwigshafen = b[id == 7314000, get(v)], kremmen = b[id == 12065165, get(v)])))
cat("\nInformative successful (state):", length(inf35), "\n")
print(pb[, lapply(.SD, function(x) if (is.numeric(x)) round(x, 3) else x)])
fwrite(rows, file.path(root, "output/balance_panelA.csv")); fwrite(pb, file.path(root, "output/balance_panelB.csv"))
