* Table 2: SLF's model with the post-attack terms entered explicitly. sp3 is SLF's coefficient
* (their Table 2, column 1, and Figure 5); p3 is the post-attack change in failed-attack municipalities,
* sp3 + p3 the post-attack change in successfully attacked municipalities.
* Also: the attack-date coding check reported in Section 3 and the Appendix (Reproduction paragraph).
clear all
set more off
use "../data/slf/derived/master.dta", clear
global fe i.year i.id#i.election_type i.election_type#i.year
forvalues t = 1/3 {
	gen p`t'  = post_election*(election_type==`t')
	gen sp`t' = success*post_election*(election_type==`t')
}

* AfD vote share
reghdfe share_afd sp1 sp2 sp3 p1 p2 p3, a($fe) cluster(id)
di "RESULT AfD difference (SLF): " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
di "RESULT AfD failed attacks:   " %7.4f _b[p3] " (" %6.4f _se[p3] ")"
lincom sp3 + p3
di "RESULT AfD successful attacks: " %7.4f r(estimate) " (" %6.4f r(se) ")"

* Turnout, elections from 2013, as in SLF's figure4.do (which also adds i.id; redundant)
preserve
keep if year>=2013
reghdfe turnout sp1 sp2 sp3 p1 p2 p3, a(i.id $fe) cluster(id)
di "RESULT turnout difference (SLF): " %7.4f _b[sp3] " (" %6.4f _se[sp3] ")"
di "RESULT turnout failed attacks:   " %7.4f _b[p3] " (" %6.4f _se[p3] ")"
lincom sp3 + p3
di "RESULT turnout successful attacks: " %7.4f r(estimate) " (" %6.4f r(se) ")"
restore

* Failed-attack municipalities in state elections from 2013: raw values
preserve
keep if election_type==3 & year>=2013 & success==0
list id land year post_election share_afd turnout, sepby(id) noobs
restore

* Attack-date coding: SLF date the first attack from the first failed attack in municipalities with an
* earlier successful one. Recode POST from the earliest attack and re-estimate.
merge m:1 id using "../data/slf/derived/municipality_first_terror.dta", keepusing(date_success date_fail) nogen keep(master match)
gen date_first = min(date_success, date_fail)
gen byte recoded = date_first != date_attack & !missing(date_attack)
egen tag = tag(id)
count if recoded & tag
di "RESULT municipalities with recoded first-attack date: " r(N)
gen post_fix = (date_first < election_date) if election_date!=.
forvalues t = 1/3 {
	gen pf`t'  = post_fix*(election_type==`t')
	gen spf`t' = success*post_fix*(election_type==`t')
}
reghdfe share_afd spf1 spf2 spf3 pf1 pf2 pf3, a($fe) cluster(id)
di "RESULT AfD state coefficient with corrected dates: " %7.4f _b[spf3] " (" %6.4f _se[spf3] ")"
