
*VERY SLOW because we use Conleys to get standard errors:
set seed 1312
global reps 999
*Globals and programs:
{
    *Sets of controls and outcomes:
    global controls_2sls="instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
    global controls_2sls_alt="inst_ind_tc  inst_gdp_tc lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* never_connected "
    global controls_2sls_fd=" inst_ind_c  inst_gdp_c lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*  never_connected"
    local bcand 0

    do ".\code\Conley_x_ols_update.do"
    use ".\data\Zero_Stage.dta", clear
    quietly summarize lnm
    scalar LNM_MEAN = r(mean)
    scalar LNM_SD   = r(sd)

    levelsof lnm, local(lnm_list)
    global LNM_LIST "`lnm_list'"

    global beta_scale = .17195181

}
****************PROGRAMS:***********
{
    capture program drop RIprog
    program define RIprog, rclass
        syntax , SHOCK(string) CONTROLS(string) [BCAND(real 0)] [SAMPLE(string asis)]

        *validate shock type early
        local shock = lower("`shock'")
        if !inlist("`shock'", "normal", "with_replacement", "without_replacement") {
            di as err "Unknown shock type: `shock'"
            exit 198
        }

        *1) Build shocks dataset
        tempfile shocks
        clear
        set obs 7

        gen int decade = 1860 + 10*(_n-1)

        if "`shock'" == "normal" {
            gen double lnm = rnormal(scalar(LNM_MEAN), scalar(LNM_SD))
        }
        else if "`shock'" == "with_replacement" {
            gen double lnm = .
            local n : word count $LNM_LIST
            forvalues i = 1/`=_N' {
                local val : word `=ceil(`n'*runiform())' of $LNM_LIST
                replace lnm = `val' in `i'
            }
        }
        else if "`shock'" == "without_replacement" {
            gen double u = runiform()
            sort u
            drop u

            gen double lnm = .
            local i = 1
            foreach c of global LNM_LIST {
                replace lnm = `c' in `i'
                local ++i
            }
        }

        save `shocks', replace

        *2) First-stage + build instrument panel

        use ".\data\Zero_Stage.dta", clear
        drop lrail_mig lindex_lrail lgdp_dg_lrail lnm
        merge m:1 decade using `shocks', nogen keep(match)

        cap gen double lrail_mig    = lrail*lnm
        cap gen double lindex_lrail = lrail*lindex
        cap gen double lgdp_dg_lrail= lrail*lgdp_dg

        areg fs lfs lrail_mig lindex_lrail lgdp_dg_lrail lrail lpopd lurbd lurbd_lnm d_decade* if sample_2sls==1, absorb(fips) robust

        * instrument components: don’t condition on e(sample)
        gen double instmig = $beta_scale*lrail_mig if e(sample)
        *gen double instmig =  lrail_mig if e(sample)
        label var instmig "Instrument For Immigration Flows"

        gen double instind = lindex_lrail
        *gen double instind = lindex_lrail
        label var instind "Instrument for Industrialization"

        gen double instgdp = lgdp_dg_lrail
        *gen double instgdp = lgdp_dg_lrail
        label var instgdp "Instrument for Business Cycles"

        gen double lrail_IV = lrail  if e(sample)

        keep if inrange(decade,1860,1920) & sample==1
        keep fips decade instmig instind instgdp lrail_IV cohort

        reshape wide instmig instind instgdp lrail_IV, i(fips cohort) j(decade)

        gen time_connected=.
        replace time_connected=. if cohort==0
        replace time_connected=10 if cohort==80
        replace time_connected=20 if cohort==90
        replace time_connected=30 if cohort==100
        replace time_connected=40 if cohort==110
        replace time_connected=50 if cohort==120
        replace time_connected=60 if cohort==130
        replace time_connected=70 if cohort==140
        replace time_connected=80 if cohort==150
        replace time_connected=90 if cohort==160
        replace time_connected=100 if cohort==170
        label var time_connected "Number of Years the County was connected to the Railroad during the period 1860-1920"

        egen temp=rowtotal(instmig1860 instmig1870 instmig1880 instmig1890 instmig1900 instmig1910 instmig1920), missing
        gen inst_mig_tc= temp/time_connected
        label var inst_mig_tc "Instrument Considering Decades of Connection Only"

        gen byte   T_i = !missing(instmig1860)+!missing(instmig1870)+!missing(instmig1880)+ !missing(instmig1890)+!missing(instmig1900)+!missing(instmig1910)+ !missing(instmig1920)

        egen double R_i = rowtotal(lrail_IV*)
        gen  double mu  = R_i/T_i
        gen mu_tc = R_i/time_connected

        egen double instmig_avg = rowmean(instmig*)
        egen double mu_manual = rowmean(lrail_IV*)
        egen double instind_avg = rowmean(instind*)
        egen double instgdp_avg = rowmean(instgdp*)

        tempfile instrument
        save `instrument', replace


        *3) Main data + IV
        use ".\data\workdir\Main_Tables_replic.dta", clear
        drop inst*_avg mu R_i T_i IV_recentered inst_mig_tc instmig*
        merge 1:1 fips_code using `instrument', nogen keep(match) keepusing(inst* mu R_i T_i instmig*)

        *cap reg inc instmig_avg `controls' `sample', robust
        *di _b[instmig_avg]
        *di _b[instmig_avg]/_se[instmig_avg]

        cap keep `sample'
        reghdfe inc         `controls' `sample', resid(y_resid)
        reghdfe foreign_avg `controls' `sample', resid(x_resid)

        *reg foreign_avg instmig_avg `controls' `sample', robust
        *return scalar b_fs = _b[instmig_avg]
        *return scalar t_fs = _b[instmig_avg]/_se[instmig_avg]
        cap reg foreign_avg  `controls' `sample'
        cap predict Y if e(sample), resid 
        cap reg instmig_avg `controls' `sample'
        predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        return scalar b_fs = `r(beta)'
        return scalar t_fs = `r(tstat)'
        return scalar F_fs = `r(tstat)'*`r(tstat)'
        cap drop Y X epsilon window dis1 dis2

        ivreg2 inc (foreign_avg=instmig_avg) `controls' `sample', partial(stid*) robust first
        * first-stage F: ivreg2 commonly stores rk Wald F in e(widstat)
        *capture confirm scalar e(widstat)
        *if _rc==0 return scalar F_fs = e(widstat)
        *else      return scalar F_fs = .
        return scalar b = _b[foreign_avg]
        return scalar t = _b[foreign_avg]/_se[foreign_avg]

        gen IV_recentered = instmig_avg - mu*LNM_MEAN*$beta_scale

        * use BCAND option (default 0)
        gen double T_element = IV_recentered*(y_resid-`bcand'*x_resid) `sample'
        egen double T = total(T_element)
        quietly summarize T
        return scalar T = r(mean)

        *reg inc instmig_avg `controls' `sample', robust
        *return scalar b_rf = _b[instmig_avg]
        *return scalar t_rf = _b[instmig_avg]/_se[instmig_avg]

        cap reg inc `controls' `sample'
        cap predict Y if e(sample), resid 
        cap reg instmig_avg `controls' `sample'
        predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(beta)'
        di `r(tstat)'
        return scalar b_rf = `r(beta)'
        return scalar t_rf = `r(tstat)'
        cap drop Y X epsilon window dis1 dis2

        *Can we show this in an RI framework? -- that it is unlikely that such a strong correlation between T and shock has appeared, NET OF ALL CONTROLS
        reg instmig_avg `controls' cohort `sample', robust
        return scalar b_cohort = _b[cohort]
        return scalar t_cohort = _b[cohort]/_se[cohort]

        reg inst_mig_tc $controls_2sls_alt cohort `sample', robust
        return scalar b_cohort_tc = _b[cohort]
        return scalar t_cohort_tc = _b[cohort]/_se[cohort]

    end

    capture program drop mainprog
    program define mainprog, rclass
        syntax , CONTROLS(string)    [BCAND(real 0)] [SAMPLE(string asis)]

        preserve
        use ".\data\workdir\Main_Tables_replic.dta", clear
        cap reghdfe inc `controls' `sample', resid(y_resid)
        cap reghdfe foreign_avg `controls' `sample', resid(x_resid)
        *
        cap keep `sample'

        *cap reg foreign_avg instmig_avg `controls' `sample', robust
        *global b_fs = _b[instmig_avg]
        *global t_fs = _b[instmig_avg]/_se[instmig_avg]
        cap reg foreign_avg  `controls' `sample'
        cap predict Y if e(sample), resid 
        cap reg instmig_avg `controls' `sample'
        predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        global b_fs = `r(beta)'
        global t_fs = `r(tstat)'
        global F_fs = `r(tstat)'*`r(tstat)'
        cap drop Y X epsilon window dis1 dis2

        cap ivreg2 inc (foreign_avg=instmig_avg)  `controls' `sample', partial(stid*) robust first
        global b = _b[foreign_avg]
        global t = _b[foreign_avg]/_se[foreign_avg]
        
        *global F_fs = e(widstat)

        gen double T_element = IV_recentered*(y_resid-`bcand'*x_resid) `sample'
        egen double T = total(T_element)
        quietly summarize T
        global T = r(mean)

        *cap reg inc instmig_avg `controls' `sample',  robust
        *global b_rf = _b[instmig_avg]
        *global t_rf = _b[instmig_avg]/_se[instmig_avg]
        cap reg inc `controls' `sample'
        cap predict Y if e(sample), resid 
        cap reg instmig_avg `controls' `sample'
        predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        global b_rf = `r(beta)'
        global t_rf = `r(tstat)'
        cap drop Y X epsilon window dis1 dis2

        cap reg instmig_avg `controls' cohort `sample', robust
        global b_cohort = _b[cohort]
        global t_cohort = _b[cohort]/_se[cohort]

        cap reg inst_mig_tc $controls_2sls_alt cohort `sample', robust
        global b_cohort_tc = _b[cohort]
        global t_cohort_tc = _b[cohort]/_se[cohort]


        restore

    end
}
****************SIMULATIONS: ***********
*Figures A6-A9: randomization-inference test-statistic distributions
{
    foreach shocktype in without_replacement normal with_replacement  {
        *-----------------------------*
        * with mu (and no lcohort)
        *-----------------------------*
        {
            simulate t_rf = r(t_rf) T = r(T) t_fs = r(t_fs) b_rf = r(b_rf)  F_fs = r(F_fs), reps($reps) seed(1312): RIprog, shock(`shocktype') controls("$controls_2sls mu") bcand(0)

            local fasuf = cond("`shocktype'"=="without_replacement","FA7",cond("`shocktype'"=="with_replacement","FA8","FA9"))
            mainprog, controls("$controls_2sls mu") bcand(0)

            * Calculate p-value
            count if T > $T
            local share_bigger = `r(N)'/_N
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist T, xline($T) xtitle("Test statistic T", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_T_`shocktype'_`fasuf'.pdf", replace


            * RF beta
            count if b_rf > $b_rf
            local share_bigger = `r(N)'/_N
            local n = cond(missing(r(N)), 0, r(N))
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist b_rf, xline($b_rf) xtitle("{&beta}{sup:RF}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_brf_`shocktype'_`fasuf'.pdf", replace

            * RF t
            count if t_rf > $t_rf
            local share_bigger = `r(N)'/_N

            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist t_rf, xline($t_rf) xtitle("t{sup:RF}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_trf_`shocktype'_`fasuf'.pdf", replace

            * FS t
            count if t_fs > $t_fs
            local share_bigger = `r(N)'/_N

            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist t_fs, xline($t_fs) xtitle("t{sup:FS}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_tfs_`shocktype'_`fasuf'.pdf", replace

            *Reduced form rejection:
            su  t_rf if t_rf>=2
            su  t_rf if t_rf>=2|t_rf<=-2

            tempfile mu_`shocktype'
            save `mu_`shocktype'', replace
        }
    }
    *original spec:
    foreach shocktype in without_replacement {
        *-----------------------------*
        * no mu (but with lcohort)
        *-----------------------------*
        {
            simulate t_rf = r(t_rf) T = r(T) t_fs = r(t_fs) b_rf = r(b_rf)  F_fs = r(F_fs), reps($reps) seed(1312): RIprog, shock(`shocktype') controls("$controls_2sls lcohort") bcand(0)

            mainprog, controls("$controls_2sls lcohort") bcand(0)

            * Calculate p-value
            count if T > $T
            local share_bigger = `r(N)'/_N
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist T, xline($T) xtitle("Test statistic T", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_T_`shocktype'_nomu_lcohort_FA6.pdf", replace

            * RF beta
            count if b_rf > $b_rf
            local share_bigger = `r(N)'/_N
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist b_rf, xline($b_rf) xtitle("{&beta}{sup:RF}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_brf_`shocktype'_nomu_lcohort_FA6.pdf", replace

            * RF t
            count if t_rf > $t_rf
            local share_bigger = `r(N)'/_N
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist t_rf, xline($t_rf) xtitle("t{sup:RF}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_trf_`shocktype'_nomu_lcohort_FA6.pdf", replace

            * FS t
            count if t_fs > $t_fs
            local share_bigger = `r(N)'/_N
            local p_RI = 2*min(`share_bigger', 1-`share_bigger')
            local p_RI_str : display %6.3f `p_RI'
            hist t_fs, xline($t_fs) xtitle("t{sup:FS}", size(large)) ytitle("Density", size(large)) note("p = `p_RI_str'", size(large) position(12)) xlabel(, labsize(large)) ylabel(, labsize(large))
            graph export ".\Manuscript\output_rere\hist_RI_tfs_`shocktype'_nomu_lcohort_FA6.pdf", replace

            tempfile nomu_lc_`shocktype'
            save `nomu_lc_`shocktype'', replace
            su t_rf if t_rf>2
        }
    }
}
*For Tables (14 iterations). Table 1 (6 specs) and Table A6 (5 specs) share one
*postfile/csv export (spec column labels each row) but get separate .smcl/.pdf
*logs, switched below by loop position.
{
    log using .\Manuscript\output_rere\RI_pvals_fragT1, replace
    * machine-readable export (in addition to the logs below):
    tempname ripf
    postfile `ripf' str45 spec double(p_fs p_rf p_2sls) using ".\Manuscript\output_rere\RI_pvals_tmp.dta", replace
    *SPECS listed in table-column order (output reads Table 1 c1-c5 & c7, then Table A6 c1-c5):
    *  Table 1 (main):        lcohort=c1, never_connected=c2, lcohort never_connected=c3,
    *                         cohort never_connected=c4, i.cohort=c5, mu=c7.
    *   (Table 1 c6 = "i.cohort i.decade_railvar" reports only the AR CI, so no RI
    *    p-value is shown for it; that spec is intentionally omitted here.)
    *  Table A6 (county age): cohort=c1, mu cohort=c2, decade_railvar=c3,
    *                         mu decade_railvar=c4, i.decade_railvar=c5.
    local controls `" "lcohort"  "never_connected"  "lcohort never_connected" "cohort never_connected" "i.cohort"  "mu"  "cohort" "mu cohort"  "decade_railvar"  "mu decade_railvar"  "i.decade_railvar" "'
    local idx = 0
    foreach c of local controls {
        local idx = `idx' + 1
        if `idx' == 7 {
            log close
            log using .\Manuscript\output_rere\RI_pvals_fragTA6, replace
        }
        di "`c'"
        simulate  t_rf = r(t_rf) T = r(T) t_fs = r(t_fs), reps($reps) seed(1312): RIprog, shock(without_replacement) controls("$controls_2sls  `c'") bcand(0)
        mainprog, controls("$controls_2sls  `c'") bcand(0)
        di "First stage"
        cap count if t_fs > $t_fs
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_fs = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'
        di "Reduced form"
        cap count if t_rf > $t_rf
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_rf = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'
        di "2SLS"
        cap count if T > $T
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_2sls = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'
        post `ripf' ("`c'") (`p_fs') (`p_rf') (`p_2sls')
    }
    log close
    log using .\Manuscript\output_rere\RI_pvals_fragTA5, replace
    *SPECS -> ever-connected table (Table A5): lcohort=c1 (keeps log(years of rail+1)),
    *  "lon"=c2 (baseline controls only). NOTE: "lon" (longitude) is already in the baseline
    *  controls, so it is collinear and dropped -> effectively baseline-only. An empty string
    *  is NOT used here because it makes "simulate: RIprog" fail with "option not allowed".
    local controls `" "lcohort"  "lon" "'
    foreach c of local controls {
        di "`c'"
        simulate  t_rf = r(t_rf) T = r(T) t_fs = r(t_fs), reps($reps) seed(1312): RIprog, shock(without_replacement) controls("$controls_2sls  `c'") bcand(0)  sample(if !never_connected)
        mainprog, controls("$controls_2sls  `c'") bcand(0)  sample(if !never_connected)

        di "First stage"
        cap count if t_fs > $t_fs
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_fs = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'

        di "Reduced form"
        cap count if t_rf > $t_rf
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_rf = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'
        di "2SLS"
        cap count if T > $T
        local share_bigger = `r(N)'/_N
        local p_RI = 2*min(`share_bigger', 1-`share_bigger')
        local p_2sls = `p_RI'
        local p_RI_str : display %6.3f `p_RI'
        di `p_RI_str'
        local clab = cond("`c'"=="lcohort", "lcohort", "baseline only")
        post `ripf' ("`clab' [ever connected]") (`p_fs') (`p_rf') (`p_2sls')
    }
    postclose `ripf'
    log close
    foreach f in fragT1 fragTA6 fragTA5 {
        translate .\Manuscript\output_rere\RI_pvals_`f'.smcl .\Manuscript\output_rere\RI_pvals_`f'.pdf, replace
    }
    use ".\Manuscript\output_rere\RI_pvals_tmp.dta", clear
    *Combined csv: rows are labeled by "spec" so Table 1, Table A6, and Table A5
    *([ever connected] suffix) rows are all identifiable from one file.
    export delimited using ".\Manuscript\output_rere\RI_pvals_fragT1_TA6_TA5.csv", replace
    erase ".\Manuscript\output_rere\RI_pvals_tmp.dta"
}