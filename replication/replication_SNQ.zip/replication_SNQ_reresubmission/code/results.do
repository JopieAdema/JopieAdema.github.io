****************Preparations:***********
{
    *Globals:
    {
        *Sets of controls and outcomes:
        global controls_ols="foreign_avg instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
        global controls_rf="instmig_avg instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* "
        global controls_2sls="instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
        global controls_noplac="lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
        global outcomes1="inc pov unemp urban educ"
        global outcomes2="lmoutcap1930"

        global controls_2sls_alt="inst_ind_tc  inst_gdp_tc lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* never_connected "
        global controls_2sls_fd=" inst_ind_c  inst_gdp_c lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*  never_connected"
    }
    *Prep: distribution of realized shocks (LNM_MEAN/SD, LNM_LIST used later for
    *the randomization-inference counterfactual shocks; no exhibit here)
    {
        use ".\data\Zero_Stage.dta", clear
        quietly summarize lnm
        scalar LNM_MEAN = r(mean)
        scalar LNM_SD   = r(sd)

        levelsof lnm, local(lnm_list)
        global LNM_LIST "`lnm_list'"
        clear
    }
    *Figure A1: correlation between decadal shocks
    {
        use ".\data\Zero_Stage.dta", clear
        collapse (mean) lnm lindex lgdp_dg, by(decade)

        twoway (scatter lindex lnm , mlabel(decade) mcolor(blue) mlabsize(medlarge)) (lfit lindex lnm,lcolor(blue)), legend(off) xtitle("Decadal migration share", size(large)) ytitle("Log industrialization index", size(large)) xlabel(, labsize(large))  ylabel(, labsize(large))

        graph export ".\Manuscript\output_rere\shock_lindex_lnm_FA1.pdf", replace

        twoway (scatter lgdp_dg lnm , mlabel(decade) mcolor(blue) mlabsize(medlarge)) (lfit lgdp_dg lnm,lcolor(blue)), legend(off) xtitle("Decadal migration share", size(large)) ytitle("GDP growth per decade", size(large)) xlabel(, labsize(large))  ylabel(, labsize(large))
        graph export ".\Manuscript\output_rere\shock_lgdp_dg_lnm_FA1.pdf", replace

        *correlations reported in the note to Figure A2 (the seven decadal shocks):
        corr lnm lindex
        local rho_ind = r(rho)
        corr lnm lgdp_dg
        local rho_gdp = r(rho)
        di as res "FIG A2 NOTE: rho(migration shock, log industrialization index) = " %7.3f `rho_ind'
        di as res "FIG A2 NOTE: rho(migration shock, GDP growth per decade)       = " %7.3f `rho_gdp'

    }
    *zeroth stage aggregation:
    {
        use ".\data\Zero_Stage.dta", clear

        gen cohort_yr = 2000-cohort 
        *here it is recursively defined based on the cohort:
        replace rail = 1 if decade==1920&cohort_yr==1920
        gen decade_rail_old = decade if !missing(rail) 
        bys fips_code: egen decade_railvar_old = min(decade_rail_old)

        *first decade with railway access in the data:
        gen decade_rail1 = decade if rail==1 
        bys fips_code: egen cohort_from_rail = min(decade_rail1)
        replace cohort_from_rail = 2000 if missing(cohort_from_rail)

        areg fs lfs lrail_mig lindex_lrail lgdp_dg_lrail lrail lpopd lurbd lurbd_lnm d_decade* if sample_2sls==1, absorb(fips)  robust
        gen samp = e(sample)
        *Define the beta as original, so all RF estimates align again:
        global beta_scale =_b[lrail_mig]
        global beta_scale_index =_b[lindex_lrail]
        global beta_scale_gdp =_b[lgdp_dg_lrail]
        *this does not make sense, and it causes some observations with missing covariates to be dropped
        gen instmig=  $beta_scale*lrail_mig if e(sample)
        gen instcmig=  $beta_scale*lrail_mig
        label var instmig "Instrument For Immigration Flows"
        gen instind=  $beta_scale_index*lindex_lrail  
        label var instind "Instrument for Industrialization"
        gen instgdp= $beta_scale_gdp*lgdp_dg_lrail  
        label var instgdp "Instrument for Business Cycles"

        *use the e(sample), as the main treatment does
        gen lrail_IV = lrail if e(sample)

        keep if decade>=1860 & decade<=1920 & sample==1

        gen decade_rail_new = decade if !missing(lrail_IV) 
        bys fips_code: egen decade_railvar = min(decade_rail_new)
        replace decade_railvar = decade_railvar-10

        keep fips decade instmig instcmig instind instgdp lrail_IV cohort_from_rail decade_railvar decade_railvar_old lnm
        reshape wide instmig instcmig instind instgdp lrail_IV lnm, i(fips cohort_from_rail decade_railvar decade_railvar_old) j(decade)
        su instmig* lrail_IV* lnm*

        *number of periods with data
        gen T_i = !missing(instmig1860)+!missing(instmig1870)+!missing(instmig1880)+!missing(instmig1890)+!missing(instmig1900)+!missing(instmig1910)+!missing(instmig1920)
        egen R_i = rowtotal(lrail_IV*)
        gen mu = R_i/T_i
        egen instmig_avg=rowmean(instmig*)
        egen instcmig_avg=rowmean(instcmig*)
        egen instind_avg=rowmean(instind*)
        egen instgdp_avg=rowmean(instgdp*)

        *Recentered instrument:
        gen IV_recentered = instmig_avg - mu*LNM_MEAN*$beta_scale 
 
        sort fips
        save ".\data\workdir\Instruments.dta", replace 
    }
    *Merge all:
    {
        use ".\data\Main_Tables.dta", clear
        drop instmig* instind* instgdp*  
        merge 1:1 fips using ".\data\workdir\Instruments.dta", nogen keepusing(inst* IV_recentered cohort_from_rail decade_railvar decade_railvar_old mu R_i T_i lrail_IV*) update replace
        gen muXlnm_mean = mu*LNM_MEAN*$beta_scale 

        gen state_fips = floor(fips / 1000)

        gen cohort_yr = 2000-cohort
        label define cohort_yr 2000 "Never", replace
        label values cohort_yr cohort_yr
    
        gen cohort_inv = 1/(cohort+1)

        la var cohort_inv "1/(years of rail+1)"
        la var cohort_yr "Cohort of rail connection"
        la var instmig_avg "Instrument"
        la var instcmig_avg "Corrected instrument"
        la var lcohort "log(Years of rail + 1)"
        la var never_connected "Never connected"
        la var cohort "Years of rail"
        la var cohort_yr "Decade of rail connection"
        la var cohort_from "Decade of rail connection"
        la var decade_railvar "Decade of county establishment"
        la var mu "Expected instrument ($\mu\_i$)"
        la var muXlnm_mean "Expected instrument ($\mu\_i$)"
        la var R_i "Decades of rail connection ($ R\_i$)"
        la var T_i "Decades of county existence ($ T\_i$)"


        label define decade_railvar 1850 "1850 and older" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910"
        label values decade_railvar decade_railvar

        gen years_since_inception =  2000-decade_railvar
        la var years_since_inception "Years of county existence"

        save ".\data\workdir\Main_Tables_replic.dta", replace
    }
}
****************Descriptives:***********
use ".\data\workdir\Main_Tables_replic.dta", clear
{
    *Figure 2: histogram of log(years of rail + 1)
    {
        hist lcohort
        graph export ".\Manuscript\output_rere\hist_lcohort_F2.pdf", replace
        hist cohort_inv
        *graph export ".\Manuscript\output_rere\hist_cohort_inv.pdf", replace  // exploratory: not used in manuscript
    }
    *Figure 3: residualized instrument vs. residualized years of rail
    {

        reghdfe cohort $controls_2sls lcohort, absorb(i.state_fips) resid( resX_lcohort)
        reghdfe cohort $controls_2sls lcohort never_connected, absorb(i.state_fips) resid( resX_lcohort_never)
        reghdfe decade_railvar $controls_2sls lcohort , absorb(i.state_fips) resid( resdecade_railvar_lcohort)
        reghdfe instmig_avg $controls_2sls lcohort, absorb(i.state_fips) resid(resY_lcohort)
        reghdfe instmig_avg , absorb(i.state_fips) resid(resY_none)
        reghdfe instmig_avg $controls_2sls i.cohort, absorb(i.state_fips) resid(resY_cohortFE)
        reghdfe instmig_avg $controls_2sls cohort, absorb(i.state_fips) resid(resY_cohort)
        reghdfe instmig_avg $controls_2sls cohort never_connected, absorb(i.state_fips) resid(resY_cohort_never)
        reghdfe instmig_avg $controls_2sls lcohort never_connected, absorb(i.state_fips) resid(resY_lcohort_never)
        reghdfe instmig_avg $controls_2sls mu, absorb(i.state_fips) resid(resY_mu_test)


        reghdfe lcohort never_connected, noabsorb resid(reslcohort_never)
        scatter reslcohort_never cohort, xtitle("Years of railroad connection",size(medlarge)) ytitle("log(Years of rail + 1) | Never connected ",size(medlarge))
        *graph export ".\Manuscript\output_rere\binscatter_lcohort_never_connected.pdf", replace   // exploratory: not used in manuscript
        xtile bin_IVc = resX_lcohort, nq(20)
        bysort bin_IVc: egen mx_IVc = mean(resX_lcohort)
        bysort bin_IVc: egen my_IVc = mean(resY_lcohort)
        egen tag_IVc = tag(bin_IVc)
        twoway (scatter resY_lcohort resX_lcohort, msymbol(o) msize(vsmall) mcolor(gs10)) ///
               (lfit resY_lcohort resX_lcohort, lcolor(maroon)) ///
               (scatter my_IVc mx_IVc if tag_IVc, msymbol(O) msize(small) mcolor(navy)), ///
               xtitle("Residualized years of rail", size(medlarge)) ///
               ytitle("Residualized instrument", size(medlarge)) ///
               legend(order(3 "Binned means" 2 "Linear fit" 1 "Observations") pos(6) rows(1))
        graph export ".\Manuscript\output_rere\binscatter_IV_cohort_lcohort_new_F3.pdf", replace
        drop bin_IVc mx_IVc my_IVc tag_IVc

    }
    *Figures A3/A4: residualized instrument by cohort / decade of establishment
    {
        egen sd_resY_none = sd(resY_none)
        egen sd_resY_cohortFE = sd(resY_cohortFE)
        egen sd_resY_lcohort = sd(resY_lcohort)
        egen sd_resY_cohort = sd(resY_cohort)
        egen sd_resY_cohort_never = sd(resY_cohort_never)
        egen sd_resY_resY_lcohort_never = sd(resY_lcohort_never)
        egen sd_resY_resY_mu_test = sd(resY_mu_test)
        replace resY_none = resY_none/sd_resY_none
        replace resY_cohortFE = resY_cohortFE/sd_resY_cohortFE
        replace resY_lcohort = resY_lcohort/sd_resY_lcohort
        replace resY_cohort = resY_cohort/sd_resY_cohort
        replace resY_cohort_never = resY_cohort_never/sd_resY_cohort_never
        replace resY_lcohort_never = resY_lcohort_never/sd_resY_resY_lcohort_never
        replace resY_mu_test = resY_mu_test/sd_resY_resY_mu_test
        bys cohort_yr: gen N = _N
        gen N_1000 = N/1000

        corr  resY_lcohort cohort_yr if cohort!=0
        local rho_A = round(r(rho), .001)
        corr  resY_lcohort_never  cohort_yr if cohort!=0
        local rho_B = round(r(rho), .001)
        corr  resY_cohort  cohort_yr if cohort!=0
        local rho_C = round(r(rho), .001)
        corr  resY_cohort_never  cohort_yr if cohort!=0
        local rho_D = round(r(rho), .001)
        corr  resY_mu_test  cohort_yr if cohort!=0
        local rho_E = round(r(rho), .001)

        graph bar resY_lcohort resY_lcohort_never resY_cohort resY_cohort_never resY_mu_test N_1000, over(cohort_yr) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "years of rail [{&rho} = `rho_C']") label(4 "years of rail + never connected [{&rho} = `rho_D']") label(5 "Sum of shares [{&rho} = `rho_E']") label(6 "Number of counties [1000s]")) ytitle("Average residual instrument [s.d.]")
        graph export ".\Manuscript\output_rere\bar_residuals_mu_new_FA3.pdf", replace

        reghdfe instmig_avg $controls_2sls i.cohort, absorb(i.state_fips) resid( resY_cohort_FE)
        reghdfe instmig_avg $controls_2sls, absorb(i.state_fips) resid( resY_empty)
        reghdfe instmig_avg , noabs resid( resY_emptiest)
        egen sd_resY_cohort_FE = sd(resY_cohort_FE)
        replace resY_cohort_FE = resY_cohort_FE/sd_resY_cohort_FE
        egen sd_resY_empty = sd(resY_empty)
        replace resY_empty = resY_empty/sd_resY_empty
        egen sd_resY_emptiest = sd(resY_emptiest)
        replace resY_emptiest = resY_emptiest/sd_resY_emptiest
        graph bar  resY_emptiest resY_empty resY_lcohort resY_cohort_FE, over(decade_railvar) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(off)

        corr  resY_lcohort  decade_railvar 
        local rho_A = round(r(rho), .001)
        corr  resY_lcohort_never  decade_railvar  
        local rho_B = round(r(rho), .001)
        corr  resY_cohort  decade_railvar 
        local rho_C = round(r(rho), .001)
        corr  resY_cohort_never  decade_railvar  
        local rho_D = round(r(rho), .001)
        corr  resY_mu_test  decade_railvar  
        local rho_E = round(r(rho), .001)
        corr  resY_cohortFE  decade_railvar  
        local rho_F = round(r(rho), .001)

        bys decade_railvar: gen Nd = _N
        gen Nd_1000 = Nd/1000

        graph bar resY_lcohort resY_lcohort_never resY_cohort resY_cohort_never resY_mu_test Nd_1000, over(decade_railvar) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "years of rail [{&rho} = `rho_C']") label(4 "years of rail + never connected [{&rho} = `rho_D']") label(5 "Sum of shares [{&rho} = `rho_E']") label(6 "Number of counties [1000s]")) ytitle("Average residual instrument [s.d.]")
        graph export ".\Manuscript\output_rere\bar_residuals_inception_mu_new_FA4.pdf", replace
    }
    *Figures A3/A4 (income panel): same as above with income as the outcome
    {
        gen N_10000 = N/10000
        gen Nd_10000 = Nd/10000
        gen Nd_100000 = Nd/100000


        reghdfe inc $controls_2sls lcohort, absorb(i.state_fips) resid(resI_lcohort)
        reghdfe inc $controls_2sls cohort, absorb(i.state_fips) resid(resI_none)
        reghdfe inc $controls_2sls cohort, absorb(i.state_fips) resid(resI_cohort)
        reghdfe inc $controls_2sls cohort never_connected, absorb(i.state_fips) resid(resI_cohort_never)
        reghdfe inc $controls_2sls lcohort never_connected, absorb(i.state_fips) resid(resI_lcohort_never)
        reghdfe inc $controls_2sls mu, absorb(i.state_fips) resid(resI_mu_test)


        egen sd_resI_none = sd(resI_none)
        egen sd_resI_lcohort = sd(resI_lcohort)
        egen sd_resI_cohort = sd(resI_cohort)
        egen sd_resI_cohort_never = sd(resI_cohort_never)
        egen sd_resI_resI_lcohort_never = sd(resI_lcohort_never)
        egen sd_resI_resI_mu_test = sd(resI_mu_test)

        replace resI_none = resI_none/sd_resI_none
        replace resI_lcohort = resI_lcohort/sd_resI_lcohort
        replace resI_cohort = resI_cohort/sd_resI_cohort
        replace resI_cohort_never = resI_cohort_never/sd_resI_cohort_never
        replace resI_lcohort_never = resI_lcohort_never/sd_resI_resI_lcohort_never
        replace resI_mu_test = resI_mu_test/sd_resI_resI_mu_test


        corr  resI_lcohort cohort_yr if cohort!=0
        local rho_A = round(r(rho), .001)
        corr  resI_lcohort_never  cohort_yr if cohort!=0
        local rho_B = round(r(rho), .001)
        corr  resI_cohort  cohort_yr if cohort!=0
        local rho_C = round(r(rho), .001)
        corr  resI_cohort_never  cohort_yr if cohort!=0
        local rho_D = round(r(rho), .001)
        corr  resI_mu_test  cohort_yr if cohort!=0
        local rho_E = round(r(rho), .001)

        graph bar resI_lcohort resI_lcohort_never resI_cohort resI_cohort_never resI_mu_test N_1000, over(cohort_yr) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "years of rail [{&rho} = `rho_C']") label(4 "years of rail + never connected [{&rho} = `rho_D']") label(5 "Sum of shares [{&rho} = `rho_E']") label(6 "Number of counties [10,000s]")) ytitle("Average residual income [s.d.]")
        graph export ".\Manuscript\output_rere\bar_residuals_mu_new_income_FA3.pdf", replace


        corr  resI_lcohort  decade_railvar 
        local rho_A = round(r(rho), .001)
        corr  resI_lcohort_never  decade_railvar  
        local rho_B = round(r(rho), .001)
        corr  resI_cohort  decade_railvar 
        local rho_C = round(r(rho), .001)
        corr  resI_cohort_never  decade_railvar  
        local rho_D = round(r(rho), .001)
        corr  resI_mu_test  decade_railvar  
        local rho_E = round(r(rho), .001)



        graph bar resI_lcohort resI_lcohort_never resI_cohort resI_cohort_never resI_mu_test Nd_10000, over(decade_railvar) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "years of rail [{&rho} = `rho_C']") label(4 "years of rail + never connected [{&rho} = `rho_D']") label(5 "Sum of shares [{&rho} = `rho_E']") label(6 "Number of counties [10,000s]")) ytitle("Average residual income [s.d.]")
        graph export ".\Manuscript\output_rere\bar_residuals_inception_mu_new_income_FA4.pdf", replace

    }
    *Figure A12: residualized immigrant share (endogenous X) by decade of establishment
    {
        reghdfe foreign_avg $controls_2sls lcohort, absorb(i.state_fips) resid(resXendo)
        reghdfe foreign_avg $controls_2sls lcohort never_connected, absorb(i.state_fips) resid(resXendo_nc)
        reghdfe foreign_avg $controls_2sls mu, absorb(i.state_fips) resid(resXendo_mu)
        reghdfe foreign_avg $controls_2sls decade_railvar, absorb(i.state_fips) resid(resXendo_est)

        *CHECK: WHY DOES THIS PREDICT PERFECTLY?
        reghdfe foreign_avg $controls_2sls i.decade_railvar, absorb(i.state_fips) resid(resXendo_estfe)



        corr  resXendo  decade_railvar 
        local rho_A = round(r(rho), .001)
        corr  resXendo_nc  decade_railvar  
        local rho_B = round(r(rho), .001)
        corr  resXendo_mu  decade_railvar 
        local rho_C = round(r(rho), .001)
        corr  resXendo_est  decade_railvar  
        local rho_D = round(r(rho), .001)
        corr  resXendo_estfe  decade_railvar  
        local rho_E = round(r(rho), .001)



        graph bar resXendo resXendo_nc resXendo_mu resXendo_est resXendo_estfe Nd_100000 , over(decade_railvar) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "Sum of shares [{&rho} = `rho_C']") label(4 "Decade of establishment [{&rho} = `rho_D']") label(5 "Decade of establishment FE [{&rho} = `rho_E']") label(6 "Number of counties [100,000s]")) ytitle("Average residual immigrant share [pp.]")
        graph export ".\Manuscript\output_rere\bar_residuals_inception_foreign_avg_FA12.pdf", replace



        corr  resXendo cohort_yr if cohort!=0
        local rho_A = round(r(rho), .001)
        corr  resXendo_nc  cohort_yr if cohort!=0
        local rho_B = round(r(rho), .001)
        corr  resXendo_mu  cohort_yr if cohort!=0
        local rho_C = round(r(rho), .001)
        corr  resXendo_est  cohort_yr if cohort!=0
        local rho_D = round(r(rho), .001)
        corr  resXendo_estfe  cohort_yr if cohort!=0
        local rho_E = round(r(rho), .001)

        graph bar resXendo resXendo_nc resXendo_mu resXendo_est resXendo_estfe N_10000 , over(cohort_yr) bar(1, color("198 219 239")) bar(2, color("158 202 225")) bar(3, color("107 174 214")) bar(4, color("49 130 189")) bar(5, color("8 81 156")) bar(6, color("203 24 29")) legend(pos(6) row(6) label(1 "Log(years of rail + 1) [{&rho} = `rho_A']") label(2 "Log(years of rail + 1) + never connected [{&rho} = `rho_B']") label(3 "Sum of shares [{&rho} = `rho_C']") label(4 "Decade of establishment [{&rho} = `rho_D']") label(5 "Decade of establishment FE [{&rho} = `rho_E']") label(6 "Number of counties [10,000s]")) ytitle("Average residual immigrant share [pp.]")
        *graph export ".\Manuscript\output_rere\bar_residuals_foreign_avg.pdf", replace  // exploratory: not used in manuscript




    }
    *Figure A2: instrument and railroad-timing controls by decade of connection
    {
        preserve
        egen instmig_avg_max = max(instmig_avg)
        replace instmig_avg = instmig_avg/instmig_avg_max 
        egen instind_avg_min = min(instind_avg)
        replace instind_avg = instind_avg/instind_avg_min 
        egen instgdp_avg_min = min(instgdp_avg)
        replace instgdp_avg = instgdp_avg/instgdp_avg_min 

        egen inst_mig_tc_max = max(inst_mig_tc)
        replace inst_mig_tc = inst_mig_tc/inst_mig_tc_max 
        egen inst_mig_c_max = max(inst_mig_c)
        replace inst_mig_c = inst_mig_c/inst_mig_c_max 


        egen inst_ind_tc_max = min(inst_ind_tc)
        replace inst_ind_tc = inst_ind_tc/inst_ind_tc_max 

        egen inst_gdp_tc_max = min(inst_gdp_tc)
        replace inst_gdp_tc = inst_gdp_tc/inst_gdp_tc_max 


        egen inst_ind_c_max = max(inst_ind_c)
        replace inst_ind_c = inst_ind_c/inst_ind_c_max 

        egen inst_gdp_c_max = max(inst_gdp_c)
        replace inst_gdp_c = inst_gdp_c/inst_gdp_c_max 


        collapse (mean) instmig_avg inst_mig_tc inst_mig_c instind_avg instgdp_avg inst_ind_tc inst_gdp_tc inst_ind_c inst_gdp_c, by(cohort_yr)

        *drop if cohort_yr==2000
        replace cohort_yr = 1930 if cohort_yr==2000
        label define cohort_yr 1930 "Never", replace
        label values cohort_yr cohort_yr

        twoway (connected instmig_avg cohort_yr, lpattern(solid) lcolor(blue) msymbol(circle)) (connected instgdp_avg cohort_yr, lpattern(dash)  lcolor(red)  msymbol(square))   (connected instind_avg cohort_yr, lpattern(dot)   lcolor(green) msymbol(diamond)), legend(pos(6) order(1 "Instrument" 2 "GDP-railroad control" 3 "Industrialization-railroad control") row(1))   xtitle("Decade of railroad connection")  ytitle("Value (most extreme = 1)") xlabel(1830 "1830" 1840 "1840" 1850 "1850" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910" 1920 "1920"  1930 "Never")
        graph export ".\Manuscript\output_rere\interactions_by_cohort_FA2.pdf", replace

        twoway (connected inst_mig_tc cohort_yr, lpattern(solid) lcolor(blue) msymbol(circle)) (connected inst_mig_c cohort_yr, lpattern(dash)  lcolor(red)  msymbol(square)) , legend(pos(6) order(1 "Average in connected decades" 2 "Immigrant inflow in first connected decade") row(1))   xtitle("Decade of railroad connection")  ytitle("Value (most extreme = 1)") xlabel(1830 "1830" 1840 "1840" 1850 "1850" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910" 1920 "1920"  1930 "Never")
        graph export ".\Manuscript\output_rere\interactions_by_cohort_alt_FA2.pdf", replace

        restore
    }
    *Figures 1 and A5: heatplots of instrument / mu by connection x establishment decade
    {
        gen cohort_from_show = cohort_from_rail
        replace cohort_from_show = 1940 if cohort_from_rail==2000

        heatplot mu decade_railvar_old cohort_from_show, levels(10) color(RdBu) legend(   subtitle("{&mu}{sub:i}")) xbins(10) ybins(7) ytitle("Decade of county establishment") xtitle("Decade of railroad connection") xlabel(1850 "1850 or before" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910" 1920 "1920"  1940 "Never" ,nogrid angle(45)) ylabel(1850 "1850 or before" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910"  ,nogrid)   keylabels(,format(%9.3f) )
        *note("Excludes never-treated counties")
        graph export ".\Manuscript\output_rere\heatplot_mu_FA5.pdf", replace
        heatplot instmig_avg decade_railvar_old cohort_from_show, levels(10) color(RdBu) legend(  subtitle("Instrument")) xbins(10) ybins(7) ytitle("Decade of county establishment") xtitle("Decade of railroad connection") xlabel(1850 "1850 or before" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910" 1920 "1920"  1940 "Never" ,nogrid angle(45)) ylabel(1850 "1850 or before" 1860 "1860" 1870 "1870" 1880 "1880" 1890 "1890" 1900 "1900" 1910 "1910" ,nogrid)  keylabels(,format(%9.3f) )
        graph export ".\Manuscript\output_rere\heatplot_instrument_F1.pdf", replace
    }
    *Table A7: instrument/outcomes regressed on the mu control alone
    {
        eststo clear

        eststo: reg instmig_avg muXlnm_mean,  robust 
        eststo: reg instmig_avg muXlnm_mean $controls_2sls lcohort,  robust 
        eststo: reg foreign_avg muXlnm_mean,  robust 
        eststo: reg foreign_avg muXlnm_mean $controls_2sls lcohort,  robust 
        eststo: reg inc muXlnm_mean,  robust 
        eststo: reg inc muXlnm_mean $controls_2sls lcohort,  robust 
        cap esttab est* using "./Manuscript/output_rere/tab_mu_tiny_fragTA7.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(muXlnm_mean ) order(muXlnm_mean)  stats(N, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" )) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")
    }
}
****************Results:***********
{
    *Table A8 and Figure A11: alternative (cumulative/time-consistent) instruments
    {
        *residuals: although not intended, the correlation is super strong
        reghdfe inst_mig_tc $controls_2sls_alt, absorb(i.state_fips) resid(res_tc_IV)
        reghdfe cohort $controls_2sls_alt, absorb(i.state_fips) resid(res_tc_cohort)    
        xtile bin_tc = res_tc_cohort, nq(20)
        bysort bin_tc: egen mx_tc = mean(res_tc_cohort)
        bysort bin_tc: egen my_tc = mean(res_tc_IV)
        egen tag_tc = tag(bin_tc)
        twoway (scatter res_tc_IV res_tc_cohort, msymbol(o) msize(vsmall) mcolor(gs10)) ///
               (lfit res_tc_IV res_tc_cohort, lcolor(maroon)) ///
               (scatter my_tc mx_tc if tag_tc, msymbol(O) msize(small) mcolor(navy)), ///
               xtitle("Residualized years of rail", size(large)) ytitle("Residualized instrument", size(large)) ///
               ylabel(,labsize(large)) xlabel(,labsize(large)) ///
               legend(order(3 "Binned means" 2 "Linear fit" 1 "Observations") pos(6) rows(1))
        graph export ".\Manuscript\output_rere\binscatter_IV_cohort_tc_FA11.pdf", replace
        drop bin_tc mx_tc my_tc tag_tc

        reghdfe inst_mig_c $controls_2sls_fd, absorb(i.state_fips) resid(res_c_IV)
        reghdfe cohort $controls_2sls_fd, absorb(i.state_fips) resid(res_c_cohort)    
        xtile bin_c = res_c_cohort, nq(20)
        bysort bin_c: egen mx_c = mean(res_c_cohort)
        bysort bin_c: egen my_c = mean(res_c_IV)
        egen tag_c = tag(bin_c)
        twoway (scatter res_c_IV res_c_cohort, msymbol(o) msize(vsmall) mcolor(gs10)) ///
               (lfit res_c_IV res_c_cohort, lcolor(maroon)) ///
               (scatter my_c mx_c if tag_c, msymbol(O) msize(small) mcolor(navy)), ///
               xtitle("Residualized years of rail", size(large)) ytitle("Residualized instrument", size(large)) ///
               ylabel(,labsize(large)) xlabel(,labsize(large)) ///
               legend(order(3 "Binned means" 2 "Linear fit" 1 "Observations") pos(6) rows(1))
        graph export ".\Manuscript\output_rere\binscatter_IV_cohort_c_FA11.pdf", replace
        drop bin_c mx_c my_c tag_c

        eststo clear
        eststo: ivreg2 inc (foreign_avg=inst_mig_c) $controls_2sls_fd ,   partial(stid*) robust first 
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        eststo: ivreg2 inc (foreign_avg=inst_mig_c) inst_ind_c  inst_gdp_c lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*  lcohort,   partial(stid*) robust first 
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        eststo: ivreg2 inc (foreign_avg=inst_mig_c) $controls_2sls_fd lcohort,   partial(stid*) robust first 
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        eststo: ivreg2 inc (foreign_avg=inst_mig_tc)  $controls_2sls_alt ,  cluster(state_fips) first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        eststo: ivreg2 inc (foreign_avg=inst_mig_tc) inst_ind_tc  inst_gdp_tc lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* lcohort ,  cluster(state_fips) first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        eststo: ivreg2 inc (foreign_avg=inst_mig_tc) $controls_2sls_alt lcohort,  cluster(state_fips) first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6

        esttab est4 est5 est6 est1 est2 est3 using "./Manuscript/output_rere/2SLS_altinstruments_fragTA8.tex", b(%9.3f) se(%9.3f)   booktabs fragment replace label keep(foreign_avg )  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic" ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    


    }
    *Table 1 (7 columns) and Table A5 (2 columns), log income per capita only
    *(neither shows an OLS panel). Columns 1-4 use lcohort/never_connected/etc;
    *columns 5-7 use the railroad-timing FE and mu specs. All 7 of Table 1's
    *columns are combined into one eststo group per panel so each fragment file
    *matches the table's actual column count.
    {

        eststo clear
        eststo: reg foreign_avg $controls_rf lcohort,  robust
        eststo: reg foreign_avg $controls_rf never_connected,  robust
        eststo: reg foreign_avg $controls_rf lcohort never_connected,  robust
        eststo: reg foreign_avg $controls_rf never_connected cohort,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls i.cohort,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls i.cohort i.years_since_inception,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls muXlnm_mean,  robust
        esttab est* using "./Manuscript/output_rere/FS_fragT1.tex", b(%9.3f) se(%9.3f) noobs   booktabs fragment replace label keep(instmig_avg)   star(* 0.10 ** 0.05 *** 0.01) nolines prehead( ) posthead( ) prefoot() postfoot( ) nonum nomtitle    eqlabels( " ",none)

        eststo clear
        eststo: reg  instmig_avg $controls_2sls lcohort, robust
        eststo: reg  instmig_avg $controls_2sls never_connected ,  robust
        eststo: reg  instmig_avg $controls_2sls lcohort never_connected ,  robust
        eststo: reg  instmig_avg $controls_2sls never_connected cohort ,  robust
        eststo: reg  instmig_avg $controls_2sls i.cohort ,  robust
        eststo: reg  instmig_avg $controls_2sls i.cohort i.years_since_inception ,  robust
        eststo: reg  instmig_avg $controls_2sls muXlnm_mean ,  robust
        esttab est* using "./Manuscript/output_rere/R2_fragT1.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep( ) order( )   stats(r2, fmt(%9.3fc %9.3fc ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: reg inc $controls_rf lcohort,  robust
        eststo: reg inc $controls_rf never_connected,  robust
        eststo: reg inc $controls_rf lcohort never_connected,  robust
        eststo: reg inc $controls_rf never_connected cohort,  robust
        eststo: reg inc instmig_avg $controls_2sls i.cohort,  robust
        eststo: reg inc instmig_avg $controls_2sls i.cohort i.years_since_inception,  robust
        eststo: reg inc instmig_avg $controls_2sls muXlnm_mean,  robust
        esttab est* using "./Manuscript/output_rere/RF_fragT1.tex", b(%9.3f) se(%9.3f)  booktabs fragment replace label keep(instmig_avg lcohort never_connected cohort)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle  noobs  eqlabels( " ",none)

        eststo clear
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls lcohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls never_connected cohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls i.cohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls i.cohort i.years_since_inception, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls muXlnm_mean, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est7
        esttab est* using "./Manuscript/output_rere/2SLS_fragT1.tex", b(%9.3f) se(%9.3f)   booktabs fragment replace label keep(foreign_avg lcohort never_connected cohort)  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic" ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)

        *Table A5 (ever-connected subsample), columns 1-2:
        eststo clear
        eststo: reg foreign_avg $controls_rf lcohort if !never_connected,  robust
        eststo: reg foreign_avg $controls_rf if !never_connected,  robust
        esttab est* using "./Manuscript/output_rere/FS_fragTA5.tex", b(%9.3f) se(%9.3f) noobs   booktabs fragment replace label keep(instmig_avg)   star(* 0.10 ** 0.05 *** 0.01) nolines prehead( ) posthead( ) prefoot() postfoot( ) nonum nomtitle    eqlabels( " ",none)

        eststo clear
        eststo: reg  instmig_avg $controls_2sls lcohort if !never_connected,  robust
        eststo: reg  instmig_avg $controls_2sls if !never_connected ,  robust
        esttab est* using "./Manuscript/output_rere/R2_fragTA5.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep( ) order( )   stats(r2, fmt(%9.3fc %9.3fc ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: reg inc $controls_rf lcohort if !never_connected,  robust
        eststo: reg inc $controls_rf if !never_connected,  robust
        esttab est* using "./Manuscript/output_rere/RF_fragTA5.tex", b(%9.3f) se(%9.3f)  booktabs fragment replace label keep(instmig_avg lcohort)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle  noobs  eqlabels( " ",none)

        eststo clear
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls lcohort if !never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls if !never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        esttab est* using "./Manuscript/output_rere/2SLS_fragTA5.tex", b(%9.3f) se(%9.3f)   booktabs fragment replace label keep(foreign_avg lcohort)  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic" ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)
    }
    *Table A1 (SNQ Table 4 Column 1, no shift-share-like placebo controls), all 7
    *columns, same specs as Table 1 with $controls_noplac in place of
    *$controls_2sls/$controls_rf. Columns 5-7 were reconstructed (the original
    *code was never saved) and verified against tab_noplac_mod_TA1.tex and
    *conley.do's Conleys_fragTA1 -- both point estimates and Conley SEs/F-stats
    *match to 3 decimals.
    {

        eststo clear
        eststo: reg foreign_avg instmig_avg $controls_noplac lcohort,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac never_connected,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac lcohort never_connected,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac never_connected cohort,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac i.cohort,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac i.cohort i.years_since_inception,  robust
        eststo: reg foreign_avg instmig_avg $controls_noplac muXlnm_mean,  robust
        esttab est* using "./Manuscript/output_rere/FS_fragTA1.tex", b(%9.3f) se(%9.3f) noobs   booktabs fragment replace label keep(instmig_avg)   star(* 0.10 ** 0.05 *** 0.01) nolines prehead( ) posthead( ) prefoot() postfoot( ) nonum nomtitle    eqlabels( " ",none)

        eststo clear
        eststo: reg  instmig_avg $controls_noplac lcohort, robust
        eststo: reg  instmig_avg $controls_noplac never_connected ,  robust
        eststo: reg  instmig_avg $controls_noplac lcohort never_connected ,  robust
        eststo: reg  instmig_avg $controls_noplac never_connected cohort ,  robust
        eststo: reg  instmig_avg $controls_noplac i.cohort ,  robust
        eststo: reg  instmig_avg $controls_noplac i.cohort i.years_since_inception ,  robust
        eststo: reg  instmig_avg $controls_noplac muXlnm_mean ,  robust
        esttab est* using "./Manuscript/output_rere/R2_fragTA1.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep( ) order( )   stats(r2, fmt(%9.3fc %9.3fc ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: reg inc instmig_avg $controls_noplac lcohort,  robust
        eststo: reg inc instmig_avg $controls_noplac never_connected,  robust
        eststo: reg inc instmig_avg $controls_noplac lcohort never_connected,  robust
        eststo: reg inc instmig_avg $controls_noplac never_connected cohort,  robust
        eststo: reg inc instmig_avg $controls_noplac i.cohort,  robust
        eststo: reg inc instmig_avg $controls_noplac i.cohort i.years_since_inception,  robust
        eststo: reg inc instmig_avg $controls_noplac muXlnm_mean,  robust
        esttab est* using "./Manuscript/output_rere/RF_fragTA1.tex", b(%9.3f) se(%9.3f)  booktabs fragment replace label keep(instmig_avg lcohort never_connected cohort)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle  noobs  eqlabels( " ",none)

        eststo clear
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac lcohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac lcohort never_connected, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac never_connected cohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac i.cohort, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac i.cohort i.years_since_inception, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_noplac muXlnm_mean, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est7
        esttab est* using "./Manuscript/output_rere/2SLS_fragTA1.tex", b(%9.3f) se(%9.3f)   booktabs fragment replace label keep(foreign_avg lcohort never_connected cohort)  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic" ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)
    }
    *Table A6, columns 1-5 (cohort, mu+cohort, years_since_inception,
    *mu+years_since_inception, i.years_since_inception). Verified against the
    *manuscript to 3 decimals.
    {

        eststo clear
        eststo: reg  instmig_avg $controls_2sls cohort ,  robust
        eststo: reg  instmig_avg $controls_2sls muXlnm_mean cohort ,  robust
        eststo: reg  instmig_avg $controls_2sls years_since_inception ,  robust
        eststo: reg  instmig_avg $controls_2sls muXlnm_mean years_since_inception ,  robust
        eststo: reg  instmig_avg $controls_2sls i.years_since_inception ,  robust
        esttab est* using "./Manuscript/output_rere/R2_fragTA6.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep( ) order( )   stats(r2, fmt(%9.3fc %9.3fc ))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls  cohort , partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls muXlnm_mean  cohort , partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls  years_since_inception , partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls muXlnm_mean  years_since_inception , partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls  i.years_since_inception, partial(stid*) robust first
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        esttab est* using "./Manuscript/output_rere/2SLS_fragTA6.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg ) order(foreign_avg )  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic" )) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: reg foreign_avg instmig_avg $controls_2sls cohort ,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls muXlnm_mean cohort ,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls years_since_inception ,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls muXlnm_mean years_since_inception ,  robust
        eststo: reg foreign_avg instmig_avg $controls_2sls i.years_since_inception ,  robust
        esttab est* using "./Manuscript/output_rere/FS_fragTA6.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(instmig_avg ) order(instmig_avg )  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")

        eststo clear
        eststo: reg inc instmig_avg $controls_2sls  cohort ,  robust
        eststo: reg inc instmig_avg $controls_2sls muXlnm_mean cohort ,  robust
        eststo: reg inc instmig_avg $controls_2sls  years_since_inception ,  robust
        eststo: reg inc instmig_avg $controls_2sls muXlnm_mean years_since_inception ,  robust
        eststo: reg inc instmig_avg $controls_2sls  i.years_since_inception ,  robust
        esttab est* using "./Manuscript/output_rere/RF_fragTA6.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(instmig_avg ) order(instmig_avg )  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    substitute ("\_" "_")
    }
    *Tables A2 and A3 (Panels A/B/C = OLS/RF/2SLS, two specs per outcome)
    {
        *Table A2 (inc, pov, unemp, urban, educ):
        eststo clear
        cap eststo: reg inc $controls_ols lcohort,  robust 
        cap eststo: reg inc $controls_ols lcohort never_connected,  robust 
        cap eststo: reg pov $controls_ols lcohort,  robust 
        cap eststo: reg pov $controls_ols lcohort never_connected,  robust 
        cap eststo: reg unemp $controls_ols lcohort,  robust 
        cap eststo: reg unemp $controls_ols lcohort never_connected,  robust 
        cap eststo: reg urban $controls_ols lcohort,  robust 
        cap eststo: reg urban $controls_ols lcohort never_connected,  robust 
        cap eststo: reg educ $controls_ols lcohort,  robust 
        cap eststo: reg educ $controls_ols lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T4A_fragTA2.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: reg inc $controls_rf lcohort ,  robust 
        cap eststo: reg inc $controls_rf lcohort never_connected,  robust 
        cap eststo: reg pov $controls_rf lcohort ,  robust 
        cap eststo: reg pov $controls_rf lcohort never_connected,  robust 
        cap eststo: reg unemp $controls_rf lcohort ,  robust 
        cap eststo: reg unemp $controls_rf lcohort never_connected,  robust 
        cap eststo: reg urban $controls_rf lcohort ,  robust 
        cap eststo: reg urban $controls_rf lcohort never_connected,  robust 
        cap eststo: reg educ $controls_rf lcohort ,  robust 
        cap eststo: reg educ $controls_rf lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T4B_fragTA2.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(instmig_avg)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        cap eststo: ivreg2 inc (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        cap eststo: ivreg2 pov (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        cap eststo: ivreg2 pov (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        cap eststo: ivreg2 unemp (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        cap eststo: ivreg2 unemp (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6
        cap eststo: ivreg2 urban (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est7
        cap eststo: ivreg2 urban (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est8
        cap eststo: ivreg2 educ (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est9
        cap eststo: ivreg2 educ (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est10
        cap esttab est* using "./Manuscript/output_rere/T4C_fragTA2.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg)  stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic"))  star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    

        *Table A3 (sk_norm, vote, crime outcomes):
        eststo clear
        cap eststo: reg sk_norm $controls_ols lcohort ,  robust 
        cap eststo: reg sk_norm $controls_ols lcohort never_connected,  robust 
        cap eststo: reg vote $controls_ols lcohort ,  robust 
        cap eststo: reg vote $controls_ols lcohort never_connected,  robust 
        cap eststo: reg total_crime $controls_ols lcohort ,  robust 
        cap eststo: reg total_crime $controls_ols lcohort never_connected,  robust 
        cap eststo: reg crime_personcap $controls_ols lcohort ,  robust 
        cap eststo: reg crime_personcap $controls_ols lcohort never_connected,  robust 
        cap eststo: reg crime_propertycap $controls_ols lcohort ,  robust 
        cap eststo: reg crime_propertycap $controls_ols lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T5A_fragTA3.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg )  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: reg sk_norm $controls_rf lcohort ,  robust 
        cap eststo: reg sk_norm $controls_rf lcohort never_connected,  robust 
        cap eststo: reg vote $controls_rf lcohort ,  robust 
        cap eststo: reg vote $controls_rf lcohort never_connected,  robust 
        cap eststo: reg total_crime $controls_rf lcohort ,  robust 
        cap eststo: reg total_crime $controls_rf lcohort never_connected,  robust 
        cap eststo: reg crime_personcap $controls_rf lcohort ,  robust 
        cap eststo: reg crime_personcap $controls_rf lcohort never_connected,  robust 
        cap eststo: reg crime_propertycap $controls_rf lcohort ,  robust 
        cap eststo: reg crime_propertycap $controls_rf lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T5B_fragTA3.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(instmig_avg)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: ivreg2 sk_norm (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        cap eststo: ivreg2 sk_norm (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        cap eststo: ivreg2 vote (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        cap eststo: ivreg2 vote (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        cap eststo: ivreg2 total_crime (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        cap eststo: ivreg2 total_crime (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6
        cap eststo: ivreg2 crime_personcap (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est7
        cap eststo: ivreg2 crime_personcap (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est8
        cap eststo: ivreg2 crime_propertycap (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est9
        cap eststo: ivreg2 crime_propertycap (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est10 
        cap esttab est* using "./Manuscript/output_rere/T5C_fragTA3.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg) stats(N Fstat, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" "First stage F-statistic")) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    



    }
    *Table A4 (manufacturing outcomes, sample_manuf==1; Panels A/B/C = OLS/RF/2SLS)
    {
        preserve
        keep if sample_manuf==1

        eststo clear
        cap eststo: reg lmoutcap1860_1920 $controls_ols lcohort,  robust 
        cap eststo: reg lmoutcap1860_1920 $controls_ols lcohort never_connected,  robust 
        cap eststo: reg lmoutcap1930 $controls_ols lcohort ,  robust 
        cap eststo: reg lmoutcap1930 $controls_ols lcohort never_connected,  robust 
        cap eststo: reg lmoutestb1860_1920 $controls_ols lcohort ,  robust 
        cap eststo: reg lmoutestb1860_1920 $controls_ols lcohort never_connected,  robust 
        cap eststo: reg lmoutestb1930 $controls_ols lcohort ,  robust 
        cap eststo: reg lmoutestb1930 $controls_ols lcohort never_connected,  robust 
        cap eststo: reg lnb_estabt1860_1920 $controls_ols lcohort ,  robust 
        cap eststo: reg lnb_estabt1860_1920 $controls_ols lcohort never_connected,  robust 
        cap eststo: reg lnb_estabt1930 $controls_ols lcohort ,  robust 
        cap eststo: reg lnb_estabt1930 $controls_ols lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T6A_fragTA4.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: reg lmoutcap1860_1920 $controls_rf lcohort ,  robust 
        cap eststo: reg lmoutcap1860_1920 $controls_rf lcohort never_connected,  robust 
        cap eststo: reg lmoutcap1930 $controls_rf lcohort ,  robust 
        cap eststo: reg lmoutcap1930 $controls_rf lcohort never_connected,  robust 
        cap eststo: reg lmoutestb1860_1920 $controls_rf lcohort ,  robust 
        cap eststo: reg lmoutestb1860_1920 $controls_rf lcohort never_connected,  robust 
        cap eststo: reg lmoutestb1930 $controls_rf lcohort ,  robust 
        cap eststo: reg lmoutestb1930 $controls_rf lcohort never_connected,  robust 
        cap eststo: reg lnb_estabt1860_1920 $controls_rf lcohort ,  robust 
        cap eststo: reg lnb_estabt1860_1920 $controls_rf lcohort never_connected,  robust 
        cap eststo: reg lnb_estabt1930 $controls_rf lcohort ,  robust 
        cap eststo: reg lnb_estabt1930 $controls_rf lcohort never_connected,  robust 
        cap esttab est* using "./Manuscript/output_rere/T6B_fragTA4.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(instmig_avg)  sfmt(%9.3f %15s %15s %15s 0 0 0 0 0) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    noobs
        eststo clear
        cap eststo: ivreg2 lmoutcap1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est1
        cap eststo: ivreg2 lmoutcap1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est2
        cap eststo: ivreg2 lmoutcap1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est3
        cap eststo: ivreg2 lmoutcap1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est4
        cap eststo: ivreg2 lmoutestb1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est5
        cap eststo: ivreg2 lmoutestb1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est6
        cap eststo: ivreg2 lmoutestb1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est7
        cap eststo: ivreg2 lmoutestb1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est8
        cap eststo: ivreg2 lnb_estabt1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est9
        cap eststo: ivreg2 lnb_estabt1860_1920 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est10
        cap eststo: ivreg2 lnb_estabt1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort , partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est11
        cap eststo: ivreg2 lnb_estabt1930 (foreign_avg=instmig_avg)  $controls_2sls lcohort never_connected, partial(stid*) robust first
        di e(rkf)
        scalar Fstat = e(rkf)
        estadd scalar Fstat: est12
        cap esttab est* using "./Manuscript/output_rere/T6C_fragTA4.tex", b(%9.3f) se(%9.3f)    booktabs fragment replace label keep(foreign_avg)  stats(N, fmt(%9.0f %9.2f %9.2f %9.2f) labels("Observations" )) star(* 0.10 ** 0.05 *** 0.01) nolines posthead( ) prefoot(\midrule) postfoot( ) nonum nomtitle    eqlabels( " ",none)    

        restore



    }
}