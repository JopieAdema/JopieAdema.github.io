
*Globals and programs:
{
    do ".\code\Conley_x_ols_update.do"
    do ".\code\Conley_x_gmm_update.do"
    global controls_ols="foreign_avg instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
    global controls_rf="instmig_avg instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* "
    global controls_2sls="instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
    global controls_2sls_nos="instind_avg  instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2"
    global controls_noplac="lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
    global controls_noplac_nos="lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2"
    global controls_2sls_alt="inst_ind_tc  inst_gdp_tc lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* "
    global controls_2sls_fd=" inst_ind_c  inst_gdp_c lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid* "

    local controls `"    "lcohort"      "never_connected"    "lcohort never_connected"     "never_connected cohort"  "'
    local controls_altint `"    "never_connected"      "lcohort"    "lcohort never_connected"    "'
}
use ".\data\workdir\Main_Tables_replic.dta", clear
log using .\Manuscript\output_rere\Conleys_fragT1, replace
*TABLE 1, columns 1-4:
{
    *RF:
    {
        foreach c of local controls {
                preserve
                cap xi: reg inc $controls_2sls `c'
                gen sample_fs=1 if e(sample)
                qui predict Y if e(sample)==1, resid
                keep if sample_fs==1
                cap for @ in any inc  $controls_2sls_nos : drop if missing(@)==1
                cap xi: reg instmig_avg $controls_2sls  `c'
                qui predict X if e(sample), resid
                x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
                restore
        }
    }
    *2SLS:
    {
        foreach c of local controls {

            preserve
            drop stid49
            cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
            cap xi: reg foreign_avg $controls_2sls `c',   robust
            qui predict X if e(sample)==1, resid
            cap xi: reg inc  $controls_2sls `c',   robust
            qui predict Y if e(sample)==1, resid
            cap xi: reg instmig_avg $controls_2sls `c',   robust
            qui predict Z if e(sample)==1, resid
            x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
            restore
        }
    }
    *FS:
    {
        foreach c of local controls {
            preserve
            cap xi: reg foreign_avg $controls_2sls `c'
            gen sample_fs=1 if e(sample)
            qui predict Y if e(sample)==1, resid
            keep if sample_fs==1
            cap for @ in any foreign_avg  $controls_2sls_nos : drop if missing(@)==1
            cap xi: reg instmig_avg $controls_2sls  `c'
            qui predict X if e(sample), resid
            x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
            di `r(tstat)'*`r(tstat)'
            restore
        }
    }
}
log close
log using .\Manuscript\output_rere\Conleys_fragTA5, replace
*Table A5 (ever-connected subsample), columns 1-2:
{
    *RF:
    {
        preserve
        drop if never_connected
        cap xi: reg inc $controls_2sls  lcohort
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any inc  $controls_2sls_nos  lcohort : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls lcohort
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        preserve
        drop if never_connected
        cap xi: reg inc $controls_2sls
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any inc  $controls_2sls_nos   : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
    }
    *2SLS:
    {
        preserve
        drop if never_connected
        drop stid49
        cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
        cap xi: reg foreign_avg $controls_2sls lcohort,   robust
        qui predict X if e(sample)==1, resid
        cap xi: reg inc  $controls_2sls lcohort,   robust
        qui predict Y if e(sample)==1, resid
        cap xi: reg instmig_avg $controls_2sls lcohort,   robust
        qui predict Z if e(sample)==1, resid
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore

        preserve
        drop if never_connected
        drop stid49
        cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
        cap xi: reg foreign_avg $controls_2sls ,   robust
        qui predict X if e(sample)==1, resid
        cap xi: reg inc  $controls_2sls ,   robust
        qui predict Y if e(sample)==1, resid
        cap xi: reg instmig_avg $controls_2sls ,   robust
        qui predict Z if e(sample)==1, resid
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
    *FS:
    {
        preserve
        drop if never_connected
        cap xi: reg foreign_avg $controls_2sls  lcohort
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any foreign_avg  $controls_2sls_nos  lcohort : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls lcohort
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore

        preserve
        drop if never_connected
        cap xi: reg foreign_avg $controls_2sls
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any  foreign_avg $controls_2sls_nos   : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore
    }
}
log close
log using .\Manuscript\output_rere\Conleys_UNVERIFIED_2SLSothers, replace
*"2SLS others": control-function-style variants. Target exhibit unidentified --
*kept but not claimed to back any specific table; logged separately so it
*doesn't contaminate the verified exhibit-specific logs.
{
        *1
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls lcohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z
        qui predict Y, resid 
        cap xi: reg lcohort $controls_2sls Z
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        *2
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls never_connected
        qui predict Z , xb
        qui reg inc $controls_2sls Z
        qui predict Y, resid 
        cap xi: reg never_connected $controls_2sls Z
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        *3
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls never_connected lcohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z lcohort
        qui predict Y, resid 
        cap xi: reg never_connected $controls_2sls Z lcohort
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls never_connected lcohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z never_connected
        qui predict Y, resid 
        cap xi: reg lcohort $controls_2sls Z never_connected
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        *4
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls never_connected cohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z cohort
        qui predict Y, resid 
        cap xi: reg never_connected $controls_2sls Z cohort
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        preserve
        qui reg foreign_avg instmig_avg $controls_2sls never_connected cohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z never_connected
        qui predict Y, resid 
        cap xi: reg cohort $controls_2sls Z never_connected
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
        *5
        preserve
        drop if never_connected
        qui reg foreign_avg instmig_avg $controls_2sls lcohort
        qui predict Z , xb
        qui reg inc $controls_2sls Z
        qui predict Y, resid 
        cap xi: reg lcohort $controls_2sls Z
        qui predict X, resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore


    }
log close
log using .\Manuscript\output_rere\Conleys_fragT1, append
*TABLE 1, columns 5-7 (mu=c7, i.cohort=c5, i.cohort i.decade_railvar=c6):
{
    local controls_t1_57 `" "mu" "i.cohort"  "i.cohort i.decade_railvar" "'
    foreach c of local controls_t1_57 {
        di "`c'"
        *FS
        preserve
        cap xi: reg foreign_avg $controls_2sls `c'
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any  foreign_avg $controls_2sls_nos : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls  `c'
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore
    }
    foreach c of local controls_t1_57 {
        di "`c'"
        *RF
        preserve
        cap xi: reg inc $controls_2sls `c'
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any inc  $controls_2sls_nos : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls  `c'
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
    }
    foreach c of local controls_t1_57 {
        di "`c'"
        *2SLS
        preserve
        drop stid49
        cap for @ in any inc foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
        cap xi: reg foreign_avg $controls_2sls `c',   robust
        qui predict X if e(sample)==1, resid
        cap xi: reg inc  $controls_2sls `c',   robust
        qui predict Y if e(sample)==1, resid
        cap xi: reg instmig_avg $controls_2sls `c',   robust
        qui predict Z if e(sample)==1, resid
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
}
log close
log using .\Manuscript\output_rere\Conleys_fragTA6, replace
*Table A6, columns 1-5 (cohort=c1, mu cohort=c2, decade_railvar=c3,
*mu decade_railvar=c4, i.decade_railvar=c5):
{
    local controls_ta6 `" "cohort"  "mu cohort"  "decade_railvar"  "mu decade_railvar"  "i.decade_railvar" "'
    foreach c of local controls_ta6 {
        di "`c'"
        *FS
        preserve
        cap xi: reg foreign_avg $controls_2sls `c'
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any  foreign_avg $controls_2sls_nos : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls  `c'
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore
    }
    foreach c of local controls_ta6 {
        di "`c'"
        *RF
        preserve
        cap xi: reg inc $controls_2sls `c'
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any inc  $controls_2sls_nos : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_2sls  `c'
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
    }
    foreach c of local controls_ta6 {
        di "`c'"
        *2SLS
        preserve
        drop stid49
        cap for @ in any inc foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
        cap xi: reg foreign_avg $controls_2sls `c',   robust
        qui predict X if e(sample)==1, resid
        cap xi: reg inc  $controls_2sls `c',   robust
        qui predict Y if e(sample)==1, resid
        cap xi: reg instmig_avg $controls_2sls `c',   robust
        qui predict Z if e(sample)==1, resid
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
}
log close
log using .\Manuscript\output_rere\Conleys_fragTA8, replace
*Table A8, columns 1-3 (time-consistent shocks, "tc" instrument variant):
{
    foreach c of local controls_altint {

        preserve
        cap xi: reg foreign_avg $controls_2sls_alt `c',   robust
        qui predict X if e(sample)==1, resid 
        cap xi: reg inc  $controls_2sls_alt `c',   robust
        qui predict Y if e(sample)==1, resid 
        cap xi: reg inst_mig_tc $controls_2sls_alt `c',   robust
        qui predict Z if e(sample)==1, resid 
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
    *FS:
    {
        foreach c of local controls_altint {
            preserve
            cap xi: reg foreign_avg $controls_2sls_alt `c'
            qui predict Y if e(sample)==1, resid 
            cap xi: reg inst_mig_tc $controls_2sls_alt  `c'
            qui predict X if e(sample), resid
            x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
            di `r(tstat)'*`r(tstat)'
            restore
        }

    }
}
*Table A8, columns 4-6 (cumulative shocks, "c" instrument variant) -- same
*Conleys_fragTA8 log as above (append, no switch needed: same exhibit):
{
    foreach c of local controls_altint {

        preserve
        cap xi: reg foreign_avg $controls_2sls_fd `c',   robust
        qui predict X if e(sample)==1, resid 
        cap xi: reg inc  $controls_2sls_fd `c',   robust
        qui predict Y if e(sample)==1, resid 
        cap xi: reg inst_mig_c $controls_2sls_fd `c',   robust
        qui predict Z if e(sample)==1, resid 
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
    *FS:
    {
        foreach c of local controls_altint {
            preserve
            cap xi: reg foreign_avg $controls_2sls_fd `c'
            qui predict Y if e(sample)==1, resid 
            cap xi: reg inst_mig_c $controls_2sls_fd  `c'
            qui predict X if e(sample), resid
            x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
            di `r(tstat)'*`r(tstat)'
            restore
        }

    }
}
log close
log using .\Manuscript\output_rere\Conleys_fragTA1, replace
*Table A1 (no placebo controls), all 7 columns:
{
    *RF:
    {
        *Columns 1-4
        foreach c of local controls {
                preserve
                cap xi: reg inc $controls_noplac `c'
                gen sample_fs=1 if e(sample) 
                qui predict Y if e(sample)==1, resid 
                keep if sample_fs==1
                cap for @ in any inc  $controls_noplac_nos : drop if missing(@)==1
                cap xi: reg instmig_avg $controls_noplac  `c'
                qui predict X if e(sample), resid
                x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
                restore
        }
        preserve
        drop if never_connected
        cap xi: reg inc $controls_noplac  lcohort
        gen sample_fs=1 if e(sample) 
        qui predict Y if e(sample)==1, resid 
        keep if sample_fs==1
        cap for @ in any inc  $controls_noplac_nos  lcohort : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_noplac lcohort
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore

        preserve
        drop if never_connected
        cap xi: reg inc $controls_noplac  
        gen sample_fs=1 if e(sample) 
        qui predict Y if e(sample)==1, resid 
        keep if sample_fs==1
        cap for @ in any inc  $controls_noplac_nos   : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_noplac 
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        restore
    }
    *2SLS:
    {
        foreach c of local controls {

            preserve
            drop stid49
            cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1 
            cap xi: reg foreign_avg $controls_noplac `c',   robust
            qui predict X if e(sample)==1, resid 
            cap xi: reg inc  $controls_noplac `c',   robust
            qui predict Y if e(sample)==1, resid 
            cap xi: reg instmig_avg $controls_noplac `c',   robust
            qui predict Z if e(sample)==1, resid 
            x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
            restore
        }
        preserve
        drop if never_connected
        drop stid49
        cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1 
        cap xi: reg foreign_avg $controls_noplac lcohort,   robust
        qui predict X if e(sample)==1, resid 
        cap xi: reg inc  $controls_noplac lcohort,   robust
        qui predict Y if e(sample)==1, resid 
        cap xi: reg instmig_avg $controls_noplac lcohort,   robust
        qui predict Z if e(sample)==1, resid 
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore

        preserve
        drop if never_connected
        drop stid49
        cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1 
        cap xi: reg foreign_avg $controls_noplac ,   robust
        qui predict X if e(sample)==1, resid 
        cap xi: reg inc  $controls_noplac ,   robust
        qui predict Y if e(sample)==1, resid 
        cap xi: reg instmig_avg $controls_noplac ,   robust
        qui predict Z if e(sample)==1, resid 
        x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
        restore
    }
    *FS:
    {
        *Columns 1-4
        foreach c of local controls {
                preserve
                cap xi: reg foreign_avg $controls_noplac `c'
                gen sample_fs=1 if e(sample) 
                qui predict Y if e(sample)==1, resid 
                keep if sample_fs==1
                cap for @ in any foreign_avg  $controls_noplac_nos : drop if missing(@)==1
                cap xi: reg instmig_avg $controls_noplac  `c'
                qui predict X if e(sample), resid
                x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
                di `r(tstat)'*`r(tstat)'

                restore
        }
        preserve
        drop if never_connected
        cap xi: reg foreign_avg $controls_noplac  lcohort
        gen sample_fs=1 if e(sample) 
        qui predict Y if e(sample)==1, resid 
        keep if sample_fs==1
        cap for @ in any foreign_avg  $controls_noplac_nos  lcohort : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_noplac lcohort
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore

        preserve
        drop if never_connected
        cap xi: reg foreign_avg $controls_noplac
        gen sample_fs=1 if e(sample)
        qui predict Y if e(sample)==1, resid
        keep if sample_fs==1
        cap for @ in any  foreign_avg $controls_noplac_nos   : drop if missing(@)==1
        cap xi: reg instmig_avg $controls_noplac
        qui predict X if e(sample), resid
        x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
        di `r(tstat)'*`r(tstat)'
        restore
    }
    *Columns 5-7 (decade-of-rail FE / +decade-of-county FE / mu spec) -- same
    *specs as Table 1's own columns 5-7 below, with $controls_noplac swapped in.
    *Verified against tab_noplac_mod_TA1.tex to 3 decimals.
    {
        local controls_ta1_57 `" "i.cohort"  "i.cohort i.decade_railvar"  "mu" "'
        *RF:
        foreach c of local controls_ta1_57 {
            preserve
            cap xi: reg inc $controls_noplac `c'
            gen sample_fs=1 if e(sample)
            qui predict Y if e(sample)==1, resid
            keep if sample_fs==1
            cap for @ in any inc  $controls_noplac_nos : drop if missing(@)==1
            cap xi: reg instmig_avg $controls_noplac  `c'
            qui predict X if e(sample), resid
            x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
            restore
        }
        *2SLS:
        foreach c of local controls_ta1_57 {
            preserve
            drop stid49
            cap for @ in any inc  foreign_avg instmig_avg  instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2   lat3 long3 lat2 long2 : drop if missing(@)==1
            cap xi: reg foreign_avg $controls_noplac `c',   robust
            qui predict X if e(sample)==1, resid
            cap xi: reg inc  $controls_noplac `c',   robust
            qui predict Y if e(sample)==1, resid
            cap xi: reg instmig_avg $controls_noplac `c',   robust
            qui predict Z if e(sample)==1, resid
            x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
            restore
        }
        *FS:
        foreach c of local controls_ta1_57 {
            preserve
            cap xi: reg foreign_avg $controls_noplac `c'
            gen sample_fs=1 if e(sample)
            qui predict Y if e(sample)==1, resid
            keep if sample_fs==1
            cap for @ in any foreign_avg  $controls_noplac_nos : drop if missing(@)==1
            cap xi: reg instmig_avg $controls_noplac  `c'
            qui predict X if e(sample), resid
            x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
            di `r(tstat)'*`r(tstat)'
            restore
        }
    }
}

log close
log using .\Manuscript\output_rere\Conleys_fragTA7, replace
*Table A7: instrument/outcomes regressed on mu alone (relabeled from a stale
*"Table A6" comment -- structure matches results.do's tab_mu_tiny_fragTA7.tex):
{
    preserve
    cap reghdfe instmig_avg , resid(Y)
    cap reghdfe muXlnm_mean , resid(X)
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    cap xi: reg instmig_avg $controls_2sls lcohort
    gen sample_fs=1 if e(sample) 
    qui predict Y if e(sample)==1, resid 
    cap xi: reg muXlnm_mean $controls_2sls  lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore

    preserve
    cap reghdfe foreign_avg , resid(Y)
    cap reghdfe muXlnm_mean , resid(X)
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    cap xi: reg foreign_avg $controls_2sls  lcohort 
    gen sample_fs=1 if e(sample) 
    qui predict Y if e(sample)==1, resid 
    cap xi: reg muXlnm_mean $controls_2sls  lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore

    preserve
    cap reghdfe inc , resid(Y)
    cap reghdfe muXlnm_mean , resid(X)
    x_ols_update lat lon cutoff1 cutoff2  Y X, coord(2) xreg(1)
    restore
    preserve
    cap xi: reg inc $controls_2sls  lcohort 
    gen sample_fs=1 if e(sample) 
    qui predict Y if e(sample)==1, resid 
    cap xi: reg muXlnm_mean $controls_2sls  lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
}
log close
log using .\Manuscript\output_rere\Conleys_fragTA2, replace
*Table A2 (income-type outcomes: inc pov unemp urban educ). Same loop body as
*Table A3 below, just a different outcome list.
local out_ta2 `" "inc" "pov"  "unemp"  "urban" "educ" "'
foreach o of local out_ta2 {
    di "`o'"

    *OLS
    di "OLS"
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid
    cap xi: reg foreign_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    *RF
    di "RF"
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    di `r(tstat)'
    restore
    *2SLS
    di "2SLS"
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort,   robust
    qui predict X if e(sample)==1, resid
    cap xi: reg `o'  $controls_2sls lcohort,   robust
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort,   robust
    qui predict Z if e(sample)==1, resid
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected,   robust
    qui predict X if e(sample)==1, resid
    cap xi: reg `o'  $controls_2sls lcohort never_connected,   robust
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected,   robust
    qui predict Z if e(sample)==1, resid
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore
}

log close
log using .\Manuscript\output_rere\Conleys_fragTA3, replace
*Table A3 (sk_norm, vote, crime outcomes):
local out_ta3 `" "sk_norm" "vote"  "total_crime"  "crime_personcap" "crime_propertycap"  "'
foreach o of local out_ta3 {
    di "`o'"

    *OLS
    di "OLS"
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid
    cap xi: reg foreign_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    *RF
    di "RF"
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    di `r(tstat)'
    restore
    *2SLS
    di "2SLS"
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort,   robust
    qui predict X if e(sample)==1, resid
    cap xi: reg `o'  $controls_2sls lcohort,   robust
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort,   robust
    qui predict Z if e(sample)==1, resid
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected,   robust
    qui predict X if e(sample)==1, resid
    cap xi: reg `o'  $controls_2sls lcohort never_connected,   robust
    qui predict Y if e(sample)==1, resid
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected,   robust
    qui predict Z if e(sample)==1, resid
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore
}

log close
log using .\Manuscript\output_rere\Conleys_UNVERIFIED_manufsample_inc, replace
*Target exhibit unidentified: Conley-corrected 2SLS/FS for "inc" (not a
*manufacturing outcome) restricted to the sample_manuf==1 sample. Looks
*superseded by the complete per-outcome loop below, which properly covers all
*6 manufacturing outcomes and clearly backs Table A4 -- kept rather than
*deleted since that could not be confirmed.
keep if sample_manuf==1
*FS
{
    *1860-1920 outcomes:
    preserve
    drop if missing(lmoutcap1860_1920)
    cap xi: reg foreign_avg $controls_2sls lcohort,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg inc  $controls_2sls lcohort,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
    di `r(tstat)'*`r(tstat)' 
    restore
    preserve
    drop if missing(lmoutcap1860_1920)
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg inc  $controls_2sls lcohort never_connected,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
    di `r(tstat)'*`r(tstat)' 
    restore

    *1930 outcomes:
    preserve
    drop if missing(lmoutcap1930)
    cap xi: reg foreign_avg $controls_2sls lcohort,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg inc  $controls_2sls lcohort,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
    di `r(tstat)'*`r(tstat)' 
    restore
    preserve
    drop if missing(lmoutcap1930)
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg inc  $controls_2sls lcohort never_connected,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y  X   Z, xreg(1) inst(1) coord(2)
    di `r(tstat)'*`r(tstat)' 
    restore
}

log close
log using .\Manuscript\output_rere\Conleys_fragTA4, replace
*Table A4 (manufacturing outcomes, sample_manuf==1):
local out `" "lmoutcap1860_1920"  "lmoutcap1930" "lmoutestb1860_1920" "lmoutestb1930"  "lnb_estabt1860_1920" "lnb_estabt1930"  "'
foreach o of local out {
    di "`o'"

    *OLS
    di "OLS"

    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid 
    cap xi: reg foreign_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid 
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    *RF
    di "RF"

    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg `o' $controls_2sls lcohort never_connected
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected
    qui predict X if e(sample), resid
    x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
    restore
    *2SLS
    di "2SLS"
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg `o'  $controls_2sls lcohort,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore
    preserve
    drop if missing(`o')
    cap xi: reg foreign_avg $controls_2sls lcohort never_connected,   robust
    qui predict X if e(sample)==1, resid 
    cap xi: reg `o'  $controls_2sls lcohort never_connected,   robust
    qui predict Y if e(sample)==1, resid 
    cap xi: reg instmig_avg $controls_2sls lcohort never_connected,   robust
    qui predict Z if e(sample)==1, resid 
    x_gmm_update lat lon cutoff1 cutoff2 Y X Z, xreg(1) inst(1) coord(2)
    restore

    
}



log close

*Convert every Conley log (smcl) opened above to pdf:
foreach f in fragT1 fragTA5 UNVERIFIED_2SLSothers fragTA6 fragTA8 fragTA1 fragTA7 fragTA2 fragTA3 UNVERIFIED_manufsample_inc fragTA4 {
    translate .\Manuscript\output_rere\Conleys_`f'.smcl .\Manuscript\output_rere\Conleys_`f'.pdf, replace
}
