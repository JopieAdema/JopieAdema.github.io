local bstart -15
local bend 15
local Nstep 1001
*1001
local Nreps 999
*999
set seed 1312
global controls_2sls="instind_avg instgdp_avg lat lon lat_long  lat2_long lat_long2 lat3 long3 lat2 long2 stid*"
do ".\code\Conley_x_ols_update.do"
*Figures A10/A11: randomization-inference p-value curve and CI (mu spec only;
*the lcohort version is computed but not plotted, per the manuscript)
{
    *preps:
    {
        use ".\data\Zero_Stage.dta", clear
        quietly summarize lnm
        scalar LNM_MEAN = r(mean)
        scalar LNM_SD   = r(sd)

        levelsof lnm, local(lnm_list)
        global LNM_LIST "`lnm_list'"

        areg fs lfs lrail_mig lindex_lrail lgdp_dg_lrail lrail lpopd lurbd lurbd_lnm d_decade* if sample_2sls==1, absorb(fips)  robust

        *Define the beta as original, so all RF estimates align again:
        global beta_scale =_b[lrail_mig]
        global beta_scale_index =_b[lindex_lrail]
        global beta_scale_gdp =_b[lgdp_dg_lrail]

        clear

        capture program drop Z_gen
        program define Z_gen, rclass
            syntax ,   
                *1) Build shocks dataset
                tempfile shocks
                clear
                set obs 7
                qui gen int decade = 1860 + 10*(_n-1)
                qui gen double u = runiform()
                sort u
                drop u
                qui gen double lnm = .
                local i = 1
                foreach c of global LNM_LIST {
                    qui replace lnm = `c' in `i'
                    local ++i
                }
                qui save `shocks', replace

                *2) First-stage + build instrument panel
                use ".\data\Zero_Stage.dta", clear
                drop lrail_mig lindex_lrail lgdp_dg_lrail lnm
                qui merge m:1 decade using `shocks', nogen keep(match)
                qui gen double lrail_mig    = lrail*lnm
                qui gen double lindex_lrail = lrail*lindex
                qui gen double lgdp_dg_lrail= lrail*lgdp_dg
                qui qui areg fs lfs lrail_mig lindex_lrail lgdp_dg_lrail lrail lpopd lurbd lurbd_lnm d_decade* if sample_2sls==1, absorb(fips) robust
                qui gen double instmig = $beta_scale*lrail_mig if e(sample)
                qui label var instmig "Instrument For Immigration Flows"
                qui gen double instind = $beta_scale_index*lindex_lrail
                qui label var instind "Instrument for Industrialization"
                qui gen double instgdp = $beta_scale_gdp*lgdp_dg_lrail
                qui label var instgdp "Instrument for Business Cycles"
                qui gen double lrail_IV = lrail  if e(sample)
                qui keep if inrange(decade,1860,1920) & sample==1
                qui keep fips decade instmig 
                qui reshape wide instmig , i(fips) j(decade)
                qui egen double Z = rowmean(instmig*)
                keep fips Z
        end
    }
    *Calculating instruments:
    {
        forvalues i =1/`Nreps' {
            di `i'
            Z_gen
            rename Z Z`i'
            tempfile Z`i'
            save `Z`i'', replace
        }
        use `Z1', clear
        forvalues i =2/`Nreps' {
            qui merge 1:1 fips using `Z`i'', nogen
        }
        tempfile Z_all
        save `Z_all'
        
    }
    foreach var in lcohort mu   {
        local ctrl  $controls_2sls `var' 
        *Frame to be populated
        {

            clear 
            range bcand `bstart' `bend' `Nstep'
            gen p = .
            gen p_rob = .
            gen p_conley = .
            local N = _N
            levelsof bcand, local(bcand_list)
            tempfile b_file
            save `b_file', replace
        }
        *Preparing IV file:
        {
            use ".\data\workdir\Main_Tables_replic.dta", clear
            merge 1:1 fips using `Z_all', nogen
            qui reghdfe inc         `ctrl', resid(y_resid)
            qui reghdfe foreign_avg `ctrl', resid(x_resid)

            keep fips_code y_resid x_resid Z* mu IV_recentered

            forvalues i =1/`Nreps' {
                gen IV_rec_`i' = Z`i' - mu*LNM_MEAN*$beta_scale
                drop Z`i'
            }
            tempfile IV_file
            save `IV_file', replace
        }
        *loop over candidate b's
        {
            global loop "`bcand_list'"
            local n = 1
            foreach b of global loop {
                di `b'
                use `IV_file',clear
                qui gen double T0_element = IV_recentered*(y_resid-`b'*x_resid)
                qui egen T0 = total(T0_element)
                qui su T0
                global T0 = r(mean)
                drop T0* T0_element

                forvalues i =1/`Nreps' {
                    qui gen double T`i'_element = IV_rec_`i'*(y_resid-`b'*x_resid)
                    qui egen double T`i' = total(T`i'_element)
                    drop T`i'_element IV_rec_`i'
                }
                keep if _n==1
                keep T*   
                xpose, clear

                su v1 if v1 > $T0
                local share_bigger = `r(N)'/_N
                local p_RI = 2*min(`share_bigger', 1-`share_bigger')


                *save the p-value 
                use `b_file', clear
                replace p = `p_RI' if _n == `n'
                *replace p_rob = `p_rob' if _n == `n'
                *replace p_conley = `p_conley' if _n == `n'
                save `b_file', replace
                local ++n



            }
        }
        *Drawing plots. Only the mu specification is shown in the manuscript (Figure A11),
        *so the (unused) lcohort plot is skipped.
        gen draw = 0
        local cisuf = cond("`var'"=="mu","_FA10","")
        if "`var'"=="mu" {
            twoway     rarea p draw b if p>0.10, color(gs14) ||   line p b, lcolor(black) ,  yline(0.10, lpattern(dash))      ylabel(0(0.1)1)      xtitle("b{sup:cand}")     ytitle("p-value") legend(off)
            graph export ".\Manuscript\output_rere\hist_CIs_RI_`var'`cisuf'.pdf", replace
        }

        log using .\Manuscript\output_rere\RI_CIs_fragFA10, replace

        gen b_notreject = bcand if p>=0.10
        egen lower_bound = min(b_notreject)
        egen upper_bound = max(b_notreject)
        su lower_bound
        su upper_bound
        log close
        translate .\Manuscript\output_rere\RI_CIs_fragFA10.smcl .\Manuscript\output_rere\RI_CIs_fragFA10.pdf

    }
}
*ANDERSON-RUBIN CONFIDENCE INTERVALS (manual, since Conleys don't allow for this):
*Table 1, Table A6, and (below) Table A5 share one postfile/csv export since the
*"spec" column already labels which table each row belongs to, but get separate
*.smcl/.pdf logs (switched below by loop position) so each exhibit has its own.
log using .\Manuscript\output_rere\AR_CIs_fragT1, replace
* machine-readable export (in addition to the logs below):
tempname arpf
postfile `arpf' str60 spec double(ar_lo ar_hi) using ".\Manuscript\output_rere\AR_CIs_tmp.dta", replace
local samp "full"
*SPECS listed in table-column order (output reads Table 1 c1-c7, then Table A6 c1-c5):
*  Table 1 (main):        lcohort=c1, never_connected=c2, lcohort never_connected=c3,
*                         cohort never_connected=c4, i.cohort=c5,
*                         "i.cohort i.decade_railvar"=c6 (AR CI only), mu=c7.
*  Table A6 (county age): cohort=c1, mu cohort=c2, decade_railvar=c3,
*                         mu decade_railvar=c4, i.decade_railvar=c5.
local controls `" "lcohort"  "never_connected"  "lcohort never_connected" "cohort never_connected" "i.cohort"  "i.cohort i.decade_railvar"  "mu"  "cohort"  "mu cohort"  "decade_railvar"  "mu decade_railvar"  "i.decade_railvar" "'
local idx = 0
foreach c of local controls {
    local idx = `idx' + 1
    if `idx' == 8 {
        log close
        log using .\Manuscript\output_rere\AR_CIs_fragTA6, replace
    }
    di "`c'"
    local cc = subinstr("`c'", " ", "", .)
    local cc = subinstr("`cc'", ".", "", .)

    {
        *Frame to be populated
        {
            clear 
            cap range bcand `bstart' `bend' `Nstep'
            cap gen p_rob = .
            cap gen p_conley = .
            local N = _N
            cap levelsof bcand, local(bcand_list)
            tempfile b_file
            save `b_file', replace
        }
        *Run and graph
        {
            global loop "`bcand_list'"
            local n = 1
            foreach b of global loop {
                cap di `b'
                *AR BLOCK:
                {
                    use ".\data\workdir\Main_Tables_replic.dta", clear
                    *calculate the residual outcome
                    cap gen inc_resid = inc-`b'*foreign_avg
                    cap reg inc_resid instmig_avg $controls_2sls `c'
                    local p_rob = (2*(normal(-abs(_b[instmig_avg]/_se[instmig_avg]))))
                    *this is effectively the RF p -- which is a nice object as it is not 

                    *simple RF conley:
                    cap xi: reg inc_resid $controls_2sls `c'
                    cap predict Y, resid 
                    cap xi: reg instmig_avg $controls_2sls `c'
                    cap predict X, resid
                    cap x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
                    local p_conley = (2*(normal(-abs(`r(tstat)'))))
                }

                *save the p-value 
                use `b_file', clear
                cap replace p_rob = `p_rob' if _n == `n'
                cap replace p_conley = `p_conley' if _n == `n'
                cap save `b_file', replace
                local ++n
            }
            gen draw=0
            *diagnostic AR-CI p-value curve (Conley), not used in the manuscript:
            *twoway     rarea p_conley draw bcand if p_conley>0.10, color(gs14) ||   line p_conley bcand, lcolor(black) ,  yline(0.10, lpattern(dash))      ylabel(0(0.1)1)      xtitle("b{sup:cand}")     ytitle("p-value") legend(off)
            *graph export ".\Manuscript\output_rere\hist_CIs_AR_con_`cc'.pdf", replace

            *95 CI
            gen b_sig_AR = bcand if p_conley>0.10
            egen b_min_AR = min(b_sig_AR)
            egen b_max_AR = max(b_sig_AR)
            su b_min_AR b_max_AR
            post `arpf' ("`samp': `c'") (b_min_AR[1]) (b_max_AR[1])

            *diagnostic AR-CI p-value curve (robust SE), not used in the manuscript:
            *twoway     rarea p_rob draw bcand if p_rob>0.10, color(gs14) ||   line p_rob bcand, lcolor(black) ,  yline(0.10, lpattern(dash))      ylabel(0(0.1)1)      xtitle("b{sup:cand}")     ytitle("p-value") legend(off)
            *graph export ".\Manuscript\output_rere\hist_CIs_AR_rob_`cc'.pdf", replace

            gen b_notreject = bcand if p_rob>=0.10
            egen lower_bound = min(b_notreject)
            egen upper_bound = max(b_notreject)
            su lower_bound upper_bound


        }
    }
}
log close
translate .\Manuscript\output_rere\AR_CIs_fragT1.smcl .\Manuscript\output_rere\AR_CIs_fragT1.pdf, replace
translate .\Manuscript\output_rere\AR_CIs_fragTA6.smcl .\Manuscript\output_rere\AR_CIs_fragTA6.pdf, replace

log using .\Manuscript\output_rere\AR_CIs_fragTA5, replace
local samp "ever_connected"
*SPECS -> ever-connected table (Table A5): lcohort=c1 (keeps log(years of rail+1)),
*  empty=c2 (baseline controls only).
local controls `" "lcohort"  " " "'

foreach c of local controls {
    di "`c'"
    local cc = subinstr("`c'", " ", "", .)
    local cc = subinstr("`cc'", ".", "", .)

    {
        *Frame to be populated
        {
            clear 
            cap range bcand `bstart' `bend' `Nstep'
            cap gen p_rob = .
            cap gen p_conley = .
            local N = _N
            cap levelsof bcand, local(bcand_list)
            tempfile b_file
            save `b_file', replace
        }
        *Run and graph
        {
            global loop "`bcand_list'"
            local n = 1
            foreach b of global loop {
                cap di `b'
                *AR BLOCK:
                {
                    use ".\data\workdir\Main_Tables_replic.dta", clear
                    cap drop if never_connected
                    *calculate the residual outcome
                    cap gen inc_resid = inc-`b'*foreign_avg
                    cap reg inc_resid instmig_avg $controls_2sls `c'
                    local p_rob = (2*(normal(-abs(_b[instmig_avg]/_se[instmig_avg]))))
                    *this is effectively the RF p -- which is a nice object as it is not 

                    *simple RF conley:
                    cap xi: reg inc_resid $controls_2sls `c'
                    cap predict Y, resid 
                    cap xi: reg instmig_avg $controls_2sls `c'
                    cap predict X, resid
                    cap x_ols_update lat lon cutoff1 cutoff2 Y X, coord(2) xreg(1)
                    local p_conley = (2*(normal(-abs(`r(tstat)'))))
                }

                *save the p-value 
                use `b_file', clear
                cap replace p_rob = `p_rob' if _n == `n'
                cap replace p_conley = `p_conley' if _n == `n'
                cap save `b_file', replace
                local ++n
            }
            gen draw=0
            *diagnostic AR-CI p-value curve (Conley, ever-connected), not used in the manuscript:
            *twoway     rarea p_conley draw bcand if p_conley>0.10, color(gs14) ||   line p_conley bcand, lcolor(black) ,  yline(0.10, lpattern(dash))      ylabel(0(0.1)1)      xtitle("b{sup:cand}")     ytitle("p-value") legend(off)
            *graph export ".\Manuscript\output_rere\hist_CIs_AR_con_`cc'_nc.pdf", replace

            *95 CI
            gen b_sig_AR = bcand if p_conley>0.10
            egen b_min_AR = min(b_sig_AR)
            egen b_max_AR = max(b_sig_AR)
            su b_min_AR b_max_AR
            post `arpf' ("`samp': `c'") (b_min_AR[1]) (b_max_AR[1])

            *diagnostic AR-CI p-value curve (robust SE, ever-connected), not used in the manuscript:
            *twoway     rarea p_rob draw bcand if p_rob>0.10, color(gs14) ||   line p_rob bcand, lcolor(black) ,  yline(0.10, lpattern(dash))      ylabel(0(0.1)1)      xtitle("b{sup:cand}")     ytitle("p-value") legend(off)
            *graph export ".\Manuscript\output_rere\hist_CIs_AR_rob_`cc'_nc.pdf", replace

            gen b_notreject = bcand if p_rob>=0.10
            egen lower_bound = min(b_notreject)
            egen upper_bound = max(b_notreject)
            su lower_bound upper_bound

        }
    }
}
postclose `arpf'
log close
translate .\Manuscript\output_rere\AR_CIs_fragTA5.smcl .\Manuscript\output_rere\AR_CIs_fragTA5.pdf, replace
use ".\Manuscript\output_rere\AR_CIs_tmp.dta", clear
*Combined csv: rows are labeled by "spec" (e.g. "full: lcohort", "full: mu",
*"ever_connected: lcohort") so Table 1 (full, c1-c7), Table A6 (full, appended
*cohort-based specs), and Table A5 (ever_connected) rows are all identifiable
*from a single machine-readable file rather than duplicated across three.
export delimited using ".\Manuscript\output_rere\AR_CIs_fragT1_TA6_TA5.csv", replace
erase ".\Manuscript\output_rere\AR_CIs_tmp.dta"
