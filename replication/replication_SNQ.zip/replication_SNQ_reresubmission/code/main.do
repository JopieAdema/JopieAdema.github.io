* Set this to the full path of the replication_SNQ_reresubmission folder on your machine:
cd "<path to replication_SNQ_reresubmission>"
* Use the user-written commands bundled in .\ado (self-contained; no ssc install needed):
sysdir set PLUS "`c(pwd)'/ado"
*Few minutes:
do .\code\results.do
*Few minutes:
do .\code\conley.do
*24 hours:
do .\code\confidence_intervals.do
*60 hours:
do .\code\randomization_inference.do
