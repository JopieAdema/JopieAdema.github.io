"""
Appendix figure: distribution of the 2014-2016 change in county crimes per inhabitant,
all recorded crimes versus crimes excluding immigration-law offences (390 counties).

Input : output/county_changes.csv (code/01_calibrate.py)
Output: output/figures/fig_hist_changes.pdf/.png
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
d = pd.read_csv(ROOT / "output" / "county_changes.csv", index_col=0)

W = 0.005
bins = np.arange(np.floor(d[["dy_all", "dy_excl"]].min().min() / W) * W,
                 d[["dy_all", "dy_excl"]].max().max() + 2 * W, W)
series = [("dy_all", "All recorded crimes", "#2a78d6"),
          ("dy_excl", "Excluding immigration-law offences", "#eb6834")]

fig, ax = plt.subplots(figsize=(7.5, 3.8))
for col, lab, c in series:
    ax.hist(d[col], bins=bins, color=c, alpha=0.5, edgecolor="none",
            label=f"{lab} (SD = {d[col].std():.4f})")

# Label the five largest changes in all recorded crimes, staggered above their bars
top = d.nlargest(5, "dy_all").sort_values("dy_all")
ax.set_yscale("log")
ax.set_ylim(0.7, 600)
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}"))
for k, (_, r) in enumerate(top.iterrows()):
    right = r.dy_all > 0.9  # rightmost label ends at its line
    ax.annotate(f"{r['name']}\n+{r.dy_all:.2f}", xy=(r.dy_all, 1), xytext=(r.dy_all, 2.2 * 1.75 ** k),
                ha="right" if right else "center", va="bottom", fontsize=7.5, color="#0b0b0b",
                arrowprops=dict(arrowstyle="-", color="#52514e", linewidth=0.6,
                                relpos=(1, 0) if right else (0.5, 0)))
ax.axvline(0, color="#52514e", linewidth=0.8)
ax.set_xlim(bins[0], bins[-1])
ax.set_xlabel("Change in crimes per inhabitant, 2014 to 2016")
ax.set_ylabel("Number of counties")
ax.legend(frameon=False, fontsize=8, loc="upper right")
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(ROOT / "output" / "figures" / f"fig_hist_changes.{ext}", dpi=200)
print(top[["name", "dy_all", "dy_excl"]].round(3).to_string())
