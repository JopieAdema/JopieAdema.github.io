"""
Master script: rebuilds every table, figure and number in the comment from the raw data.

Usage (from any directory):
    python code/run_all.py            # all steps, then compiles the manuscript if latexmk is found
    python code/run_all.py --no-tex   # skip the LaTeX step

R is found on the PATH (Rscript) or through the environment variable RSCRIPT. Each step writes
its console output to output/logs/<step>.log.
"""
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CODE, LOGS = ROOT / "code", ROOT / "output" / "logs"
STEPS = [
    "00_riaz_calibration.R",       # Riaz's calibration values -> output/riaz_calibration.csv
    "01_calibrate.py",             # Table 1, Table B1, 2016 benchmark, county changes
    "02_power_heatmaps.R",         # Figure 2 and the power numbers in Section 4
    "03_appendix_histogram.py",    # Figure 1
    "04_appendix_windows.py",      # Table B2
]

rscript = os.environ.get("RSCRIPT") or shutil.which("Rscript")
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",  # no __pycache__ (it stores local paths)
           PYTHONIOENCODING="utf-8")  # logs are written as UTF-8 (county names such as Gießen)
LOGS.mkdir(parents=True, exist_ok=True)
for step in STEPS:
    cmd = [rscript, str(CODE / step)] if step.endswith(".R") else [sys.executable, str(CODE / step)]
    if cmd[0] is None:
        sys.exit("Rscript not found: put it on the PATH or set the environment variable RSCRIPT.")
    t0 = time.time()
    with open(LOGS / f"{Path(step).stem}.log", "w", encoding="utf8") as log:
        rc = subprocess.run(cmd, cwd=CODE, stdout=log, stderr=subprocess.STDOUT, env=env).returncode
    print(f"{step:34s} {'ok' if rc == 0 else 'FAILED'} ({time.time() - t0:.0f} s)")
    if rc != 0:
        sys.exit(f"{step} failed; see output/logs/{Path(step).stem}.log")

if "--no-tex" not in sys.argv and shutil.which("latexmk"):
    # Manuscript and online appendix cross-reference each other (xr-hyper), so each is
    # compiled twice, alternating, until both read the other's final labels
    docs = ["comment_riaz_rap_appendix.tex", "comment_riaz_rap.tex"]
    rc = {}
    for doc in docs * 2:
        rc[doc] = subprocess.run(["latexmk", "-pdf", "-g", "-interaction=nonstopmode", doc],
                                 cwd=ROOT / "manuscript", stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL).returncode
    for doc in docs:
        print(f"{'manuscript/' + doc:34s} {'ok' if rc[doc] == 0 else 'FAILED'}")
    # Remove LaTeX auxiliary files (they record local file paths); keeps the PDFs
    for doc in docs:
        subprocess.run(["latexmk", "-c", doc], cwd=ROOT / "manuscript",
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
