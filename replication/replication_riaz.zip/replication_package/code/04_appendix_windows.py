"""
Appendix table: calibration of the first-difference design in two two-year windows, 2014-2016
(Riaz's window) and 2017-2019 (after the inflow at the border had ended), for the same 390 counties,
with and without immigration-law offences (PKS key 725000). Procedure as in 01_calibrate.py.

Inputs : output/county_changes.csv (01_calibrate.py; defines the 390 counties),
         data/pks/PKS{2014,2016,2017,2019}_Kreise_Faelle.csv,
         data/destatis/ population and Schutzsuchende by county at 31.12. (GENESIS 12411-0015, 12531-0040)
Outputs: output/calibration_windows.csv, output/tables/tab_windows.tex,
         output/macros/04_appendix_windows.tex
"""
import numpy as np
import pandas as pd
from pathlib import Path

import macros as M

ROOT = Path(__file__).resolve().parents[1]
PKS = ROOT / "data" / "pks"
DESTATIS = ROOT / "data" / "destatis"
OUT = ROOT / "output"
WINDOWS = [(2014, 2016), (2017, 2019)]


def num(s):
    return pd.to_numeric(s.astype(str).str.replace(",", "", regex=False), errors="coerce")


# --- Recorded crime (PKS): all offences (key ------) and immigration-law offences (725000)
def read_pks(year):
    df = pd.read_csv(PKS / f"PKS{year}_Kreise_Faelle.csv", sep=";", skiprows=1, encoding="latin1",
                     dtype=str)
    cases = [c for c in df.columns if "erfasste F" in c][0]
    df = df.rename(columns={df.columns[0]: "key", df.columns[2]: "id", cases: "cases"})
    df = df[df.key.isin(["------", "725000"])].assign(id=num(df["id"]).astype("Int64"),
                                                      cases=num(df["cases"]))
    w = df.pivot_table(index="id", columns="key", values="cases")
    return pd.DataFrame({"all": w["------"], "imm": w["725000"].fillna(0)})


# --- Population and refugees (Schutzsuchende) at 31.12.
pop = pd.read_csv(DESTATIS / "destatis_-Bevoelkerung_Kreise_2007-2019.csv", sep=";", skiprows=6,
                  header=None, encoding="latin1", dtype=str).iloc[:, :15]
pop.columns = ["id", "name"] + [f"p{y}" for y in range(2007, 2020)]
pop["id"] = num(pop["id"]).astype("Int64")
pop = pop.dropna(subset=["id"]).set_index("id").drop(columns="name").apply(num)
ref = pd.read_csv(DESTATIS / "destatis-12531-0040_SchutzsuchendeAnzahl_Kreise_2007-2019.csv", sep=";",
                  skiprows=5, header=None, encoding="latin1", dtype=str).iloc[:, :6]
ref.columns = ["date", "id", "name", "male", "female", "total"]
ref["year"] = num(ref["date"].str[6:10])
ref["id"] = num(ref["id"]).astype("Int64")
ref = ref.assign(total=num(ref["total"])).dropna(subset=["id", "year"])
ref = ref.set_index(["id", "year"])["total"].unstack()

# --- Sample: the 390 counties of Riaz's 2014-2016 calibration, held fixed across windows
ids = pd.read_csv(OUT / "county_changes.csv", index_col=0).index

rows = {}
for y0, y1 in WINDOWS:
    d = pd.DataFrame({"p0": pop[f"p{y0}"], "p1": pop[f"p{y1}"], "r0": ref[y0], "r1": ref[y1]})
    d = d.join(read_pks(y0).add_suffix("0")).join(read_pks(y1).add_suffix("1")).reindex(ids)
    assert d.notna().all().all() and len(d) == 390, d[d.isna().any(axis=1)]
    dS = d.r1 / d.p1 - d.r0 / d.p0
    X = np.column_stack([np.ones(len(d)), dS])
    r = dict(n=len(d), mean_dS=dS.mean(), sd_dS=dS.std())
    for k in ("all", "excl"):
        y_0 = (d.all0 - (d.imm0 if k == "excl" else 0)) / d.p0
        y_1 = (d.all1 - (d.imm1 if k == "excl" else 0)) / d.p1
        beta, *_ = np.linalg.lstsq(X, y_1 - y_0, rcond=None)
        r[f"sigma_{k}"] = np.std(y_1 - y_0 - X @ beta, ddof=1)
    rows[f"{y0}-{y1}"] = r

cal = pd.DataFrame(rows).T
cal.to_csv(OUT / "calibration_windows.csv")
print(cal.round(5).to_string())

# --- Table
lines = [
    ("Counties", "n", "{:.0f}"),
    ("Mean change in refugee share", "mean_dS", "{:.4f}"),
    ("SD of change in refugee share", "sd_dS", "{:.4f}"),
    ("Residual volatility $\\sigma_{\\Delta\\varepsilon}$, all crimes", "sigma_all", "{:.4f}"),
    ("Residual volatility $\\sigma_{\\Delta\\varepsilon}$, excl.\\ immigration law", "sigma_excl", "{:.4f}"),
]
body = [lab + " & " + " & ".join(f.format(cal.loc[w, v]) for w in cal.index) + " \\\\"
        for lab, v, f in lines]
tex = r"""\begin{tabular}{lcc}
\toprule
 & 2014--2016 & 2017--2019 \\
 & (1) & (2) \\
\midrule
""" + "\n".join(body) + r"""
\bottomrule
\end{tabular}
"""
(OUT / "tables" / "tab_windows.tex").write_text(tex, encoding="utf8")

# --- Numbers cited in the text: residual volatility 2017-2019
M.write(OUT / "macros" / "04_appendix_windows.tex", {
    "SigmaAllLate": M.num(cal.loc["2017-2019", "sigma_all"], 4),
})
