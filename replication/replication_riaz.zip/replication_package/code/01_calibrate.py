"""
Rebuild the Monte Carlo calibration of Riaz (2026, BJPolS), SI Section E, from public data,
and recalibrate it excluding immigration-law offences (PKS key 725000) from recorded crime.
Also computes the 2016 benchmark for the immigrant-native crime gap: the suspect rate of asylum
seekers relative to natives (PKS key 890000, i.e. excluding immigration-law offences).

Inputs : data/pks/PKS{2014,2016}_Kreise_Faelle.csv, data/pks/PKS2016_T61_...csv (BKA);
         data/destatis/ (population and protection seekers by county; national population from the
         Statistischer Bericht Schutzsuchende 2025); data/bamf/bamf_2016_asylum_procedures.csv (BAMF);
         data/gisco/ (Eurostat NUTS 2016); output/riaz_calibration.csv (00_riaz_calibration.R)
Outputs: output/calibration.csv, output/observed_ratio.csv, output/county_changes.csv,
         output/text_numbers.csv, output/tables/tab_{calibration,counties}.tex,
         output/macros/01_calibrate.tex
"""
import geopandas as gpd
import numpy as np
import pandas as pd
from pathlib import Path

import macros as M

ROOT = Path(__file__).resolve().parents[1]
PKS = ROOT / "data" / "pks"
DESTATIS = ROOT / "data" / "destatis"
OUT = ROOT / "output"
(OUT / "tables").mkdir(parents=True, exist_ok=True)
mac = {}

r = pd.read_csv(OUT / "riaz_calibration.csv", index_col=0)["value"]
RIAZ = dict(n=r.n_units, mean_dS=r.mean_delta_S, sd_dS=r.sd_delta_S, cv=r.coeff_var_S, c_N=r.c_N,
            sigma=r.sigma_Deps)


def num(s):
    return pd.to_numeric(s.astype(str).str.replace(",", "", regex=False), errors="coerce")


def read_raw(path):
    df = pd.read_csv(path, sep=";", skiprows=1, encoding="latin1", dtype=str)
    df = df.rename(columns={df.columns[0]: "key", df.columns[2]: "id"})
    df["id"] = num(df["id"]).astype("Int64")
    return df


# --- Recorded crime (PKS): all offences (key ------) and immigration-law offences (725000)
def read_pks(path, year):
    df = read_raw(path)
    cases = [c for c in df.columns if c.startswith("erfasste F")][0]
    df = df[df.key.isin(["------", "725000"])]
    w = df.assign(cases=num(df[cases])).pivot_table(index="id", columns="key", values="cases")
    return pd.DataFrame({f"all{year}": w["------"], f"imm{year}": w["725000"].fillna(0)})


pks = read_pks(PKS / "PKS2014_Kreise_Faelle.csv", 2014).join(
      read_pks(PKS / "PKS2016_Kreise_Faelle.csv", 2016), how="inner")

# --- Population at 31.12.
pop = pd.read_csv(DESTATIS / "destatis_-Bevoelkerung_Kreise_2007-2019.csv", sep=";", skiprows=6,
                  header=None, encoding="latin1", dtype=str).iloc[:, :15]
pop.columns = ["id", "name"] + [f"p{y}" for y in range(2007, 2020)]
pop["id"] = num(pop["id"]).astype("Int64")
pop = pop.dropna(subset=["id"]).set_index("id")
DNAME = pop["name"]
NAME = pop["name"].str.replace(", Landkreis", " (district)").str.replace(", kreisfreie Stadt", " (city)")
p2017, p2019 = num(pop["p2017"]), num(pop["p2019"])
pop = pop[["p2014", "p2016"]].apply(num)

# --- Refugees (Schutzsuchende) at 31.12.; columns are date, id, name, male, female, total
ref = pd.read_csv(DESTATIS / "destatis-12531-0040_SchutzsuchendeAnzahl_Kreise_2007-2019.csv", sep=";",
                  skiprows=5, header=None, encoding="latin1", dtype=str).iloc[:, :6]
ref.columns = ["date", "id", "name", "male", "female", "total"]
ref["year"] = ref["date"].str[6:10]
ref = ref[ref.year.isin(["2014", "2016", "2017", "2019"])].copy()
ref["id"] = num(ref["id"]).astype("Int64")
ref["total"] = num(ref["total"])
ref = ref.set_index(["id", "year"])["total"].unstack()  # "-" (suppressed) stays missing
ref.columns = ["r2014", "r2016", "r2017", "r2019"]
r2017, r2019 = ref.pop("r2017"), ref.pop("r2019")

# --- Sample (Riaz, SI fn. 14): drop units whose refugees are reported for a joint area or whose
#     boundaries change: Saarland (registered jointly in Saarlouis), Kassel city/district and
#     Cottbus/Spree-Neisse (no separate district count in 2014), Goettingen/Osterode (merged 2016)
JOINT = [6611, 6633, 12052, 12071]
full_sample = pop.join(ref, how="inner").join(pks, how="inner").dropna(subset=["p2014", "p2016", "all2014", "all2016"])
d = pop.join(ref, how="inner").join(pks, how="inner").dropna()
d = d[((d.index // 1000) != 10) & ~d.index.isin(JOINT)]
assert len(d) == 390, len(d)
d["dS"] = d.r2016 / d.p2016 - d.r2014 / d.p2014
for k in ("all", "excl"):
    for y in (2014, 2016):
        d[f"y_{k}{y}"] = (d[f"all{y}"] - (d[f"imm{y}"] if k == "excl" else 0)) / d[f"p{y}"]
    d[f"dy_{k}"] = d[f"y_{k}2016"] - d[f"y_{k}2014"]

X = np.column_stack([np.ones(len(d)), d.dS])
d.assign(name=NAME.reindex(d.index))[["name", "dS", "dy_all", "dy_excl"]].to_csv(OUT / "county_changes.csv")

# c_N for all counties with complete 2014 crime and population data (for footnote on Riaz's c_N)
cN_full = full_sample.all2014.sum() / full_sample.p2014.sum()

# Average county change in the refugee share 2017-2019, same counties (as in Table B2)
dS1719 = (r2019 / p2019 - r2017 / p2017).reindex(d.index)
print(f"mean dS 2017-2019: {dS1719.mean():.5f} ({dS1719.notna().sum()} counties)")

# --- Distance of each county to Germany's land border (Eurostat GISCO NUTS 2016, 1:1 million,
#     NUTS-3 = Kreise); matched to county codes by name
#     The file is downloaded from GISCO on first run (not redistributed with the package).
#     (c) EuroGeographics for the administrative boundaries.
NUTS = ROOT / "data" / "gisco" / "NUTS_RG_01M_2016_3035.geojson"
if not NUTS.exists():
    import urllib.request
    NUTS.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve("https://gisco-services.ec.europa.eu/distribution/v2/nuts/geojson/"
                               "NUTS_RG_01M_2016_3035.geojson", NUTS)
g = gpd.read_file(NUTS)
de = g[(g.LEVL_CODE == 3) & (g.CNTR_CODE == "DE")].copy()
nb = g[(g.LEVL_CODE == 0) & g.NUTS_ID.isin(["AT", "CH", "FR", "LU", "BE", "NL", "DK", "PL", "CZ"])]
de["dist_km"] = de.geometry.distance(nb.geometry.union_all()) / 1000
full = de.set_index(de.NUTS_NAME.str.lower())["dist_km"]
base = de[~de.NUTS_NAME.str.contains(",")]
base = base.set_index(base.NUTS_NAME.str.lower())["dist_km"]


def border_km(i):
    n = DNAME[i].lower()
    if n in full.index:
        return full[n]
    b = n.split(",")[0].strip()
    return base[b] if b in base.index else np.nan


def calibrate(k):
    """c_N, OLS of dy on dS (residual SD as sd() in Riaz), shock moments."""
    beta, *_ = np.linalg.lstsq(X, d[f"dy_{k}"].values, rcond=None)
    e = d[f"dy_{k}"].values - X @ beta
    c_N = np.average(d[f"y_{k}2014"], weights=d.p2014)
    share = pd.Series(e**2 / np.sum(e**2), index=d.index)
    return dict(n=len(d), mean_dS=d.dS.mean(), sd_dS=d.dS.std(), cv=d.dS.std() / d.dS.mean(), c_N=c_N,
                sigma=np.std(e, ddof=1), top4_ssr=share.nlargest(4).sum()), share


rows, ssr_share = {}, {}
for k in ("all", "excl"):
    rows[k], ssr_share[k] = calibrate(k)

cal = pd.DataFrame({"riaz": RIAZ} | rows).T
# Minimum detectable crime ratio c_I/c_N (80% power, 5% two-sided) at the 2014-2016 mean shock
# (the vertical line in Figure 2), holding n and CV at Riaz's values:
# r_MD = 2.8 * sigma / (sd(dS) * sqrt(n))
cal["mdr"] = 1 + 2.8 * cal.sigma / (d.dS.mean() * RIAZ["cv"] * np.sqrt(RIAZ["n"])) / cal.c_N
cal.to_csv(OUT / "calibration.csv")
print(cal.round(5).to_string())

# The four counties with the largest residuals (all crimes)
drop4 = ssr_share["all"].nlargest(4).index
s4 = d.drop(drop4)
print("four largest residuals:", [NAME[i] for i in drop4])
inc = pks.imm2016 - pks.imm2014
top5_change = d.nlargest(5, "dy_all").index  # labelled in the histogram
stats = pd.Series({
    # Standard deviations of the raw (not residualized) changes, as in the histogram
    "sd_dy_all": d.dy_all.std(), "sd_dy_excl": d.dy_excl.std(),
    "sd_dy_all_without_top4": s4.dy_all.std(),
    "imm_share_2014": pks.imm2014.sum() / pks.all2014.sum(),
    "imm_share_2016": pks.imm2016.sum() / pks.all2016.sum(),
    "imm_cases_2014": pks.imm2014.sum(), "imm_cases_2016": pks.imm2016.sum(),
    "all_cases_2014": pks.all2014.sum(), "all_cases_2016": pks.all2016.sum(),
    "top4_share_of_imm_increase": inc.reindex(drop4).sum() / inc.sum(),
    "top4_pop_share_2016": pop.p2016.reindex(drop4).sum() / pop.p2016.sum(),
    "bgl_all_rate_2014": d.loc[9172, "y_all2014"], "bgl_all_rate_2016": d.loc[9172, "y_all2016"],
    "bgl_excl_rate_2014": d.loc[9172, "y_excl2014"], "bgl_excl_rate_2016": d.loc[9172, "y_excl2016"],
    "bgl_ssr_share": ssr_share["all"][9172],
    "top4_dy_excl_min": d.loc[drop4, "dy_excl"].min(), "top4_dy_excl_max": d.loc[drop4, "dy_excl"].max(),
    "top5_dy_excl_min": d.loc[top5_change, "dy_excl"].min(),
    "top5_dy_excl_max": d.loc[top5_change, "dy_excl"].max(),
    "cN_all_counties": cN_full, "n_all_counties": len(full_sample),
})
stats.to_csv(OUT / "text_numbers.csv", header=["value"])
print(stats.round(4).to_string())

# --- Benchmark for 2016 (the horizontal line in Figure 2). Suspects: national PKS table 61
#     (key 890000, both sexes; a suspect is counted once nationally), by residence status as
#     recorded by the police. Suspects recorded as asylum seekers are divided by the number of
#     asylum seekers in 2016: procedures pending at the Federal Office or in court on 31.12.2015
#     plus first applications in 2016 (BAMF, Das Bundesamt in Zahlen 2016). This counts each
#     applicant as present for the whole year, so it overstates the population at risk and
#     understates the rate. The benchmark is the asylum-seeker suspect rate divided by the suspect
#     rate of everyone else (all other suspects over the rest of the population), Riaz's c_I/c_N.
t61 = pd.read_csv(PKS / "PKS2016_T61_TV_nichtdeutsch_Aufenthaltsanlass.csv", sep=";", skiprows=1,
                  encoding="latin1", dtype=str)
t61 = t61[(t61.iloc[:, 0] == "890000") & (t61.Sexus == "X")].iloc[0]
col = lambda s: num(pd.Series([t61[[c for c in t61.index if s in c][0]]]))[0]
ts = pd.read_excel(DESTATIS / "schutzsuchende_2025_2010240257005.xlsx", sheet_name="12531-01",
                   header=None, dtype=str)
ts = ts[ts[0].astype(str).str.startswith("31.12.2016")].iloc[0]
bamf = pd.read_csv(ROOT / "data" / "bamf" / "bamf_2016_asylum_procedures.csv", index_col=0)["value"]

T, P = col("Tatverdaechtige insgesamt"), float(ts[1])  # all suspects; population of Germany
# Check against the BKA's immigrant suspects ("Zuwanderer"), Kriminalitaet im Kontext von Zuwanderung 2016
assert sum(col(s) for s in ("Asylbewerber", "Duldung", "Kontingent", "Aufenthalt unerlaubt")) == 174438
S = col("Asylbewerber")
N = bamf[["pending_bamf_end2015", "pending_court_end2015", "first_applications_2016"]].sum()
B = pd.Series(dict(suspects=S, pop=N, share_suspects=S / T, share_pop=N / P,
                   rate=S / N, rate_other=(T - S) / (P - N), ratio=(S / N) / ((T - S) / (P - N))))
print(B.round(4).to_string())
obs = B.add_prefix("asylum_")
obs["ratio_axis"] = B.ratio  # the horizontal line
obs["dS_2017_2019"] = dS1719.mean()  # average county change, for the text
obs["sdS_2017_2019"] = dS1719.std()  # SD across counties, the input to the 2017-2019 power number
obs["dS_2014_2016"] = d.dS.mean()  # average county change, the vertical line
obs.to_csv(OUT / "observed_ratio.csv", header=["value"])

# --- Table: calibration parameters
cols = ["riaz", "all", "excl"]
lines = [
    ("Baseline crime rate 2014, $c_N$", "c_N", "{:.4f}"),
    ("Residual volatility, $\\sigma_{\\Delta\\varepsilon}$", "sigma", "{:.4f}"),
    ("Minimum detectable $c_I/c_N$", "mdr", "{:.3g}"),
]
body = []
for lab, v, f in lines:
    cells = [("--" if pd.isna(cal.loc[c, v]) else f.format(cal.loc[c, v])) for c in cols]
    body.append(lab + " & " + " & ".join(cells) + " \\\\")
tex = r"""\begin{tabular}{lccc}
\toprule
 & Riaz (2026) & \multicolumn{2}{c}{Reconstruction} \\
\cmidrule(lr){3-4}
 & & All crimes & Excl.\ immigration law \\
 & (1) & (2) & (3) \\
\midrule
""" + "\n".join(body) + r"""
\bottomrule
\end{tabular}
"""
(OUT / "tables" / "tab_calibration.tex").write_text(tex, encoding="utf8")


# --- Table: the five counties with the largest relative increase in the crime rate
def top5(k):
    t = d.assign(rel=d[f"y_{k}2016"] / d[f"y_{k}2014"] - 1).nlargest(5, "rel")
    t["share"] = ssr_share[k].reindex(t.index)
    t["km"] = [border_km(i) for i in t.index]
    assert t.km.notna().all(), t[t.km.isna()]
    return [f"{NAME[i]} & {r[f'y_{k}2014']:.3f} & {r[f'y_{k}2016']:.3f} & {100 * r.rel:,.0f} & "
            f"{CHECK if r.km <= 25 else ''} & {100 * r.share:.1f} \\\\" for i, r in t.iterrows()], \
        t["share"].sum()


CHECK = r"$\checkmark$"
a, sa = top5("all")
b, sb = top5("excl")
tex = r"""\begin{tabular}{lccccc}
\toprule
 & \multicolumn{2}{c}{Crimes per inhabitant} & Change & Within 25 km & Share of squared \\
\cmidrule(lr){2-3}
County & 2014 & 2016 & (\%) & of border & residuals (\%) \\
\midrule
\multicolumn{6}{l}{\textit{Panel A. All recorded crimes}} \\
""" + "\n".join(a) + f"\n\\addlinespace\n\\multicolumn{{5}}{{l}}{{Five counties combined}} & {100 * sa:.1f} \\\\\n" + \
r"""\midrule
\multicolumn{6}{l}{\textit{Panel B. Excluding immigration-law offences}} \\
""" + "\n".join(b) + f"\n\\addlinespace\n\\multicolumn{{5}}{{l}}{{Five counties combined}} & {100 * sb:.1f} \\\\\n" + \
r"""\bottomrule
\end{tabular}
"""
(OUT / "tables" / "tab_counties.tex").write_text(tex.replace("\u00df", "{\\ss}").replace("\u00fc", '\\"u')
                                                  .replace("\u00f6", '\\"o').replace("\u00e4", '\\"a'),
                                                  encoding="utf8")
print(f"top-5 share of squared residuals: all {sa:.3f}, excl {sb:.3f}")

# --- Macros for the manuscript
A, R, st = cal.loc["all"], cal.loc["excl"], stats
mac.update({
    "NCounties": M.num(len(d)), "NCountiesAll": M.num(st.n_all_counties),
    "CNAllShort": M.num(A.c_N, 3),
    "CNSampleDiffPct": M.num(100 * abs(RIAZ["c_N"] / A.c_N - 1), 2),
    "SigmaAll": M.num(A.sigma, 3), "SigmaExcl": M.num(R.sigma, 4), "SigmaFactor": M.num(A.sigma / R.sigma, 1),
    "SDAll": M.num(st.sd_dy_all, 3), "SDAllNoTopFour": M.num(st.sd_dy_all_without_top4, 4),
    "SDExcl": M.num(st.sd_dy_excl, 4),
    "BglIncrease": M.pct(st.bgl_all_rate_2016 / st.bgl_all_rate_2014 - 1),
    "TopFourSSR": M.pct(A.top4_ssr), "BglSSR": M.pct(st.bgl_ssr_share, 1),
    "ImmShareFourteen": M.pct(st.imm_share_2014, 1), "ImmShareSixteen": M.pct(st.imm_share_2016, 1),
    "TopFourImmIncrease": M.pct(st.top4_share_of_imm_increase),
    "TopFourPopShare": M.pct(st.top4_pop_share_2016, 2),
    "BglAllFourteen": M.num(st.bgl_all_rate_2014, 2), "BglAllSixteen": M.num(st.bgl_all_rate_2016, 2),
    "BglExclFourteen": M.num(st.bgl_excl_rate_2014, 3), "BglExclSixteen": M.num(st.bgl_excl_rate_2016, 3),
    "TopFiveExclMin": M.num(st.top5_dy_excl_min, 3), "TopFiveExclMax": M.num(st.top5_dy_excl_max, 3),
    "MeanShockShort": M.num(100 * d.dS.mean(), 1),
    "SdShockShort": M.num(100 * d.dS.std(), 2),
    "SdShockSeventeenNineteen": M.num(100 * dS1719.std(), 2),
    # 2016 benchmark
    "SuspAll": M.num(T), "SuspAsylum": M.num(S),
    "PendBamf": M.num(bamf.pending_bamf_end2015), "PendCourt": M.num(bamf.pending_court_end2015),
    "FirstApp": M.num(bamf.first_applications_2016),
    "AsyPop": M.num(N), "AsyShareSusp": M.pct(B.share_suspects, 2), "AsySharePop": M.pct(B.share_pop, 2),
    "AsyRate": M.pct(B.rate, 2), "RateOther": M.pct(B.rate_other, 2),
    "Bench": M.num(B.ratio, 2), "BenchShort": M.num(B.ratio, 1),
    "ImmCasesFourteen": M.num(st.imm_cases_2014), "ImmCasesSixteen": M.num(st.imm_cases_2016),
    "AllCasesFourteen": M.num(st.all_cases_2014 / 1e6, 2), "AllCasesSixteen": M.num(st.all_cases_2016 / 1e6, 2),
})
M.write(OUT / "macros" / "01_calibrate.tex", mac)
