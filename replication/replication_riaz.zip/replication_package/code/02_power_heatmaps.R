# Re-run the Monte Carlo power simulation of Riaz (2026, BJPolS), Figure 2, under
#   (A) Riaz's own calibration (data/riaz/fd_calibration_GER_2014_2016.rds)
#   (B) baseline rate and noise recalibrated excluding immigration-law offences
# The data-generating process, number of draws and test are Riaz's (fig_2.R); the grid of
# crime ratios runs to 10x instead of 31x. The OLS t-test is computed in closed form, which
# gives the same test decisions as summary(lm()) for identical draws. Reference lines: the
# 2016 ratio of the asylum-seeker suspect rate to that of everyone else and the 2014-2016 mean shock; diamonds mark
# 80% power on each.
# Inputs : data/riaz/fd_calibration_GER_2014_2016.rds, output/calibration.csv,
#          output/observed_ratio.csv (code/01_calibrate.py)
# Outputs: output/figures/fig_power_heatmaps.pdf/.png, output/power_summary.csv,
#          output/macros/02_power_heatmaps.tex

library(ggplot2)
library(dplyr)
library(scales)
library(viridis)

root <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE),
                                                                 value = TRUE))), ".."))
setwd(root)
dir.create("output/figures", showWarnings = FALSE, recursive = TRUE)

riaz <- readRDS("data/riaz/fd_calibration_GER_2014_2016.rds")
cal  <- read.csv("output/calibration.csv", row.names = 1)
# 2016 benchmark: asylum-seeker suspect rate divided by the suspect rate of everyone else
obs_csv <- read.csv("output/observed_ratio.csv", row.names = 1)
obs  <- obs_csv["ratio_axis", "value"]
# 2017-2019 shock for the text. With an intercept, power depends on the shock only through its SD
# across counties (Riaz's DGP sets SD = CV x mean), so the 2017-2019 shock enters as the mean
# shock whose SD under Riaz's CV equals the observed 2017-2019 SD.
S1719 <- obs_csv["sdS_2017_2019", "value"] / riaz$coeff_var_S
# Average county change in the refugee share 2014-2016, the mean shock of the calibration
dS1416 <- riaz$mean_delta_S

# Riaz's simulate_power_fd(), same draws in the same order, closed-form OLS t-test
simulate_power_fd <- function(avg_delta_S, r_true, n_obs, n_sims, coeff_var_S,
                              sigma_delta_epsilon, alpha) {
  sd_delta_S <- avg_delta_S * coeff_var_S
  if (sd_delta_S <= 1e-9) return(ifelse(abs(r_true) < 1e-9, alpha, 0))
  t_crit <- qt(1 - alpha / 2, n_obs - 2)
  sig <- 0L
  for (s in seq_len(n_sims)) {
    delta_S <- rnorm(n_obs, mean = avg_delta_S, sd = sd_delta_S)
    delta_e <- rnorm(n_obs, mean = 0, sd = sigma_delta_epsilon)
    delta_y <- r_true * delta_S + delta_e
    xc  <- delta_S - mean(delta_S)
    sxx <- sum(xc^2)
    b   <- sum(xc * delta_y) / sxx
    res <- delta_y - mean(delta_y) - b * xc
    se  <- sqrt(sum(res^2) / (n_obs - 2) / sxx)
    if (abs(b / se) > t_crit) sig <- sig + 1L
  }
  sig / n_sims
}

scen <- tibble::tribble(
  ~panel,                                    ~c_N,                 ~sigma,
  "A. Riaz (2026): all recorded crimes",     riaz$c_N,             riaz$sigma_Deps,
  "B. Excluding immigration-law offences",   cal["excl", "c_N"],   cal["excl", "sigma"]
)
power_at <- function(dS, ratio, j) simulate_power_fd(dS, (ratio - 1) * scen$c_N[j], riaz$n_units,
                                                     1000L, riaz$coeff_var_S, scen$sigma[j], 0.05)

grid <- expand.grid(DeltaS_avg = seq(0, 0.02, length.out = 21),
                    ratio      = seq(1, 10, length.out = 20), KEEP.OUT.ATTRS = FALSE)

set.seed(20260317)
res <- bind_rows(lapply(seq_len(nrow(scen)), function(j) {
  g <- grid
  g$power <- mapply(power_at, g$DeltaS_avg, g$ratio, MoreArgs = list(j = j))
  g$panel <- scen$panel[j]
  g
}))

# Where power reaches 80% on the two reference lines. In Riaz's DGP, Delta S = S(1 + CV z), so for
# common draws the t-statistic is (r S + b0) / se0, with b0 and se0 the slope and SE from
# regressing the noise on 1 + CV z. Power depends on r and S only through u = r S: find the u at
# which 80% of 10,000 draws reject, then the ratio on the vertical line is 1 + u / (S c_N) and the
# shock on the horizontal line is u / ((obs - 1) c_N).
power_u <- function(j, n_sims = 10000L) {
  set.seed(20261007 + j)
  n  <- riaz$n_units
  z  <- matrix(rnorm(n * n_sims), n) * riaz$coeff_var_S
  e  <- matrix(rnorm(n * n_sims, sd = scen$sigma[j]), n)
  xc <- sweep(z, 2, colMeans(z))
  sxx <- colSums(xc^2)
  b0  <- colSums(xc * e) / sxx
  res0 <- sweep(e, 2, colMeans(e)) - sweep(xc, 2, b0, "*")
  se0 <- sqrt(colSums(res0^2) / (n - 2) / sxx)
  tc  <- qt(0.975, n - 2)
  function(u) sapply(u, function(v) mean(abs(v + b0) > tc * se0))
}
pw  <- lapply(seq_len(nrow(scen)), power_u)
u80 <- function(j) uniroot(function(u) pw[[j]](u) - 0.8, c(0, 1), tol = 1e-10)$root

# Smallest ratio with 80% power and power at the observed suspect-rate ratio, at the 2014-2016
# mean shock, half a percentage point and the 2017-2019 shock (all numbers in the text)
summ <- bind_rows(lapply(seq_len(nrow(scen)), function(j) {
  S <- c(dS1416, 0.005, S1719)
  data.frame(panel = scen$panel[j], DeltaS_avg = S, min_ratio_80 = 1 + u80(j) / (S * scen$c_N[j]),
             observed_ratio = obs, power_obs = pw[[j]]((obs - 1) * scen$c_N[j] * S))
}))
write.csv(summ, "output/power_summary.csv", row.names = FALSE)
print(summ)

marks <- bind_rows(lapply(seq_len(nrow(scen)), function(j) {
  u <- u80(j)
  data.frame(panel = scen$panel[j],
             x = c(dS1416, u / ((obs - 1) * scen$c_N[j])) * 100,
             y = c(1 + u / (dS1416 * scen$c_N[j]), obs),
             line = c("vertical", "horizontal"))
}))
print(marks)
marks <- filter(marks, x <= 2, y <= 10)  # Panel A reaches 80% outside the plotted range

p <- ggplot(res, aes(x = DeltaS_avg * 100, y = ratio, fill = power)) +
  geom_tile(color = NA) +
  geom_hline(yintercept = obs, colour = "white", linewidth = 0.5, linetype = "dashed") +
  geom_vline(xintercept = dS1416 * 100, colour = "white", linewidth = 0.5, linetype = "dashed") +
  geom_point(data = marks, aes(x = x, y = y, shape = "80% power reached"), inherit.aes = FALSE,
             size = 2.6, fill = "white", colour = "black", stroke = 0.4) +
  scale_shape_manual(values = 23, name = NULL) +
  geom_label(data = marks, inherit.aes = FALSE, size = 2.6, label.size = 0,
             label.padding = unit(0.12, "lines"), fill = "white", colour = "black",
             aes(x = x + ifelse(line == "vertical", 0.06, -0.06),
                 y = y + ifelse(line == "vertical", -0.3, 0.35),
                 hjust = ifelse(line == "vertical", 0, 1),
                 label = ifelse(line == "vertical", sprintf("%.2f×", y), sprintf("%.2f%%", x)))) +
  annotate("label", x = 0.05, y = obs - 0.12, hjust = 0, vjust = 1, size = 2.8, colour = "white", fill = alpha("black", 0.45), label.size = 0, label.padding = unit(0.12, "lines"),
           label = sprintf("Asylum seekers, 2016 (%.1f×)", obs)) +
  annotate("text", x = dS1416 * 100 + 0.05, y = 1.45, hjust = 0, vjust = 0.5, size = 2.8, colour = "white",
           label = "Germany 2014–2016") +
  facet_wrap(~panel, ncol = 2) +
  scale_fill_viridis(option = "C", limits = c(0, 1), oob = squish,
                     labels = percent_format(accuracy = 1), name = "Power") +
  scale_x_continuous(expand = c(0, 0), labels = function(x) paste0(x, "%")) +
  scale_y_continuous(expand = c(0, 0), breaks = c(1, seq(2, 10, by = 2)),
                     labels = function(y) paste0(y, "×")) +
  labs(x = sprintf("Average immigration shock (change in refugee share; SD across counties = %.3f × average)",
                   riaz$coeff_var_S),
       y = expression(Immigrant*"–"*native~crime~rate~ratio~~(c[I]/c[N]))) +
  guides(fill = guide_colorbar(title.position = "top", title.hjust = 0.5,
                               barwidth = unit(16, "lines"), barheight = unit(0.5, "lines"),
                               ticks = FALSE, order = 1),
         shape = guide_legend(order = 2, override.aes = list(size = 3))) +
  theme_minimal(base_size = 11) +
  theme(panel.grid = element_blank(), legend.position = "bottom",
        strip.text = element_text(hjust = 0, face = "bold"), panel.spacing = unit(1.2, "lines"),
        legend.ticks = element_blank())

ggsave("output/figures/fig_power_heatmaps.pdf", p, width = 8, height = 4.4, device = cairo_pdf)
ggsave("output/figures/fig_power_heatmaps.png", p, width = 8, height = 4.4, dpi = 200)

# --- Macros for the manuscript
pick <- function(j, S) summ[summ$panel == scen$panel[j] & abs(summ$DeltaS_avg - S) < 1e-12, ]
fmt_pow <- function(p) if (p > 0.99) "more than 99" else sprintf("%.0f", 100 * p)
macros <- c(
  NDraws = "1,000", NDrawsExact = "10,000",
  MinRatioA = sprintf("%.1f", pick(1, dS1416)$min_ratio_80),
  MinRatioB = sprintf("%.2f", pick(2, dS1416)$min_ratio_80),
  PowerBenchA = fmt_pow(pick(1, dS1416)$power_obs),
  PowerBenchB = fmt_pow(pick(2, dS1416)$power_obs),
  PowerBenchBHalf = fmt_pow(pick(2, 0.005)$power_obs),
  PowerBenchBLate = fmt_pow(pick(2, S1719)$power_obs),
  ShockHorizA = sprintf("%.1f", 100 * u80(1) / ((obs - 1) * scen$c_N[1])),
  ShockHorizB = sprintf("%.2f", 100 * u80(2) / ((obs - 1) * scen$c_N[2])),
  ShockHorizBSd = sprintf("%.2f", 100 * riaz$coeff_var_S * u80(2) / ((obs - 1) * scen$c_N[2])))
dir.create("output/macros", showWarnings = FALSE, recursive = TRUE)
writeLines(c("% Generated by code; do not edit.",
             sprintf("\\newcommand{\\%s}{%s}", names(macros), macros)),
           "output/macros/02_power_heatmaps.tex")
