# Export the calibration values from Riaz's replication package (BJPolS Dataverse) to CSV, so that
# 01_calibrate.py can compare its rebuilt values with them.
# Input : data/riaz/fd_calibration_GER_2014_2016.rds
# Output: output/riaz_calibration.csv

root <- normalizePath(file.path(dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE),
                                                                 value = TRUE))), ".."))
setwd(root)
dir.create("output", showWarnings = FALSE)
riaz <- readRDS("data/riaz/fd_calibration_GER_2014_2016.rds")
write.csv(data.frame(parameter = names(riaz), value = unlist(riaz)), "output/riaz_calibration.csv",
          row.names = FALSE)
print(unlist(riaz))
