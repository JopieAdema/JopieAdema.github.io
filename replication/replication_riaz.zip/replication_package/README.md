# Replication package for "Statistical Power in Immigration–Crime Studies: A Comment on Riaz (2026)"

*Author: anonymized for review.*

This package contains the data, code and output needed to reproduce every table, figure and number
in the comment. A single command, `python code/run_all.py`, rebuilds everything from the raw data in
about 2 minutes, writes a log for each step and compiles the manuscript. No number in the text is
typed by hand: each script writes the numbers it produces as LaTeX macros (`output/macros/*.tex`),
and the manuscript reads them.

## 1. Contents

```
README.md          this file
README.pdf         this file as PDF
requirements.txt   Python package versions (R packages are listed in Section 4)
code/              scripts, run in the order of Section 5
data/              raw data as downloaded (Section 2)
output/            everything the code produces
  tables/          LaTeX tables read by the manuscript
  figures/         figures (PDF and PNG)
  macros/          numbers cited in the text, as LaTeX macros
  logs/            console output of each step
  *.csv            intermediate results (calibration values, power summary, benchmark)
manuscript/        comment_riaz_rap.tex (manuscript), comment_riaz_rap_appendix.tex (online
                   appendix), references (refs.bib, BibTeX style chicago) and the compiled PDFs
```

## 2. Data sources and licences

All data are publicly available. The files in `data/` are the original downloads, unchanged, except
for `data/bamf/`, which transcribes five numbers from a publication.

| File(s) | Content | Source | Licence / terms |
|---|---|---|---|
| `data/pks/PKS{2014,2016,2017,2019}_Kreise_Faelle.csv` | Police crime statistics (PKS), table 01 by county: recorded cases by offence key and county | Bundeskriminalamt (BKA), *Polizeiliche Kriminalstatistik*, yearly table pages under https://www.bka.de/DE/AktuelleInformationen/StatistikenLagebilder/PolizeilicheKriminalstatistik/ | Datenlizenz Deutschland – Namensnennung – Version 2.0 (dl-de/by-2-0, www.govdata.de/dl-de/by-2-0), as listed for the BKA's PKS tables on GovData |
| `data/pks/PKS2016_T61_TV_nichtdeutsch_Aufenthaltsanlass.csv` | PKS 2016, standard table 61: suspects in Germany, all and non-German, by residence status | BKA, https://www.bka.de/SharedDocs/Downloads/DE/Publikationen/PolizeilicheKriminalstatistik/2016/Standardtabellen/Tatverdaechtige/STD-TV-15-T61-TV-nichtdeutsch-Aufenthaltsanlass_csv.csv | dl-de/by-2-0 |
| `data/destatis/destatis_-Bevoelkerung_Kreise_2007-2019.csv` | Population by county, 31 December 2007–2019 | Statistisches Bundesamt (Destatis), GENESIS-Online table 12411-0015 | dl-de/by-2-0 |
| `data/destatis/destatis-12531-0040_SchutzsuchendeAnzahl_Kreise_2007-2019.csv` | Protection seekers (*Schutzsuchende*) by county, 31 December 2007–2019 | Destatis, GENESIS-Online table 12531-0040 | dl-de/by-2-0 |
| `data/destatis/schutzsuchende_2025_2010240257005.xlsx` | *Statistischer Bericht – Schutzsuchende – 2025*; the code uses table 12531-01 (population of Germany at 31 December 2016) | Destatis, https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Bevoelkerung/Migration-Integration/Publikationen/_publikationen-innen-schutzsuchende.html | © Statistisches Bundesamt (Destatis); reproduction and distribution permitted with source attribution |
| `data/bamf/bamf_2016_asylum_procedures.csv` | Five numbers from BAMF, *Das Bundesamt in Zahlen 2016* (2017): asylum procedures pending at the Federal Office (p. 56) and in court (p. 60) on 31.12.2015, first and follow-up applications in 2016 (p. 10), pending procedures on 31.12.2016 (p. 56) | https://www.bamf.de/SharedDocs/Anlagen/DE/Statistik/BundesamtinZahlen/bundesamt-in-zahlen-2016.pdf | The publication may not be redistributed electronically without BAMF's consent, so only the numbers are included, with page references |
| `data/riaz/fd_calibration_GER_2014_2016.rds` | Riaz's calibration values | Riaz, S. (2026). Replication Data for: Null by Design: Statistical Dilution in Immigration-Crime Research. Harvard Dataverse, V1.1, https://doi.org/10.7910/DVN/FJFWEI | CC0 1.0 |
| `data/gisco/NUTS_RG_01M_2016_3035.geojson` (downloaded on first run, not included) | NUTS 2016 regions, 1:1 million, for the distance of each county to the national border | Eurostat GISCO, https://gisco-services.ec.europa.eu/distribution/v2/nuts/geojson/NUTS_RG_01M_2016_3035.geojson | © EuroGeographics for the administrative boundaries; non-commercial use with attribution |

Source notes required by dl-de/by-2-0: "Datenquelle: Bundeskriminalamt, Polizeiliche
Kriminalstatistik; Statistisches Bundesamt (Destatis), Genesis-Online; Datenlizenz Deutschland –
Namensnennung – Version 2.0; eigene Berechnungen."

## 3. Codebook

* **Units.** German counties (*Kreise* and *kreisfreie Städte*), identified by the five-digit
  official municipality key (AGS). Crime is measured in recorded cases per inhabitant; the refugee
  share is protection seekers per inhabitant, both at 31 December.
* **PKS table 01 by county.** Rows are offence key × county. Key `------` = all offences; `725000` =
  offences against residence, asylum and freedom-of-movement law ("immigration-law offences");
  `890000` = all offences except `725000`. Columns used: offence key, county code
  (*Gemeindeschlüssel*) and recorded cases (*erfasste Fälle*). The 2014 file has no *Kreisart*
  column; the scripts handle this.
* **PKS table 61 (2016).** Row key `890000`, sex `X` (both sexes). Columns used: all suspects;
  non-German suspects; and non-German suspects with residence status *Asylbewerber* (asylum seeker),
  *Duldung* (tolerated: rejected applicant whose deportation is suspended),
  *Kontingent-/Bürgerkriegsflüchtlinge* (quota or civil-war refugee) and *Aufenthalt unerlaubt*
  (staying without permission). The last four sum to the BKA's 174,438 immigrant suspects
  (*Zuwanderer*) in 2016, which the code checks. Each suspect is counted once nationally.
* **GENESIS tables.** County code, name and value at 31 December of each year (population;
  protection seekers, total). "-" marks suppressed values.
* **Statistischer Bericht 2025.** Sheet `12531-01`: national population, foreign population and
  protection seekers by status at 31 December of each year; the code uses the population of
  Germany at 31 December 2016.
* **Sample.** Riaz's 390 counties: all counties except the six Saarland districts (refugees
  registered jointly), Kassel city and district and Cottbus and Spree-Neiße (no separate refugee
  count in 2014), and Göttingen (merged with Osterode in 2016).
* **Benchmark (Appendix C).** The suspect rate of asylum seekers (excluding immigration-law
  offences) divided by the suspect rate of the rest of the population, where asylum seekers are
  approximated by the procedures pending at the Federal Office or in court on 31.12.2015 plus first
  applications in 2016 (follow-up applications are not used). This is the estimate of c_I/c_N, the
  point on the vertical axis of the power figure.

## 4. Computational requirements

* Python 3.12.3 with pandas 2.2.3, numpy 1.26.4, geopandas 1.0.1, shapely 2.0.7, matplotlib 3.9.2
  and openpyxl 3.1.5 (`requirements.txt`).
* R 4.4.3 with ggplot2 3.5.2, dplyr 1.1.4, scales 1.3.0, viridis 0.6.5 and tibble 3.2.1.
* Optional: a LaTeX distribution with `latexmk` and `pdflatex` to compile the manuscript.
* Internet access on the first run only, to download the GISCO boundaries.
* Runtime: about 2 minutes on a standard laptop under Windows 11, most of it for the power
  simulation. Random seeds are fixed in the R scripts, so the results reproduce exactly.

## 5. Instructions

```
python code/run_all.py            # all steps, then compiles the manuscript and online appendix
python code/run_all.py --no-tex   # without the LaTeX step
```

If `Rscript` is not on the PATH, set the environment variable `RSCRIPT` to its full path. Each step
writes its console output to `output/logs/<script>.log`.

| Step | Script | Produces |
|---|---|---|
| 0 | `code/00_riaz_calibration.R` | `output/riaz_calibration.csv`: Riaz's calibration values |
| 1 | `code/01_calibrate.py` | Table 1 (`tab_calibration.tex`), Table B1 (`tab_counties.tex`), the 2016 benchmark (`observed_ratio.csv`), county changes (`county_changes.csv`), numbers in Sections 1–4 and Appendix C |
| 2 | `code/02_power_heatmaps.R` | Figure 2 (`fig_power_heatmaps.pdf`), `power_summary.csv`, power numbers in Section 4 |
| 3 | `code/03_appendix_histogram.py` | Figure 1 (`fig_hist_changes.pdf`) |
| 4 | `code/04_appendix_windows.py` | Table B2 (`tab_windows.tex`), 2017–2019 residual volatility cited in Section 2.2 |

Table 2 (treatment of immigration-law offences in the literature) and Table A1 (data sources) are
written directly in the manuscript and contain no computed numbers. `code/macros.py` is a helper
that writes the LaTeX macros.

## 6. Notes for the Dataverse deposit

* Upload `README.md`, `requirements.txt`, `code/`, `data/` (without
  `data/gisco/`, which the code downloads), `output/` (including `output/logs/`, the log files of the
  statistical software that *Research & Politics* requires) and `manuscript/`, to the
  *Research & Politics* Dataverse.
* The Dataverse default CC0 waiver cannot cover the third-party data in `data/`. Opt out of CC0 and
  state in the terms of use that the code and derived files are released under CC0, while the files
  in `data/` remain under the licences listed in Section 2.

## 7. Data citations

* Bundesamt für Migration und Flüchtlinge (2017). *Das Bundesamt in Zahlen 2016: Asyl, Migration und
  Integration*. Nürnberg.
* Bundeskriminalamt. *Polizeiliche Kriminalstatistik*, Berichtsjahre 2014, 2016, 2017 and 2019, county tables and
  standard table 61 (2016). Wiesbaden.
* Eurostat GISCO. *NUTS 2016*, 1:1 million. © EuroGeographics for the administrative boundaries.
* Riaz, S. (2026). Replication Data for: Null by Design: Statistical Dilution in Immigration-Crime
  Research. Harvard Dataverse, V1.1. https://doi.org/10.7910/DVN/FJFWEI
* Statistisches Bundesamt (Destatis). GENESIS-Online tables 12411-0015 and 12531-0040;
  *Statistischer Bericht – Schutzsuchende – 2025*. Wiesbaden.
